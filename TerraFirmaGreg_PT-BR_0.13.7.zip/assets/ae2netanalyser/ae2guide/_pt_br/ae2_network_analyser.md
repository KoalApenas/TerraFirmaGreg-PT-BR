---
navigation:
    parent: ae2:items-blocks-machines/items-blocks-machines-index.md
    icon: ae2netanalyser:network_analyser
    title: Analisador de Rede ME
categories:
- tools
item_ids:
- ae2netanalyser:network_analyser
---

# Analisar a Rede ME

<ItemImage id="ae2netanalyser:network_analyser" scale="4"></ItemImage>

Você já teve dificuldade para descobrir qual dispositivo da sua rede ME está off-line? Ou só quer ver como a sua rede
está funcionando? Então conheça o Analisador de Rede ME!

## O que está acontecendo na minha rede ME?

Clique em qualquer bloco, cabo ou dispositivo conectado à rede ME para ver o estado de todos os dispositivos e como eles se conectam 
uns aos outros.

![visão geral](./pic/showoff.png)

Cores e formas diferentes representam estados diferentes.
- Cubo azul: dispositivos ME normais; eles têm canais suficientes e podem transportar 8 canais.
- Cubo amarelo: dispositivos ME densos; eles têm canais suficientes e podem transportar 32 canais.
- Cubo vermelho: dispositivos ME off-line; eles não têm canais suficientes.
- Conexão azul: esta conexão pode transportar, no máximo, 8 canais.
- Conexão amarela: esta conexão pode transportar, no máximo, 32 canais.
- Conexão rosa: é uma conexão P2P ME.
- Números: a quantidade de canais transportados por esta conexão.

Observe que o número máximo de canais depende, na verdade, do seu Modo de Canais ME. O Analisador não exibirá números de canais quando o
modo de Canais Infinitos estiver ativado.

## Exibição personalizada

Você pode alterar o modo de análise e as cores na interface de configuração.

![interface](./pic/gui.png)

O Analisador de Rede ME tem 5 modos.
- Cheio: exibe todo o estado da rede.
- Nós: exibe somente o estado dos nós.
- Links: exibe somente o estado das conexões.
- Sem Número: não exibe os números dos canais.
- P2P: exibe somente as conexões P2P ME.

Você também pode alterar a cor dos nós ou das conexões.

![interface2](./pic/color.png)

