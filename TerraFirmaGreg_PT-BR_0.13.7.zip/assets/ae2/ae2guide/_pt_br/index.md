---
navigation:
  title: Índice/Sumário
  position: 0
---
# O que é o Applied Energistics 2?

# Como Usar este Guia

* Acesse a barra lateral esquerda para encontrar o sumário
* Muitas páginas possuem cenas interativas. Se uma cena tiver botões de ![Mais](assets/diagrams/plus.png)
e ![Menos](assets/diagrams/minus.png) — zoom — ao lado, você poderá girar e mover a câmera.
Clique e arraste com o botão esquerdo para girar; clique e arraste com o direito para deslocar.

# O que é o Applied Energistics 2?

O Applied Energistics 2 adiciona componentes e mecânicas que oferecem soluções de logística e armazenamento. Você pode substituir sua
enorme sala cheia de baús por uma Rede ME compacta, mas isso é apenas o começo.
O Applied Energistics foi projetado para trabalhar com outros mods de um modpack e permitir a automação deles. Você pode configurar seu sistema para,
com um único clique, fabricar todos os pré-requisitos — e o resultado final — de uma cadeia de fabricação complexa; manter determinadas
quantidades de itens em estoque, fabricando mais quando necessário; ou simplesmente transportar itens pela sua base.

* [Primeiros Passos](getting-started.md)
* [Dicas e Truques](tips-and-tricks.md)
* [Mecânicas do AE2](ae2-mechanics/ae2-mechanics-index.md)
* [Exemplos de Montagens](example-setups/example-setups-index.md)
* [Itens, Blocos e Máquinas](items-blocks-machines/items-blocks-machines-index.md)

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="assets/assemblies/autocraft_setup_greebles.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
