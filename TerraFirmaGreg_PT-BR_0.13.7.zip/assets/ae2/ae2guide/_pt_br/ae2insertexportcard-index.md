---
navigation:
  title: "Complemento: Cartões de Importação e Exportação do AE2"
  icon: ae2insertexportcard:export_card
  position: 150
categories:
  - tools
item_ids:
- ae2insertexportcard:export_card
- ae2insertexportcard:insert_card
---

# Cartões de Importação e Exportação do AE2

<Row>
  <ItemImage id="ae2insertexportcard:export_card" scale="2" />

  <ItemImage id="ae2insertexportcard:insert_card" scale="2" />
</Row>

Os Cartões de Importação e Exportação permitem enviar itens do seu inventário ao sistema ME ou trazer itens dele para o inventário.

## Cartão de Importação

<ItemImage id="ae2insertexportcard:insert_card" scale="2" />

O Cartão de Importação retira itens de espaços específicos do seu inventário e os envia ao sistema ME.

![Cartão de Importação](diagrams/insert_card.png)

Clicar nos espaços adiciona uma marca de seleção. Todo item em um espaço marcado será importado para o sistema ME. Arraste itens do inventário até a parte superior para alterar o filtro.

### Melhorias

O Cartão de Importação aceita as seguintes [melhorias](items-blocks-machines/upgrade_cards.md):

*   <ItemLink id="fuzzy_card" /> filtra pelo nível de dano e/ou ignora o NBT do item
*   <ItemLink id="inverter_card" /> alterna o filtro de uma lista de permissões para uma lista de bloqueio

### Receita

<RecipeFor id="ae2insertexportcard:insert_card" />

## Cartão de Exportação

<ItemImage id="ae2insertexportcard:export_card" scale="2" />

O Cartão de Exportação funciona da mesma forma, mas retira itens do sistema ME e os coloca no seu inventário.

![Cartão de Exportação](diagrams/export_card.png)

Para especificar os itens, arraste um item do inventário até um dos espaços superiores e clique em um espaço do inventário para definir a quantidade desejada. Clicar com o botão direito redefine o espaço para X.

### Melhorias

O Cartão de Exportação aceita as seguintes [melhorias](items-blocks-machines/upgrade_cards.md):

*   <ItemLink id="fuzzy_card" /> filtra pelo nível de dano e/ou ignora o NBT do item
*   <ItemLink id="speed_card" /> aumenta a velocidade de transferência de 1 item para uma pilha inteira
*   <ItemLink id="crafting_card" /> solicita e fabrica automaticamente itens que não estejam disponíveis no momento

### Receita

<RecipeFor id="ae2insertexportcard:export_card" />
