---
navigation:
  title: Primeiros Passos (1.20+)
  position: 10
---

<div class="notification is-info">
  As informações a seguir se aplicam somente ao Applied Energistics 2 no Minecraft 1.20 ou mais recente.
</div>

# Primeiros Passos

## Obtendo os Materiais Iniciais

<GameScene zoom="4" background="transparent">
  <ImportStructure src="assets/assemblies/meteor_interior.snbt" />
</GameScene>

Para começar no Applied Energistics 2, primeiro você precisa encontrar um [meteorito](ae2-mechanics/meteorites.md). Eles são bem comuns e costumam deixar enormes crateras no terreno, então você provavelmente já encontrou algum em suas viagens.
Caso ainda não tenha encontrado, você pode fabricar uma <ItemLink id="meteorite_compass" />, que apontará para o <ItemLink id="mysterious_cube" /> mais próximo.

Depois de encontrar um meteorito, minere até o centro. Lá você encontrará aglomerados e gemas de quartzo Certus, [drusas de Certus](items-blocks-machines/budding_certus.md) de vários tipos e um Cubo Misterioso no centro.

Minere os aglomerados de quartzo Certus e todos os blocos de quartzo Certus que encontrar. Você também pode recolher as drusas de Certus, mas, sem Toque Suave, elas se degradarão em 1 nível.

Não quebre nenhuma drusa de Certus infalível: mesmo com Toque Suave, ela se degradará para uma drusa de Certus imperfeita, e é impossível restaurá-la ao nível infalível.

Também minere o Cubo Misterioso no centro do meteorito para obter todas as 4 prensas de Inscritor.

## Cultivando Quartzo Certus

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_certus_1.snbt" />
</GameScene>

Gemas de quartzo Certus brotam das [drusas de Certus](items-blocks-machines/budding_certus.md), de forma semelhante à ametista. Se você quebrar uma gema que ainda não terminou de
crescer, ela derrubará um <ItemLink id="certus_quartz_dust" />, sem alteração pela Fortuna. Se quebrar um aglomerado totalmente crescido, ele derrubará quatro
<ItemLink id="certus_quartz_crystal" />, e a Fortuna aumentará essa quantidade.

Há 4 níveis de drusas de Certus: Infalível, Imperfeita, Lascada e Danificada.

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_blocks.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Sempre que uma gema avança um estágio de crescimento, a drusa tem uma chance de se degradar em um nível, até acabar se transformando
em um simples bloco de quartzo Certus. Elas podem ser restauradas — e novas drusas podem ser criadas — lançando a drusa ou um
bloco de quartzo Certus na água com um ou mais <ItemLink id="charged_certus_quartz_crystal" />.

<RecipeFor id="damaged_budding_quartz" />

Drusas de Certus infalíveis não se degradam e geram Certus infinitamente. Porém, elas não podem ser fabricadas nem movidas
com uma picareta, nem mesmo com Toque Suave. (Entretanto, elas *podem* ser movidas com [armazenamento espacial](ae2-mechanics/spatial-io.md).)

Sozinhas, as gemas de quartzo Certus crescem muito lentamente. Felizmente, o <ItemLink id="growth_accelerator" />
acelera enormemente esse processo quando colocado ao lado da drusa. Construir alguns deles deve ser sua primeira prioridade.

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_certus_2.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Se você não tiver quartzo suficiente para também fabricar um <ItemLink id="energy_acceptor" /> ou uma <ItemLink id="vibration_chamber" />,
pode fabricar uma <ItemLink id="crank" /> e instalá-la na extremidade do acelerador.

A coleta automática de Certus é [descrita aqui](example-setups/simple-certus-farm.md).

## Um Breve Comentário sobre Fluix

Outro material necessário é o Fluix, que você já encontrou ao fabricar aceleradores de crescimento. Ele é produzido lançando Certus carregado, redstone e quartzo do Nether na água. Automatizar isso fica “como exercício para o leitor”.

O <ItemLink id="charger" /> é necessário para produzir <ItemLink id="charged_certus_quartz_crystal" />, caso você ainda não tenha fabricado um.

## Inscrevendo Alguns Processadores

Ao explorar um meteorito, você encontrou quatro “prensas” ao quebrar o Cubo Misterioso. Elas são usadas no <ItemLink id="inscriber" /> para produzir os três tipos de processador.

<ItemGrid>
  <ItemIcon id="silicon_press" />

  <ItemIcon id="logic_processor_press" />

  <ItemIcon id="calculation_processor_press" />

  <ItemIcon id="engineering_processor_press" />
</ItemGrid>

O Inscritor é uma máquina com lados definidos, assim como a fornalha padrão. Inserir por cima ou por baixo coloca itens nos slots superior ou inferior; inserir pela lateral ou por trás os coloca no slot central. Os resultados podem ser retirados pela lateral ou por trás.

Para facilitar a automação com funis — e talvez reduzir o emaranhado de tubos —, os Inscritores podem ser girados com uma <ItemLink id="certus_quartz_wrench" />.

Produza alguns processadores de cada tipo para se preparar para a próxima etapa: montar um sistema ME bem básico. Automatizar a produção de processadores fica “como exercício para o leitor”.

## Tecnologia de Matéria e Energia: Redes ME e Armazenamento

### O que é Armazenamento ME?

Pronuncia-se “eme-i” e significa Matéria e Energia.

Matéria e Energia é o principal componente do Applied Energistics 2; é como a versão de um cientista maluco de um baú multibloco
e pode revolucionar seu sistema de armazenamento. O ME é muito diferente de outros sistemas de armazenamento do Minecraft e
talvez exija uma forma de pensar um pouco diferente até você se acostumar; depois que começar, enormes capacidades de armazenamento em um espaço minúsculo
e vários terminais de acesso são apenas o começo das possibilidades.

### O que preciso saber para começar?

Primeiro, o ME armazena itens dentro de outros itens, chamados [Células de Armazenamento](items-blocks-machines/storage_cells.md); existem 5 níveis, com capacidades
cada vez maiores. Para usar uma Célula de Armazenamento, ela deve ser colocada em um <ItemLink id="chest" />
ou em um <ItemLink id="drive" />.

O <ItemLink id="chest" /> mostra o conteúdo da Célula assim que ela é colocada dentro dele, e você
pode adicionar ou remover itens como faria em um <ItemLink id="minecraft:chest" />, exceto que os itens ficam
armazenados nas Células de Armazenamento, e não no próprio <ItemLink id="chest" />.

Embora o <ItemLink id="chest" /> seja uma ótima introdução ao conceito de ME, para realmente
aproveitá-lo você precisa montar uma [Rede ME](ae2-mechanics/me-network-connections.md).

## Seu Primeiro Sistema ME

Agora que você possui todos os materiais e máquinas básicos do Applied Energistics 2, pode montar seu primeiro sistema ME — Matéria e Energia. Será um sistema muito básico: sem autofabricação nem logística, apenas um armazenamento simples, agradável e pesquisável.

<GameScene zoom="6" interactive={true}>
<ImportStructure src="assets/assemblies/tiny_me_system.snbt" />

</GameScene>

*   Lista de ingredientes:
    * 1x <ItemLink id="drive" />
    * 1x <ItemLink id="terminal" /> ou <ItemLink id="crafting_terminal" />
    * 1x <ItemLink id="energy_acceptor" />
    * Alguns [cabos](items-blocks-machines/cables.md), de vidro, revestidos ou inteligentes, mas não densos
    * Algumas [células de armazenamento](items-blocks-machines/storage_cells.md); recomenda-se a variedade de 4k por oferecer um bom equilíbrio entre
    capacidade e tipos — seria mais eficiente [particionar](items-blocks-machines/cell_workbench.md) uma combinação de 4k e 1k, mas não abordaremos essa complexidade agora
---
1.  Coloque o gabinete.
2.  O aceitador de energia — assim como vários outros [dispositivos](ae2-mechanics/devices.md) do AE2 — possui 2 modos: cubo e plano. É possível alternar entre eles em uma grade de fabricação. Se o aceitador estiver em forma de cubo, coloque-o ao lado do gabinete. Se for um quadrado plano, coloque um cabo no gabinete e instale o aceitador nele.
3.  Conduza energia até o aceitador de energia usando um cabo, tubo ou conduíte de seu mod de geração de energia preferido.
4.  Coloque um cabo sobre o gabinete — ou em outra posição na altura dos olhos — e instale nele o terminal ou terminal de fabricação.
5.  Coloque suas células de armazenamento no gabinete
6.  Lucre
7.  Experimente as configurações do terminal
8.  Contemple seu poder e sua habilidade supremos
9.  Perceba que, no panorama geral, esta rede é bastante pequena

### Expandindo sua Rede

Agora você possui algum armazenamento básico e acesso a ele. É um bom começo, mas provavelmente desejará
automatizar algum processamento.

Um ótimo exemplo é colocar um <ItemLink id="export_bus" /> sobre uma fornalha para
inserir minérios, e um <ItemLink id="import_bus" />
sob a fornalha para retirar os minérios processados.

O <ItemLink id="export_bus" /> permite exportar itens da rede para o inventário
conectado, enquanto o <ItemLink id="import_bus" /> importa itens do inventário conectado para
a rede.

### Superando Limites

Neste ponto, você provavelmente está se aproximando de cerca de 8 [dispositivos](ae2-mechanics/devices.md). Ao chegar a 9 dispositivos, precisará começar a
administrar [canais](ae2-mechanics/channels.md). Muitos dispositivos — mas não todos — exigem um canal para
funcionar.

Por padrão, uma rede pode comportar 8 canais. Ao ultrapassar esse limite, você terá de adicionar
um <ItemLink id="controller" /> à rede. Isso permite expandi-la enormemente.
Os [cabos inteligentes](items-blocks-machines/cables.md) permitem visualizar como os canais são roteados pela rede. Use-os bastante no início para aprender o comportamento dos canais — ou caso tenha muita redstone e pó de pedra luminosa.
