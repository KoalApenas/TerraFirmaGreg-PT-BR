---
navigation:
  title: Dicas e Truques
  position: 20
---

# Dicas e Truques

Uma coleção de pequenas recomendações diversas

* Remova o OptiFine
* Você pode girar e ampliar as cenas do guia que possuem os botões de zoom e de mostrar ou ocultar anotações
* Mantenha sua rede em forma de árvore e evite ciclos
* Mantenha [dispositivos](ae2-mechanics/devices.md) de bloco inteiro em grupos de 8 ou menos, a menos que entenda profundamente como os [canais](ae2-mechanics/channels.md)
  são roteados pela rede
* Escolha um tipo de madeira e use-o em todos os [padrões](items-blocks-machines/patterns.md). Sim, ativar substituições
  nos padrões às vezes funciona, mas usar sempre o mesmo tipo de madeira reduz bastante as complicações.
* Organize seus [padrões](items-blocks-machines/patterns.md) verticalmente no <ItemLink id="pattern_access_terminal" /> ou
  distribua-os entre seus [provedores](items-blocks-machines/pattern_provider.md), permitindo que as receitas sejam executadas em paralelo.
* Adicione uma [célula de energia](items-blocks-machines/energy_cells.md) para que sua rede suporte picos de consumo.
* Você pode usar água no <ItemLink id="condenser" />
* A melhor maneira de manter sua rede organizada é não armazenar nela espólios aleatórios de criaturas, como espadas e armaduras. Cada combinação única de
  encantamento e durabilidade representa outro [tipo](ae2-mechanics/bytes-and-types.md).
* Um evento de “item entrando no sistema” precisa ocorrer ao devolver o resultado de um [padrão de processamento](items-blocks-machines/patterns.md),
  por exemplo, por meio de um <ItemLink id="import_bus" />, uma <ItemLink id="interface" /> ou o slot de retorno de um <ItemLink id="pattern_provider" />;
  não basta transportar o resultado para um baú que tenha um <ItemLink id="storage_bus" />.
* Não se esqueça de que você pode girar e ampliar as cenas do guia que possuem os botões de zoom e de mostrar ou ocultar anotações
* O <ItemLink id="pattern_provider" /> envia apenas lotes completos da receita e somente por um único lado. Isso é útil
  para garantir que as máquinas não recebam lotes incompletos, mas às vezes você precisa enviar os ingredientes para vários lugares.
  Você pode fazer isso usando uma <ItemLink id="interface" />, seja como uma [sub-rede de tubo](example-setups/pipe-subnet.md), seja aproveitando
  sua capacidade de conter simultaneamente várias pilhas diferentes de itens, fluidos, substâncias químicas etc., usando-a como uma espécie de baú ou tanque intermediário.
* Você pode ampliar e girar as cenas do guia que possuem os botões de zoom e de mostrar ou ocultar anotações
