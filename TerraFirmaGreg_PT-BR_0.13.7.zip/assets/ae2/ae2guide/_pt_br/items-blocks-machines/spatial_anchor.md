---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Âncora Espacial
  icon: spatial_anchor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:spatial_anchor
---

# A Âncora Espacial

<BlockImage id="spatial_anchor" p:powered="true" scale="8"/>

Uma rede do AE2 precisa permanecer carregada para que qualquer [dispositivo](../ae2-mechanics/devices.md) funcione; se apenas parte dela estiver carregada,
talvez não funcione corretamente. A Âncora Espacial resolve esse problema forçando o carregamento dos chunks ocupados por sua rede.
Um único cabo atravessando a borda de um chunk já é suficiente para carregar o novo chunk.

Ela propaga seu “carregamento” por [pontes quânticas](quantum_bridge.md), mas não entre dimensões. Portanto, se você
possui uma ponte quântica para o Nether, precisa de uma âncora espacial na rede de sua base e outra na rede do Nether.

Por padrão, ela também habilita ticks aleatórios nos chunks carregados; isso pode ser desativado na configuração do AE2.

Ela pode ser girada com uma <ItemLink id="certus_quartz_wrench" /> se, por algum motivo, você quiser fazer isso.

## Configurações

*   A âncora espacial fornece acesso à configuração global para exibir energia em AE ou E/FE.
*   Um holograma pode ser exibido no mundo para mostrar os chunks que estão sendo carregados.

## Energia

A âncora espacial consome [energia](../ae2-mechanics/energy.md) de acordo com esta equação:

e = 80 + (x\*(x+1))/2

onde x é o número de chunks carregados

## Receita

<RecipeFor id="spatial_anchor" />
