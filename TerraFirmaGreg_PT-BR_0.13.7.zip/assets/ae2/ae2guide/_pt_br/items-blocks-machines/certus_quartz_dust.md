---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Pó de Quartzo Certus
  icon: certus_quartz_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_dust
---

# Pó de Quartzo Certus

<ItemImage id="certus_quartz_dust" scale="4" />

Um <ItemLink id="certus_quartz_crystal" /> que foi triturado por uma <ItemLink id="inscriber" />. É usado na produção de
diversos materiais e componentes do AE2.

## Receita

<RecipeFor id="certus_quartz_dust" />
