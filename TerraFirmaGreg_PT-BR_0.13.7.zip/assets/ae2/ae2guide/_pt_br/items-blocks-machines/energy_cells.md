---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Células de Energia
  icon: energy_cell
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_cell
- ae2:dense_energy_cell
- ae2:creative_energy_cell
---

# Células de Energia

<Row gap="20">
  <BlockImage id="energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="dense_energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="creative_energy_cell" scale="8" />
</Row>

Células de Energia fornecem à rede mais armazenamento de [energia](../ae2-mechanics/energy.md). Uma reserva de energia ajuda a suavizar
os picos de consumo quando grandes quantidades de itens são inseridas ou extraídas, enquanto uma capacidade maior de armazenamento
permite que a rede funcione quando não há geração de energia (por exemplo, à noite com painéis solares) ou lide com o enorme consumo instantâneo
de energia do [armazenamento espacial](../ae2-mechanics/spatial-io.md).

## Barras de Preenchimento

<Row>
<BlockImage id="energy_cell" scale="4" p:fullness="0" />
<BlockImage id="energy_cell" scale="4" p:fullness="1" />
<BlockImage id="energy_cell" scale="4" p:fullness="2" />
<BlockImage id="energy_cell" scale="4" p:fullness="3" />
<BlockImage id="energy_cell" scale="4" p:fullness="4" />
</Row>

As barras na lateral de uma célula correspondem à quantidade de energia armazenada nela.

*   0 quando a carga está abaixo de 25%
*   1 quando a carga está entre 25% e 50%
*   2 quando a carga está entre 50% e 75%
*   3 quando a carga está entre 75% e 99%
*   4 quando a carga está acima de 99%

## Tipos de Célula

*   A <ItemLink id="energy_cell" /> pode armazenar 200k AE, e apenas uma deve bastar para a maioria dos usos, absorvendo com facilidade os picos de energia
    do uso normal da rede.
*   A <ItemLink id="dense_energy_cell" /> pode armazenar 1.6M AE e é indicada quando você deseja alimentar uma rede com energia armazenada ou
    lidar com o enorme consumo instantâneo de grandes sistemas de [armazenamento espacial](../ae2-mechanics/spatial-io.md).
*   A <ItemLink id="creative_energy_cell" /> é um item criativo para testes que fornece PODERRRR ILIMITADO ou algo assim.

## Receitas

<Row>
  <RecipeFor id="energy_cell" />

  <RecipeFor id="dense_energy_cell" />
</Row>
