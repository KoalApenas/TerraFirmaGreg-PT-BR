---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cabos
  icon: fluix_glass_cable
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:white_glass_cable
- ae2:orange_glass_cable
- ae2:magenta_glass_cable
- ae2:light_blue_glass_cable
- ae2:yellow_glass_cable
- ae2:lime_glass_cable
- ae2:pink_glass_cable
- ae2:gray_glass_cable
- ae2:light_gray_glass_cable
- ae2:cyan_glass_cable
- ae2:purple_glass_cable
- ae2:blue_glass_cable
- ae2:brown_glass_cable
- ae2:green_glass_cable
- ae2:red_glass_cable
- ae2:black_glass_cable
- ae2:fluix_glass_cable
- ae2:white_covered_cable
- ae2:orange_covered_cable
- ae2:magenta_covered_cable
- ae2:light_blue_covered_cable
- ae2:yellow_covered_cable
- ae2:lime_covered_cable
- ae2:pink_covered_cable
- ae2:gray_covered_cable
- ae2:light_gray_covered_cable
- ae2:cyan_covered_cable
- ae2:purple_covered_cable
- ae2:blue_covered_cable
- ae2:brown_covered_cable
- ae2:green_covered_cable
- ae2:red_covered_cable
- ae2:black_covered_cable
- ae2:fluix_covered_cable
- ae2:white_covered_dense_cable
- ae2:orange_covered_dense_cable
- ae2:magenta_covered_dense_cable
- ae2:light_blue_covered_dense_cable
- ae2:yellow_covered_dense_cable
- ae2:lime_covered_dense_cable
- ae2:pink_covered_dense_cable
- ae2:gray_covered_dense_cable
- ae2:light_gray_covered_dense_cable
- ae2:cyan_covered_dense_cable
- ae2:purple_covered_dense_cable
- ae2:blue_covered_dense_cable
- ae2:brown_covered_dense_cable
- ae2:green_covered_dense_cable
- ae2:red_covered_dense_cable
- ae2:black_covered_dense_cable
- ae2:fluix_covered_dense_cable
- ae2:white_smart_cable
- ae2:orange_smart_cable
- ae2:magenta_smart_cable
- ae2:light_blue_smart_cable
- ae2:yellow_smart_cable
- ae2:lime_smart_cable
- ae2:pink_smart_cable
- ae2:gray_smart_cable
- ae2:light_gray_smart_cable
- ae2:cyan_smart_cable
- ae2:purple_smart_cable
- ae2:blue_smart_cable
- ae2:brown_smart_cable
- ae2:green_smart_cable
- ae2:red_smart_cable
- ae2:black_smart_cable
- ae2:fluix_smart_cable
- ae2:white_smart_dense_cable
- ae2:orange_smart_dense_cable
- ae2:magenta_smart_dense_cable
- ae2:light_blue_smart_dense_cable
- ae2:yellow_smart_dense_cable
- ae2:lime_smart_dense_cable
- ae2:pink_smart_dense_cable
- ae2:gray_smart_dense_cable
- ae2:light_gray_smart_dense_cable
- ae2:cyan_smart_dense_cable
- ae2:purple_smart_dense_cable
- ae2:blue_smart_dense_cable
- ae2:brown_smart_dense_cable
- ae2:green_smart_dense_cable
- ae2:red_smart_dense_cable
- ae2:black_smart_dense_cable
- ae2:fluix_smart_dense_cable
---

# Cabos

<GameScene zoom="3" background="transparent">
  <ImportStructure src="../assets/assemblies/cables.snbt" />
  <IsometricCamera yaw="180" pitch="30" />
</GameScene>

Embora redes ME também possam ser criadas por máquinas compatíveis com ME adjacentes, os cabos são a principal forma de
estender uma rede ME por áreas maiores.

Cabos de cores diferentes podem ser usados para garantir que cabos adjacentes não se conectem entre si,
permitindo distribuir os [canais](../ae2-mechanics/channels.md) com mais eficiência. Eles também afetam a cor dos terminais conectados,
assim você não precisa deixar todos os seus terminais roxos. Cabos de Fluix conectam-se a todas as outras cores.

Vale destacar: **OS CANAIS NÃO TÊM NENHUMA RELAÇÃO COM A COR DO CABO**

## Uma Observação Importante

**Se você ainda não conhece o AE2 nem está familiarizado com canais, use Cabos Inteligentes e Cabos Inteligentes Densos sempre que puder.
Eles mostrarão como os canais são roteados pela sua rede, facilitando a compreensão do comportamento deles.**

## Outra Observação

**Eles não são tubos de itens, fluidos, energia nem nada parecido.** Não possuem inventário interno; provedores de padrões e máquinas não empurram
coisas para dentro deles. Sua única função é conectar [dispositivos](../ae2-mechanics/devices.md) do AE2 em uma rede.

## Cabo de Vidro

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/fluix_glass_cable.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="fluix_glass_cable" /> é o cabo mais simples de fabricar, transmite energia
e até 8 [canais](../ae2-mechanics/channels.md). Ele está disponível em 17 cores diferentes; a cor padrão
é Fluix, e ele pode ser tingido com qualquer um dos 16 corantes.

Para fabricar cabos coloridos, cerque um corante de qualquer tipo com 8 cabos do mesmo
tipo (a cor dos cabos não importa, mas eles devem ser do mesmo tipo:
vidro, inteligente etc.). Você também pode pintar cabos no mundo com qualquer
pincel compatível com o Forge.

Você pode fabricar qualquer cabo colorido com um balde de água para remover a tinta.

Você pode revestir o cabo com lã para criar <ItemLink id="fluix_covered_cable" /> e fabricar <ItemLink id="fluix_smart_cable" /> para entender melhor o que está acontecendo com
seus [canais](../ae2-mechanics/channels.md).

<RecipeFor id="fluix_glass_cable" />

<RecipeFor id="blue_glass_cable" />

## Cabo Revestido

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

A variante revestida não oferece nenhuma vantagem de gameplay em relação ao <ItemLink id="fluix_glass_cable" /> correspondente. No entanto, pode ser usada
como uma opção estética alternativa, caso você prefira a aparência revestida.

Pode ser colorida da mesma forma que <ItemLink id="fluix_glass_cable" />. Quatro <ItemLink id="fluix_covered_cable" /> podem ser fabricados com
redstone e pedra luminosa para produzir <ItemLink id="fluix_covered_dense_cable" />.

<Recipe id="network/cables/covered_fluix" />

<RecipeFor id="blue_covered_cable" />

## Cabo Denso

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Um cabo de maior capacidade, capaz de transportar 32 canais, enquanto o cabo padrão transporta apenas 8.
No entanto, ele não comporta barramentos; portanto, primeiro é necessário passar do cabo denso para um
cabo menor (como <ItemLink id="fluix_glass_cable" /> ou <ItemLink id="fluix_smart_cable" />) antes de usar barramentos ou
painéis.

Cabos densos alteram um pouco o comportamento de "caminho mais curto" dos canais: os canais seguirão o caminho mais curto até um
cabo denso e, em seguida, o caminho mais curto por esse cabo denso até um controlador.

<Recipe id="network/cables/dense_covered_fluix" />

<RecipeFor id="blue_covered_dense_cable" />

## Cabo Inteligente

<Row>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
</Row>

Embora tenham uma aparência um pouco semelhante à de <ItemLink id="fluix_covered_cable" />, eles
oferecem uma função de diagnóstico ao visualizar o uso dos canais nos cabos.
Os canais aparecem como linhas coloridas acesas que percorrem a faixa preta dos
cabos, permitindo entender como seus canais estão sendo usados na
rede. Nos cabos inteligentes comuns, os quatro primeiros canais aparecem como linhas da mesma cor do
cabo, e os quatro seguintes aparecem como linhas brancas. Nos cabos inteligentes densos, cada faixa representa 4 canais.

Em redes com um <ItemLink id="controller" />, as linhas nos cabos mostram o caminho exato percorrido pelos canais.

Em redes ad hoc, os cabos inteligentes mostram a quantidade de canais usados em toda a rede, em vez da quantidade de canais que passam por aquele cabo específico.

Eles também podem ser coloridos da mesma forma que <ItemLink id="fluix_glass_cable" />.

<Recipe id="network/cables/smart_fluix" />

<Recipe id="network/cables/dense_smart_fluix" />

<RecipeFor id="blue_smart_cable" />
