---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Pó de Pedra Celeste
  icon: sky_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:sky_dust
---

# Pó de Pedra Celeste

<ItemImage id="sky_dust" scale="4" />

Um bloco <ItemLink id="sky_stone_block" /> triturado por um <ItemLink id="inscriber" />. Usado na produção de
<ItemLink id="cell_component_256k" /> e <ItemLink id="sky_stone_block" />.

Também pode ser obtido apontando um <ItemLink id="annihilation_plane" /> para cima no limite de altura do mundo.

## Receita

<RecipeFor id="sky_dust" />
