---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bloco Gerador de Quartzo Certus
  icon: flawless_budding_quartz
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:flawless_budding_quartz
- ae2:flawed_budding_quartz
- ae2:chipped_budding_quartz
- ae2:damaged_budding_quartz
- ae2:small_quartz_bud
- ae2:medium_quartz_bud
- ae2:large_quartz_bud
- ae2:quartz_cluster
---

# Bloco Gerador de Quartzo Certus

(consulte também [Crescimento de Certus](../ae2-mechanics/certus-growth.md))

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Brotos de Quartzo Certus surgirão nos blocos geradores de Certus, de modo semelhante à ametista. Eles são encontrados em [meteoritos](../ae2-mechanics/meteorites.md).
Há 4 níveis de blocos geradores de Certus: Impecável, Imperfeito, Lascado e Danificado. A maneira mais fácil de identificá-los
é usando um mod como HWYLA, Jade, The One Probe etc. (ou a tela F3).

Nos blocos geradores de Certus imperfeitos, lascados e danificados, sempre que um broto avança para o próximo estágio, o bloco gerador tem uma chance
de se degradar em um nível, até se transformar em um <ItemLink id="quartz_block" /> comum.

O bloco gerador de Certus impecável não se degrada ao gerar brotos e funciona como uma fonte infinita.

Se for quebrado com uma picareta comum, um bloco gerador de Certus se degradará em 1 nível. Se for quebrado com uma picareta
encantada com Toque Suave, ele não se degradará, a menos que seja impecável. **Isso significa que blocos geradores de Certus impecáveis não podem
ser coletados e movidos com uma picareta**. Em vez disso, o [Armazenamento Espacial](../ae2-mechanics/spatial-io.md) pode ser usado para
recortar e colar os blocos geradores impecáveis em outro lugar.

## Receitas

Blocos geradores de Certus imperfeitos, lascados e danificados podem ser fabricados ao jogar o nível anterior do bloco gerador (ou um <ItemLink id="quartz_block" />)
na água com um ou mais <ItemLink id="charged_certus_quartz_crystal" />.

O bloco gerador de Certus impecável não pode ser fabricado; ele só pode ser encontrado no mundo.

<Row>
  <RecipeFor id="damaged_budding_quartz" />

  <RecipeFor id="chipped_budding_quartz" />

  <RecipeFor id="flawed_budding_quartz" />
</Row>
