---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Prensas
  icon: silicon_press
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:silicon_press
- ae2:logic_processor_press
- ae2:calculation_processor_press
- ae2:engineering_processor_press
- ae2:name_press
---

# Prensas

Existem 5 prensas diferentes usadas no <ItemLink id="inscriber" />.

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

<ItemImage id="name_press" scale="4" />

## Prensas de Processadores

As prensas de Silício, Lógica, Cálculo e Engenharia são usadas na produção de [processadores](processors.md).
Essas 4 prensas são obtidas ao quebrar um <ItemLink id="mysterious_cube" /> em um [meteorito](../ae2-mechanics/meteorites.md).
Elas também podem ser duplicadas em um <ItemLink id="inscriber" />.

<Column>
  <Row>
    <RecipeFor id="silicon_press" />

    <RecipeFor id="logic_processor_press" />
  </Row>

  <Row>
    <RecipeFor id="calculation_processor_press" />

    <RecipeFor id="engineering_processor_press" />
  </Row>
</Column>

## Prensa de Nome

A Prensa de Nome pode ser usada em um inscritor para nomear itens, de forma semelhante a uma bigorna.

Para fabricá-la, clique com o botão direito em uma <ItemLink id="certus_quartz_cutting_knife" /> ou <ItemLink id="nether_quartz_cutting_knife" />
e insira um lingote de metal. Em seguida, digite o nome que você
deseja gravar na placa e retire a placa pronta. É possível usar uma ou duas placas por vez no inscritor;
com duas placas, o nome será impresso combinando os dois textos: primeiro o slot superior e depois o inferior.
