---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Porta de E/S ME
  icon: io_port
  position: 210
categories:
- devices
item_ids:
- ae2:io_port
---

# A Porta de E/S ME

<BlockImage id="io_port" p:powered="true" scale="8" />

A Porta de E/S permite preencher ou esvaziar rapidamente [células de armazenamento](../items-blocks-machines/storage_cells.md), transferindo o conteúdo de ou para
o [armazenamento da rede](../ae2-mechanics/import-export-storage.md).

Ela pode ser girada com uma <ItemLink id="certus_quartz_wrench" />.

## Configurações

*   A Porta de E/S pode ser configurada para mover a célula aos slots de saída quando ela estiver vazia, cheia ou quando o trabalho terminar.
*   Quando um <ItemLink id="redstone_card" /> é inserido, aparecem opções para várias condições de redstone.
*   No centro da interface há uma seta que define a direção da transferência: da célula para o [armazenamento da rede](../ae2-mechanics/import-export-storage.md)
    ou do armazenamento para a célula.

## Melhorias

A Porta de E/S aceita as seguintes [melhorias](upgrade_cards.md):

*   <ItemLink id="speed_card" /> aumenta a quantidade de conteúdo movimentada por operação
*   <ItemLink id="redstone_card" /> adiciona controle por redstone, permitindo ativação com sinal alto, sinal baixo ou uma vez por pulso

## Receita

<RecipeFor id="io_port" />
