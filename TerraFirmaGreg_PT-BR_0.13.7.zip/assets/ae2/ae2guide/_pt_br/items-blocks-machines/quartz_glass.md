---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Vidro de Quartzo
  icon: quartz_glass
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_glass
- ae2:quartz_vibrant_glass
---

# Vidro de Quartzo

<BlockImage id="quartz_glass" scale="8" />

Um vidro quase transparente produzido com <ItemLink id="certus_quartz_dust" />.
Usado para fabricar muitas máquinas e itens do AE2.

Existe uma variante chamada vidro de quartzo vibrante, que emite luz.

## Receitas

<RecipeFor id="quartz_glass" />

<RecipeFor id="quartz_vibrant_glass" />
