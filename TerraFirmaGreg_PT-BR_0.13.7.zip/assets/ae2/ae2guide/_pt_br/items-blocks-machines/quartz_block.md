---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bloco de Quartzo Certus
  icon: quartz_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_block
---

# O Bloco de Quartzo Certus

<BlockImage id="quartz_block" scale="8" />

O bloco de armazenamento de <ItemLink id="certus_quartz_crystal" />. Pode ser usado para produzir [blocos de Certus brotante](budding_certus.md)
ou [blocos decorativos de Certus](decorative_certus.md).

## Receita

<RecipeFor id="quartz_block" />
