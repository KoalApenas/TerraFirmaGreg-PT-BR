---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Acelerador de Crescimento
  icon: growth_accelerator
  position: 310
categories:
- machines
item_ids:
- ae2:growth_accelerator
---

# O Acelerador de Crescimento

<BlockImage id="growth_accelerator" p:powered="true" scale="8"/>

O Acelerador de Crescimento acelera enormemente [o crescimento de](../ae2-mechanics/certus-growth.md) Certus ou Ametista quando é colocado ao lado do bloco em brotamento.

Curiosamente, ele *também* pode acelerar o crescimento de várias plantas.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/growth_accelerator.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Para energizá-lo manualmente, coloque uma <ItemLink id="crank" /> na parte superior ou inferior e clique nela com o botão direito.

Ele só se conecta a cabos nas extremidades onde estão os detalhes rosados de Fluix.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/accelerator_connections.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Receita

<RecipeFor id="growth_accelerator" />
