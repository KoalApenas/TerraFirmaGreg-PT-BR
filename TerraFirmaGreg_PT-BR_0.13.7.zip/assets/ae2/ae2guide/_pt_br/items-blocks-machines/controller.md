---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Controlador
  icon: controller
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:controller
---

# O Controlador

<BlockImage id="controller" p:state="online" scale="8" />

O Controlador é o centro de roteamento de uma [Rede ME](../ae2-mechanics/me-network-connections.md).
Sem ele, uma rede é "ad hoc" e pode ter no máximo 8 [dispositivos](../ae2-mechanics/devices.md) que usam canais no total.

Não é possível ter 2 controladores em uma única [Rede ME](../ae2-mechanics/me-network-connections.md).

O Controlador fornece 32 [Canais](../ae2-mechanics/channels.md) por face.

O Controlador exige 6 AE/t por bloco do controlador para
funcionar. Cada bloco do controlador pode armazenar 8000 AE; portanto, redes maiores podem exigir mais
armazenamento de energia. Consulte [energia](../ae2-mechanics/energy.md) para ver os detalhes.

Controladores multibloco podem ser construídos de forma bastante livre.

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controllers.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

No entanto, algumas regras precisam ser seguidas:

1.  Todos os blocos do controlador em uma [Rede ME](../ae2-mechanics/me-network-connections.md) precisam estar conectados; caso contrário, os blocos ficarão vermelhos.
2.  O tamanho do controlador deve permanecer dentro de 7x7x7; caso contrário, ele ficará vermelho.
3.  Um bloco do controlador pode ter 2 blocos adjacentes em, no máximo, 1 eixo; se violar essa regra, ele será desativado e ficará vermelho.

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controller_rules.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Desde que todas as regras sejam seguidas e haja energia, o controlador deverá brilhar e
alternar suas cores.

Você pode clicar com o botão direito em um controlador para abrir a mesma interface de uma <ItemLink id="network_tool" />.

## Receita

<RecipeFor id="controller" />
