---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Células de Armazenamento
  icon: item_storage_cell_1k
  position: 410
categories:
- tools
item_ids:
- ae2:item_cell_housing
- ae2:fluid_cell_housing
- ae2:cell_component_1k
- ae2:cell_component_4k
- ae2:cell_component_16k
- ae2:cell_component_64k
- ae2:cell_component_256k
- ae2:item_storage_cell_1k
- ae2:item_storage_cell_4k
- ae2:item_storage_cell_16k
- ae2:item_storage_cell_64k
- ae2:item_storage_cell_256k
- ae2:fluid_storage_cell_1k
- ae2:fluid_storage_cell_4k
- ae2:fluid_storage_cell_16k
- ae2:fluid_storage_cell_64k
- ae2:fluid_storage_cell_256k
---

# Células de Armazenamento

<Column>
  <Row>
    <ItemImage id="item_storage_cell_1k" scale="4" />

    <ItemImage id="item_storage_cell_4k" scale="4" />

    <ItemImage id="item_storage_cell_16k" scale="4" />

    <ItemImage id="item_storage_cell_64k" scale="4" />

    <ItemImage id="item_storage_cell_256k" scale="4" />
  </Row>

  <Row>
    <ItemImage id="fluid_storage_cell_1k" scale="4" />

    <ItemImage id="fluid_storage_cell_4k" scale="4" />

    <ItemImage id="fluid_storage_cell_16k" scale="4" />

    <ItemImage id="fluid_storage_cell_64k" scale="4" />

    <ItemImage id="fluid_storage_cell_256k" scale="4" />
  </Row>
</Column>

Células de Armazenamento são um dos principais métodos de armazenamento do Applied Energistics. Elas são inseridas em <ItemLink id="drive" />
ou <ItemLink id="chest" />.

Consulte [Bytes e Tipos](../ae2-mechanics/bytes-and-types.md) para entender suas capacidades em bytes e tipos.

Quando a célula está vazia, o componente de armazenamento pode ser removido do invólucro usando Shift + botão direito com a célula na mão.

## Capacidade de Armazenamento com Diferentes Quantidades de Tipos

O [custo inicial dos tipos](../ae2-mechanics/bytes-and-types.md) faz com que uma célula contendo 1 tipo comporte 2x mais que uma célula usando todos os 63 tipos.

| Célula                                  | Capacidade Total com 1 Tipo em Uso | Capacidade Total com 63 Tipos em Uso |
| ---------------------------------------- | ----------------------------------------: | ------------------------------------------: |
| <ItemLink id="item_storage_cell_1k" />   |                                     8,128 |                                       4,160 |
| <ItemLink id="item_storage_cell_4k" />   |                                    32,512 |                                      16,640 |
| <ItemLink id="item_storage_cell_16k" />  |                                   130,048 |                                      66,560 |
| <ItemLink id="item_storage_cell_64k" />  |                                   520,192 |                                     266,240 |
| <ItemLink id="item_storage_cell_256k" /> |                                 2,080,768 |                                   1,064,960 |


## Particionamento

Células podem ser filtradas para aceitar apenas determinados itens, de forma semelhante à filtragem de <ItemLink id="storage_bus" />. Isso é
feito em uma <ItemLink id="cell_workbench" />.

Itens podem ser arrastados do JEI/REI para os slots mesmo que você não possua nenhuma unidade daquele item.

## Melhorias

Células de armazenamento aceitam as seguintes [melhorias](upgrade_cards.md), inseridas por meio de uma <ItemLink id="cell_workbench" />:

*   <ItemLink id="fuzzy_card" /> — indisponível em células de fluido — permite particionar a célula por nível de dano e/ou ignorar o NBT do item
*   <ItemLink id="inverter_card" /> troca o filtro de lista branca para lista negra
*   <ItemLink id="equal_distribution_card" /> reserva a mesma quantidade de bytes da célula para cada tipo, impedindo que um tipo ocupe toda a célula
*   <ItemLink id="void_card" /> destrói itens inseridos quando a célula está cheia — ou quando o espaço reservado ao tipo específico está cheio, no
    caso de um cartão de distribuição igualitária —, evitando o congestionamento de fazendas. Tenha cuidado ao particioná-la!
*   Células portáteis aceitam <ItemLink id="energy_card" /> para aumentar a capacidade da bateria

## Coloração

Células portáteis de itens e fluidos podem ser coloridas como armaduras de couro, sendo fabricadas em conjunto com corantes.

# Invólucros

Células podem ser produzidas com um componente de armazenamento e um invólucro ou usando a receita do invólucro ao redor do componente:

<Row>
  <Recipe id="network/cells/item_storage_cell_1k" />

  <Recipe id="network/cells/item_storage_cell_1k_storage" />
</Row>

Invólucros sozinhos são fabricados desta forma:

<Row>
  <RecipeFor id="item_cell_housing" />

  <RecipeFor id="fluid_cell_housing" />
</Row>

# Componentes de Armazenamento

Componentes de Armazenamento são o núcleo de todas as células do AE2 e determinam sua capacidade. Cada nível aumenta a capacidade
em 4x e custa 3 unidades do nível anterior.

<Column>
  <Row>
    <RecipeFor id="cell_component_1k" />

    <RecipeFor id="cell_component_4k" />

    <RecipeFor id="cell_component_16k" />
  </Row>

  <Row>
    <RecipeFor id="cell_component_64k" />

    <RecipeFor id="cell_component_256k" />
  </Row>
</Column>

# Células de Armazenamento de Itens

Células de armazenamento de itens comportam até 63 tipos distintos de itens e estão disponíveis em todas as capacidades padrão.

<Column>
  <Row>
    <Recipe id="network/cells/item_storage_cell_1k_storage" />

    <Recipe id="network/cells/item_storage_cell_4k_storage" />

    <Recipe id="network/cells/item_storage_cell_16k_storage" />
  </Row>

  <Row>
    <Recipe id="network/cells/item_storage_cell_64k_storage" />

    <Recipe id="network/cells/item_storage_cell_256k_storage" />
  </Row>
</Column>

## Armazenamento Portátil de Itens

Elas funcionam como um pequeno <ItemLink id="chest" /> no bolso ou como uma mochila. Podem ser carregadas em um <ItemLink id="charger" />.

Ao contrário das células de armazenamento comuns, sua capacidade de tipos é *reduzida* conforme a capacidade em bytes aumenta, e elas possuem metade da
capacidade total em bytes.

Além dos cartões de melhoria aceitos por todas as células, elas também recebem <ItemLink id="energy_card" /> para ampliar suas baterias internas.

<Column>
  <Row>
    <RecipeFor id="portable_item_cell_1k" />

    <RecipeFor id="portable_item_cell_4k" />

    <RecipeFor id="portable_item_cell_16k" />
  </Row>

  <Row>
    <RecipeFor id="portable_item_cell_64k" />

    <RecipeFor id="portable_item_cell_256k" />
  </Row>
</Column>

# Células de Armazenamento de Fluidos

Células de armazenamento de fluidos comportam até 5 tipos distintos de fluido e estão disponíveis em todas as capacidades padrão.

<Column>
  <Row>
    <Recipe id="network/cells/fluid_storage_cell_1k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_4k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_16k_storage" />
  </Row>

  <Row>
    <Recipe id="network/cells/fluid_storage_cell_64k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_256k_storage" />
  </Row>
</Column>

## Armazenamento Portátil de Fluidos

Elas funcionam como um pequeno <ItemLink id="chest" /> no bolso ou como uma mochila. Podem ser carregadas em um <ItemLink id="charger" />.

Ao contrário das células de armazenamento comuns, sua capacidade de tipos é *reduzida* conforme a capacidade em bytes aumenta, e elas possuem metade da
capacidade total em bytes.

Além dos cartões de melhoria aceitos por todas as células, elas também recebem <ItemLink id="energy_card" /> para ampliar suas baterias internas.

<Column>
  <Row>
    <RecipeFor id="portable_fluid_cell_1k" />

    <RecipeFor id="portable_fluid_cell_4k" />

    <RecipeFor id="portable_fluid_cell_16k" />
  </Row>

  <Row>
    <RecipeFor id="portable_fluid_cell_64k" />

    <RecipeFor id="portable_fluid_cell_256k" />
  </Row>
</Column>

# Células Criativas de Itens e Fluidos

<Row>
  <ItemImage id="creative_item_cell" scale="2" />

  <ItemImage id="creative_fluid_cell" scale="2" />
</Row>

Células criativas de itens e fluidos **não oferecem armazenamento infinito**. Em vez disso, funcionam como fontes e destinos infinitos do
item ou fluido para o qual forem [particionadas](cell_workbench.md).
