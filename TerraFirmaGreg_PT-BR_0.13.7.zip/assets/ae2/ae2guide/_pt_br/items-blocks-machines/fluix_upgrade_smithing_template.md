---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Molde de Ferraria de Fluix
  icon: fluix_upgrade_smithing_template
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_upgrade_smithing_template
---

<ItemImage id="fluix_upgrade_smithing_template" scale="8" />

# Molde de Ferraria de Fluix

Ao contrário do molde de ferraria padrão, este pode ser produzido do zero.

Necessário para as [ferramentas de Fluix](fluix_tools.md)

## Receita

<RecipeFor id="fluix_upgrade_smithing_template" />
