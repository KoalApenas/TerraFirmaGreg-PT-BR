---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Pérola de Fluix
  icon: fluix_pearl
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_pearl
---

# Pérola de Fluix

<ItemImage id="fluix_pearl" scale="4" />

Uma Pérola de Ender revestida com <ItemLink id="fluix_crystal" />, usada na produção de
vários componentes do AE2.

## Receita

<RecipeFor id="fluix_pearl" />
