---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Baú ME
  icon: chest
  position: 210
categories:
- devices
item_ids:
- ae2:chest
---

# O Baú ME

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/chest.snbt" />
</GameScene>

O Baú ME funciona como uma rede em miniatura com um <ItemLink id="terminal" />, um <ItemLink id="drive" /> e um <ItemLink id="energy_acceptor" />.
Embora possa ser usado como uma pequena rede de armazenamento, sua capacidade para apenas uma [célula de armazenamento](../items-blocks-machines/storage_cells.md)
limita sua utilidade nessa função.

Em vez disso, ele é útil para interagir especificamente com a célula de armazenamento instalada dentro dele. Seu terminal integrado só consegue ver e acessar
os itens da célula instalada, enquanto os [dispositivos](../ae2-mechanics/devices.md) da rede geral podem acessar itens de qualquer [armazenamento da rede](../ae2-mechanics/import-export-storage.md),
incluindo Baús ME.

Ele possui 2 interfaces diferentes e lados específicos para o transporte de itens. Interagir com o terminal superior abre o terminal integrado. Itens podem ser inseridos na
célula de armazenamento instalada por essa face, mas não podem ser extraídos. Interagir com qualquer outra face abre a interface com o espaço para a célula de armazenamento
e as configurações de prioridade. A célula só pode ser inserida e removida pela logística de itens através da face que contém o espaço da célula.

Ele pode ser girado com uma <ItemLink id="certus_quartz_wrench" />.

Ele possui um pequeno buffer de armazenamento de energia AE; portanto, se não estiver em uma rede com uma [célula de energia](../items-blocks-machines/energy_cells.md),
inserir ou extrair itens demais de uma só vez pode fazer com que fique sem energia.

O terminal pode ser colorido com um <ItemLink id="color_applicator" />.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/chest_color.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurações

O Baú ME possui as mesmas configurações que um <ItemLink id="terminal" /> ou <ItemLink id="crafting_terminal" />.
No entanto, ele não aceita <ItemLink id="view_cell" />s.

## LEDs de Estado da Célula

As células no baú possuem um LED que mostra seu estado:

| Cor     | Estado                                                                           |
| :----- | :------------------------------------------------------------------------------- |
| Verde   | Vazia                                                                            |
| Azul    | Possui algum conteúdo                                                            |
| Laranja | [Tipos](../ae2-mechanics/bytes-and-types.md) cheios; novos tipos não podem ser adicionados |
| Vermelho| [Bytes](../ae2-mechanics/bytes-and-types.md) cheios; mais itens não podem ser inseridos |
| Preto   | Sem energia, ou a célula não possui um [canal](../ae2-mechanics/channels.md)      |

## Prioridade

As prioridades podem ser definidas clicando na chave inglesa no canto superior direito da interface do espaço da célula.
Os itens que entrarem na rede começarão pelo armazenamento de maior prioridade como
seu primeiro destino. Caso dois armazenamentos ou células tenham a mesma prioridade,
se um deles já contiver o item, esse armazenamento terá preferência sobre qualquer
outro. Qualquer célula [particionada](cell_workbench.md) será tratada como se já contivesse o item
quando estiver no mesmo grupo de prioridade que outros armazenamentos. Itens removidos do armazenamento serão
retirados daquele com a menor prioridade. Esse sistema significa que, à medida que itens são inseridos e removidos
do armazenamento da rede, os armazenamentos de maior prioridade serão preenchidos e os de menor prioridade serão esvaziados.

## Receita

<RecipeFor id="chest" />
