---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Monitores
  icon: storage_monitor
  position: 210
categories:
- devices
item_ids:
- ae2:storage_monitor
- ae2:conversion_monitor
---

# Monitores

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/monitors.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Monitores permitem visualizar e interagir com um único tipo de item ou fluido sem abrir uma interface.

Monitores herdam a cor do [cabo](cables.md) no qual estão instalados.

Quando o monitor está no chão ou no teto, você pode girá-lo com uma <ItemLink id="certus_quartz_wrench" />.

Eles são [subpartes de cabo](../ae2-mechanics/cable-subparts.md).

# Monitor de Armazenamento

Exibe um item ou fluido e sua quantidade. Coloque-o ao lado de suas fazendas ou algo assim...

*Não* precisa de um [canal](../ae2-mechanics/channels.md).

Atalhos:

*   Clique com o botão direito usando um item, ou duas vezes usando um recipiente de fluido, para configurar o monitor com esse item ou fluido.
*   Clique com o botão direito usando a mão vazia para limpar o monitor.
*   Use Shift + botão direito com a mão vazia para bloquear o monitor.

## Receita

<RecipeFor id="storage_monitor" />

# Monitor de Conversão

O Monitor de Conversão é semelhante ao monitor de armazenamento, mas permite inserir ou extrair o item configurado.

Se o item configurado puder ser [autofabricado](../ae2-mechanics/autocrafting.md) e não houver unidades no armazenamento, tentar retirar um
item abrirá uma interface para especificar a quantidade que deve ser fabricada.

*Precisa* de um [canal](../ae2-mechanics/channels.md).

Atalhos adicionais:

*   Clique com o botão esquerdo para extrair uma pilha do item configurado ou solicitar sua fabricação quando não houver unidades no armazenamento.
*   Clique com o botão direito usando qualquer item para inseri-lo.
*   Clique com o botão direito usando a mão vazia para inserir todas as unidades do item configurado presentes em seu inventário.

## Receita

<RecipeFor id="conversion_monitor" />
