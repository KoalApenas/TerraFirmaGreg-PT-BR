---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bola de Matéria
  icon: matter_ball
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:matter_ball
---

# Bolas de Matéria

<ItemImage id="matter_ball" scale="4" />

Uma bola de matéria genérica, útil como munição para um <ItemLink id="matter_cannon" /> ou na produção de [bolas de tinta](paintballs.md).

Produzida com 256 itens ou baldes em um <ItemLink id="condenser" /> configurado no modo de bola de matéria.
