---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: TNT Minúscula
  icon: tiny_tnt
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:tiny_tnt
---

# TNT Minúscula

<BlockImage id="tiny_tnt" scale="8" />

Uma TNT pequena para explosões pequenas. Útil para criar pares de <ItemLink id="quantum_entangled_singularity" />.

O dano a blocos pode ser desativado nas configurações para permitir a criação de singularidades sem o risco
de destruição indesejada, caso você queira desativar TNT e creepers no seu servidor.

## Receita

<RecipeFor id="tiny_tnt" />
