---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Padrões
  icon: crafting_pattern
  position: 410
categories:
- tools
item_ids:
- ae2:blank_pattern
- ae2:crafting_pattern
- ae2:processing_pattern
- ae2:smithing_table_pattern
- ae2:stonecutting_pattern
---

# Padrões

<ItemImage id="crafting_pattern" scale="4" />

Padrões são produzidos em um <ItemLink id="pattern_encoding_terminal" /> a partir de padrões em branco e inseridos em <ItemLink id="pattern_provider" />
ou <ItemLink id="molecular_assembler" />.

Há vários tipos de padrão para diferentes finalidades:

*   <ItemLink id="crafting_pattern" /> codificam receitas de uma bancada de trabalho. Eles podem ser colocados diretamente em um <ItemLink id="molecular_assembler" /> para fazê-lo
    fabricar o resultado quando recebe os ingredientes, mas seu uso principal é em um <ItemLink id="pattern_provider" /> ao lado de um montador molecular.
    Provedores de padrões possuem um comportamento especial nesse caso e enviam o padrão relevante aos montadores adjacentes junto com os ingredientes.
    Como os montadores ejetam automaticamente os resultados para inventários adjacentes, basta um montador junto a um provedor para automatizar padrões de fabricação.

***

*   <ItemLink id="smithing_table_pattern" /> são muito semelhantes aos padrões de fabricação, mas codificam receitas da bancada de ferraria. Eles também são automatizados por um provedor
    de padrões e um montador molecular e funcionam exatamente da mesma forma. Na verdade, padrões de fabricação, ferraria e corte de pedra podem ser
    usados na mesma instalação.

***

*   <ItemLink id="stonecutting_pattern" /> são muito semelhantes aos padrões de fabricação, mas codificam receitas do cortador de pedras. Eles também são automatizados por um provedor
    de padrões e um montador molecular e funcionam exatamente da mesma forma. Na verdade, padrões de fabricação, ferraria e corte de pedra podem ser
    usados na mesma instalação.

***

*   <ItemLink id="processing_pattern" /> são a fonte de grande parte da flexibilidade da autofabricação. Eles são o tipo mais genérico e apenas
    afirmam: “Se um provedor de padrões enviar estes ingredientes a inventários adjacentes, o sistema ME receberá estes itens em algum momento no
    futuro próximo ou distante”. É assim que você automatiza a fabricação em quase todas as máquinas de mods, fornalhas e semelhantes. Como possuem uso tão
    geral e não se importam com o que ocorre entre o envio dos ingredientes e o recebimento do resultado, é possível fazer coisas bastante estranhas, como inserir
    os ingredientes em uma cadeia de produção industrial complexa que separa materiais e recebe ingredientes adicionais de fazendas com produção infinita,
    imprimir o roteiro inteiro de Bee Movie... O sistema ME não se importa, desde que receba o resultado especificado pelo padrão. Na verdade,
    ele nem sequer exige que os ingredientes estejam relacionados ao resultado. Você pode dizer “1 tábua de cerejeira = 1 estrela do Nether” e fazer
    sua fazenda de withers matar um wither ao receber uma tábua de cerejeira, e isso funcionará.

Vários <ItemLink id="pattern_provider" /> com padrões idênticos são aceitos e funcionam em paralelo. Além disso, um padrão pode especificar,
por exemplo, 8 pedregulhos = 8 pedras em vez de 1 pedregulho = 1 pedra, fazendo o provedor inserir 8 pedregulhos
em sua instalação de fundição a cada operação, em vez de um por vez.

## Receita

<RecipeFor id="blank_pattern" />
