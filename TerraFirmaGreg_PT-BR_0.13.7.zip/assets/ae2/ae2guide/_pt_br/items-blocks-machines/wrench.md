---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Chaves
  icon: certus_quartz_wrench
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_wrench
- ae2:nether_quartz_wrench
---

# Chaves

<Row>
  <ItemImage id="certus_quartz_wrench" scale="4" />

  <ItemImage id="nether_quartz_wrench" scale="4" />
</Row>

Chaves são usadas para girar dispositivos do AE2 (clique com o botão direito) e desmontar blocos do AE2 (Shift + clique com o botão direito).
[Subpartes](../ae2-mechanics/cable-subparts.md) podem ser removidas de um cabo sem quebrar tudo que estiver nele
(ou o cabo pode ser removido sem quebrar as subpartes).

Muitos blocos do AE2 podem ser girados; portanto, o fato de este guia não dizer que algo pode ser girado não significa que isso seja impossível.

## Receitas

<Row>
  <RecipeFor id="certus_quartz_wrench" />

  <RecipeFor id="nether_quartz_wrench" />
</Row>
