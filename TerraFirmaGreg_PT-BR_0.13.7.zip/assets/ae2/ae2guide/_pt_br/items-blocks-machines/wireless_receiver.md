---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Receptor Sem Fio
  icon: wireless_receiver
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:wireless_receiver
---

# Receptor Sem Fio

<ItemImage id="wireless_receiver" scale="4" />

Uma <ItemLink id="fluix_pearl" /> em uma antena parabólica refletora, componente da tecnologia ME sem fio de curto alcance.

## Receita

<RecipeFor id="wireless_receiver" />
