---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Decorativo
  icon: fluix_stairs
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_stairs
- ae2:fluix_wall
- ae2:fluix_slab
---

# Fluix Decorativo

<GameScene zoom="4" background="transparent">
<ImportStructure src="../assets/assemblies/decorative_fluix.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

O <ItemLink id="fluix_block" /> pode ser fabricado e cortado em uma cortadora de pedras para produzir blocos de construção decorativos.

## Receitas

<Row>
  <RecipeFor id="fluix_stairs" />

  <RecipeFor id="fluix_wall" />

  <RecipeFor id="fluix_slab" />
</Row>
