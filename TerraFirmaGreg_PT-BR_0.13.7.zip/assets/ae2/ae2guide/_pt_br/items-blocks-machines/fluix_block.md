---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bloco de Fluix
  icon: fluix_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_block
---

# O Bloco de Fluix

<BlockImage id="fluix_block" scale="8" />

O bloco de armazenamento para <ItemLink id="fluix_crystal" />. Ele também é usado nas receitas de algumas máquinas.

## Receita

<RecipeFor id="fluix_block" />
