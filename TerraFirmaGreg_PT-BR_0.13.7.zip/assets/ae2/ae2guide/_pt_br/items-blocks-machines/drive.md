---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Gabinete ME
  icon: drive
  position: 210
categories:
- devices
item_ids:
- ae2:drive
---

# O Gabinete ME

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/drive.snbt" />
</GameScene>

O Gabinete ME é o [dispositivo](../ae2-mechanics/devices.md) no qual você insere suas [células de armazenamento](storage_cells.md) para usá-las como
[armazenamento de rede](../ae2-mechanics/import-export-storage.md). Ele possui 10 espaços, e cada um aceita uma célula.

Se por algum motivo desejar, você pode inserir e retirar células do inventário com qualquer logística de itens, como funis ou pontos do AE2.

Ele pode ser girado com uma <ItemLink id="certus_quartz_wrench" />.

## LEDs de Estado das Células

As células no Gabinete ME possuem um LED que mostra seu estado:

| Cor    | Estado                                                                           |
| :----- | :------------------------------------------------------------------------------- |
| Verde  | Vazia                                                                            |
| Azul   | Contém alguns itens                                                               |
| Laranja| [Tipos](../ae2-mechanics/bytes-and-types.md) cheios; nenhum tipo novo pode ser adicionado |
| Vermelho| [Bytes](../ae2-mechanics/bytes-and-types.md) cheios; nenhum outro item pode ser inserido |
| Preto  | Sem energia ou o Gabinete ME não possui [canal](../ae2-mechanics/channels.md)   |

## Prioridade

As prioridades podem ser definidas ao clicar na chave inglesa no canto superior direito da interface.
Itens que entram na rede começam pelo armazenamento de maior prioridade como
seu primeiro destino. Quando dois armazenamentos ou células possuem a mesma prioridade,
se um deles já contém o item, o sistema prefere esse armazenamento a qualquer
outro. Células [particionadas](cell_workbench.md) são tratadas como se já contivessem o item
quando estão no mesmo grupo de prioridade que outros armazenamentos. Itens retirados do armazenamento são
removidos daquele com menor prioridade. Este sistema faz com que, à medida que itens são inseridos e retirados
do armazenamento de rede, os armazenamentos de maior prioridade sejam preenchidos e os de menor prioridade sejam esvaziados.

## Receita

<RecipeFor id="drive" />
