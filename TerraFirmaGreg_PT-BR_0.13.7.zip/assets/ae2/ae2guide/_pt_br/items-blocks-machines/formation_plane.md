---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Plano de Formação
  icon: formation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:formation_plane
---

# O Plano de Formação

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/formation_plane.snbt" />
</GameScene>

O Plano de Formação coloca blocos e solta itens. Ele funciona de modo semelhante a um <ItemLink id="storage_bus" /> que aceita somente inserções,
colocando/soltando objetos quando eles são “armazenados” nele por [dispositivos](../ae2-mechanics/devices.md) que inserem conteúdo no [armazenamento de rede](../ae2-mechanics/import-export-storage.md),
como um <ItemLink id="import_bus" /> e uma <ItemLink id="interface" />.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/formation_plane_demonstration.snbt" />
  <IsometricCamera yaw="255" pitch="30" />
</GameScene>

Este [dispositivo](../ae2-mechanics/devices.md) usa as mesmas mecânicas dos Pontos de Armazenamento em sistemas como [sub-redes com tubos](../example-setups/pipe-subnet.md)
e pode substituir esses pontos em tais sistemas quando você quiser soltar itens/colocar blocos em vez de transportar itens.

Eles são [subpartes de cabo](../ae2-mechanics/cable-subparts.md).

**LEMBRE-SE DE ATIVAR JOGADORES FALSOS NA REIVINDICAÇÃO DO SEU CHUNK**

## Filtragem

Por padrão, o plano coloca/solta qualquer coisa. Itens inseridos nos espaços de filtro funcionam como uma lista de permissões e somente
esses itens específicos podem ser colocados.

Itens e fluidos podem ser arrastados do JEI/REI para os espaços mesmo que você não possua nenhuma unidade daquele item.

Clique com o botão direito usando um recipiente de fluido, como um balde ou tanque, para definir o fluido como filtro em vez do item do recipiente.

## Prioridade

As prioridades podem ser definidas ao clicar na chave inglesa no canto superior direito da interface.
Itens que entram na rede começam pelo armazenamento de maior prioridade.

## Configurações

*   O plano pode ser configurado para colocar blocos no mundo ou soltar itens

## Melhorias

O Plano de Formação aceita as seguintes [melhorias](upgrade_cards.md):

*   A <ItemLink id="capacity_card" /> aumenta a quantidade de espaços de filtro
*   A <ItemLink id="fuzzy_card" /> permite que o plano filtre pelo nível de dano e/ou ignore o NBT do item
*   A <ItemLink id="inverter_card" /> alterna o filtro de uma lista de permissões para uma lista de bloqueio

## Receita

<RecipeFor id="formation_plane" />
