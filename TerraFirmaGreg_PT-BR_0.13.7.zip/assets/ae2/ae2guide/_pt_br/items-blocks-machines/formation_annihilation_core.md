---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Núcleos de Formação e Aniquilação
  icon: formation_core
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:formation_core
- ae2:annihilation_core
---

# Núcleos de Formação e Aniquilação

<Row>
  <ItemImage id="formation_core" scale="4" />

  <ItemImage id="annihilation_core" scale="4" />
</Row>

Estes são os componentes principais dos [dispositivos](../ae2-mechanics/devices.md) de entrada e saída do AE2. Usando o poder de um <ItemLink id="fluix_crystal" /> e
de um [processador lógico](processors.md), eles permitem que dispositivos recebam e enviem itens, blocos, fluidos etc. (Não possuem função própria; são apenas
um componente intermediário de fabricação)

## Receitas

<RecipeFor id="formation_core" />

<RecipeFor id="annihilation_core" />
