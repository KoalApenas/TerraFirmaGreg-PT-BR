---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bancada de Células
  icon: cell_workbench
  position: 310
categories:
- machines
item_ids:
- ae2:cell_workbench
---

# A Bancada de Células

<BlockImage id="cell_workbench" scale="8" />

A Bancada de Células permite configurar [células de armazenamento](storage_cells.md) e <ItemLink id="view_cell" />s.

Você pode adicionar [cartões de melhoria](upgrade_cards.md) e configurar "partições" para filtrar o que a célula armazenará.

Itens e fluidos podem ser arrastados do JEI/REI para os espaços, mesmo que você não possua nenhum daquele item.

Clique com o botão direito usando um recipiente de fluido (como um balde ou tanque) para definir o fluido como filtro, em vez do item que representa o balde ou tanque.

## Configurações

A Bancada de Células possui alguns botões no canto superior esquerdo:

*   Você pode particionar uma célula com base no conteúdo existente nela
*   Você pode limpar o particionamento da célula
*   A bancada pode ser configurada para manter as definições de partição quando a célula for removida, permitindo copiar configurações entre células.

## Receita

<RecipeFor id="cell_workbench" />
