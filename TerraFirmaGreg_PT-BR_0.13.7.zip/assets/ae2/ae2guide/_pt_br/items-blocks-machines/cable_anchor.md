---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Âncora de Cabo
  icon: cable_anchor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:cable_anchor
---

# A Âncora de Cabo

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/cable_anchor.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Pequenos espinhos decorativos montados em cabos, que podem ser usados para impedir a conexão entre cabos, criar escadas com cabos ou fazer o cabo parecer
conectado às paredes ao redor. Também são usados para fabricar <ItemLink id="facade" />.

As âncoras de cabo impedem a formação de conexões no lado em que estão instaladas.

Você pode escalá-las como uma escada.

## Receita

<RecipeFor id="cable_anchor" />
