---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Câmara de Vibração
  icon: vibration_chamber
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:vibration_chamber
---

# A Câmara de Vibração

<BlockImage id="vibration_chamber" p:active="true" scale="8" />

Embora o método principal recomendado para fornecer [energia](../ae2-mechanics/energy.md) à sua rede seja um
<ItemLink id="energy_acceptor" />, a Câmara de Vibração pode gerar diretamente quantidades pequenas ou moderadas de AE.

Por padrão (sem [melhorias](upgrade_cards.md) e com as configurações padrão), ela gera 40 AE/t.

Quando o armazenamento de [energia](../ae2-mechanics/energy.md) da rede está cheio, a Câmara de Vibração reduz seu ritmo para economizar
combustível, mas não consegue desligar completamente.

## Configurações

*   A Câmara de Vibração permite acessar a configuração global que alterna a exibição de energia entre AE e E/FE.

## Melhorias

A Câmara de Vibração aceita as seguintes [melhorias](upgrade_cards.md):

*   O <ItemLink id="energy_card" /> aumenta a eficiência da câmara em +50%, até o máximo de +150%, ou 250% da eficiência básica.
*   O <ItemLink id="speed_card" /> aumenta a velocidade de queima da câmara em +50%, até o máximo de +150%, ou 250% da potência básica.

## Arquivo de Configuração

As propriedades da Câmara de Vibração podem ser editadas no arquivo common.json da pasta ae2, dentro da pasta config do diretório .minecraft\
do jogo.

*   baseEnergyPerFuelTick define a eficiência básica da Câmara de Vibração sem melhorias.
*   minEnergyPerGameTick define a menor geração de energia possível (a câmara sempre consumirá combustível lentamente, mesmo que a rede
    não precise de energia).
*   maxEnergyPerGameTick define a potência máxima sem melhorias (e a velocidade) da Câmara de Vibração.

## Receita

<RecipeFor id="vibration_chamber" />
