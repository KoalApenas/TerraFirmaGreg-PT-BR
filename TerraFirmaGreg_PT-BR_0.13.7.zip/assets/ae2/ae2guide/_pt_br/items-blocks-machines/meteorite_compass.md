---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bússola de Meteoritos
  icon: meteorite_compass
  position: 410
categories:
- tools
item_ids:
- ae2:meteorite_compass
---

# A Bússola de Meteoritos

<ItemImage id="meteorite_compass" scale="4" />

A Bússola de Meteoritos aponta para o <ItemLink id="mysterious_cube" /> mais próximo e, portanto, também aponta para o
[meteorito](../ae2-mechanics/meteorites.md) mais próximo. É um dos primeiros itens do AE2 que você deve fabricar.

## Receita

<RecipeFor id="meteorite_compass" />
