---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ferramentas de Quartzo
  icon: certus_quartz_pickaxe
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_axe
- ae2:certus_quartz_hoe
- ae2:certus_quartz_shovel
- ae2:certus_quartz_pickaxe
- ae2:certus_quartz_sword
- ae2:nether_quartz_axe
- ae2:nether_quartz_hoe
- ae2:nether_quartz_shovel
- ae2:nether_quartz_pickaxe
- ae2:nether_quartz_sword
---

# Ferramentas de Quartzo

<Row>
  <ItemImage id="certus_quartz_axe" scale="4" />

  <ItemImage id="certus_quartz_hoe" scale="4" />

  <ItemImage id="certus_quartz_shovel" scale="4" />

  <ItemImage id="certus_quartz_pickaxe" scale="4" />

  <ItemImage id="certus_quartz_sword" scale="4" />
</Row>

<Row>
  <ItemImage id="nether_quartz_axe" scale="4" />

  <ItemImage id="nether_quartz_hoe" scale="4" />

  <ItemImage id="nether_quartz_shovel" scale="4" />

  <ItemImage id="nether_quartz_pickaxe" scale="4" />

  <ItemImage id="nether_quartz_sword" scale="4" />
</Row>

Ferramentas de quartzo são funcionalmente idênticas às de ferro, com o mesmo dano, durabilidade, velocidade de mineração etc.
Existem variantes de quartzo do Nether e de [quartzo Certus](fluix_crystal.md).

## Receitas

<Column>
  <Row>
    <RecipeFor id="certus_quartz_axe" />

    <RecipeFor id="certus_quartz_hoe" />

    <RecipeFor id="certus_quartz_shovel" />
  </Row>

  <Row>
    <RecipeFor id="certus_quartz_pickaxe" />

    <RecipeFor id="certus_quartz_sword" />
  </Row>

  <Row>
    <RecipeFor id="nether_quartz_axe" />

    <RecipeFor id="nether_quartz_hoe" />

    <RecipeFor id="nether_quartz_shovel" />
  </Row>

  <Row>
    <RecipeFor id="nether_quartz_pickaxe" />

    <RecipeFor id="nether_quartz_sword" />
  </Row>
</Column>
