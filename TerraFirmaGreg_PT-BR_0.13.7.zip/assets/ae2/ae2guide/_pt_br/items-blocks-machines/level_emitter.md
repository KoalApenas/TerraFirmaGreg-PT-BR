---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Emissor de Nível
  icon: level_emitter
  position: 220
categories:
- devices
item_ids:
- ae2:level_emitter
- ae2:energy_level_emitter
---

# O Emissor de Nível

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/level_emitter.snbt" />
</GameScene>

O Emissor de Nível emite um sinal de redstone de acordo com a quantidade de um item no
[armazenamento da rede](../ae2-mechanics/import-export-storage.md).

Também existe uma versão que emite um sinal de redstone de acordo com a [energia](../ae2-mechanics/energy.md) armazenada
em sua rede.

Itens e fluidos podem ser arrastados do JEI/REI para o slot mesmo que você não possua nenhuma unidade daquele item.

Clique com o botão direito usando um recipiente de fluido, como balde ou tanque, para definir o fluido como filtro em vez do item recipiente.

Eles são [subpartes de cabo](../ae2-mechanics/cable-subparts.md).

Ao contrário de outros [dispositivos](../ae2-mechanics/devices.md), emissores de nível *não* precisam de um [canal](../ae2-mechanics/channels.md).

## Configurações

*   O Emissor de Nível pode ser configurado no modo “maior ou igual a” ou “menor que”
*   Quando um <ItemLink id="crafting_card" /> é inserido, ele pode ser configurado para “emitir redstone enquanto o item é fabricado” ou
    “emitir redstone para fabricar o item”

## Melhorias

O emissor de nível aceita as seguintes [melhorias](upgrade_cards.md):

*   <ItemLink id="fuzzy_card" /> permite que o emissor filtre pelo nível de dano e/ou ignore o NBT do item
*   <ItemLink id="crafting_card" /> habilita a função de fabricação

## Função de Fabricação

Quando um <ItemLink id="crafting_card" /> é inserido, o emissor muda para o modo de fabricação.

Isso habilita duas opções:

A primeira, “emitir redstone enquanto o item é fabricado”, faz o emissor produzir um sinal de redstone enquanto seu sistema de [autofabricação](../ae2-mechanics/autocrafting.md)
fabrica um item específico por meio de <ItemLink id="pattern_provider" />. Isso é útil para ligar determinadas
instalações automatizadas de alto consumo apenas enquanto elas estão realmente sendo usadas.

A segunda opção, “emitir redstone para fabricar o item”, é extremamente útil em situações específicas, como fazendas infinitas e
instalações automatizadas que possuem apenas uma chance de produzir uma saída, em vez de uma saída garantida.
Essa configuração cria um [padrão](patterns.md) virtual para a [autofabricação](../ae2-mechanics/autocrafting.md) usar com o item
presente no slot de filtro do emissor.
(Para funcionar corretamente, um padrão real do mesmo item **não deve existir** em seus <ItemLink id="pattern_provider" />)

Esse “padrão” não define ingredientes, nem sequer se importa com eles.
Ele apenas diz: “Se você emitir redstone deste emissor de nível, o sistema ME receberá este item em algum momento no
futuro próximo ou distante”. Em geral, isso é usado para ativar e desativar fazendas infinitas que não exigem ingredientes de entrada
ou para ativar um sistema que processa receitas recursivas, que a autofabricação padrão não compreende, como “1 pedregulho = 2 pedregulhos”,
caso você possua uma máquina que duplique pedregulho.

## Receita

<RecipeFor id="level_emitter" />

<RecipeFor id="energy_level_emitter" />
