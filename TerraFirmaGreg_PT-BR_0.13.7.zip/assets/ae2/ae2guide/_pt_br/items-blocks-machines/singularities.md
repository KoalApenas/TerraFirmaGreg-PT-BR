---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Singularidades
  icon: singularity
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:singularity
- ae2:quantum_entangled_singularity
---

# Singularidade

<ItemImage id="singularity" scale="4" />

Uma bola de matéria extremamente compacta.

Produzida com 256.000 itens ou baldes em um <ItemLink id="condenser" /> configurado no modo de singularidade.

## Singularidade Entrelaçada Quântica

<ItemImage id="quantum_entangled_singularity" scale="4" />

Necessárias para criar uma conexão entre duas [Pontes de Rede Quântica](quantum_bridge.md), elas sempre são produzidas em pares correspondentes.
Para criar uma conexão, coloque 1 das singularidades entrelaçadas quânticas do par na <ItemLink id="quantum_link" /> da
ponte de cada lado.

Elas são fabricadas provocando uma reação entre uma <ItemLink id="minecraft:ender_pearl" /> ou <ItemLink id="ender_dust" />\
e uma <ItemLink id="singularity" />. Qualquer força explosiva deve ser suficiente para iniciar a reação.

<RecipeFor id="quantum_entangled_singularity" />

***Quase qualquer explosão — até mesmo a de creepers — funciona.***

Sempre são produzidas em pares, mas exigem apenas uma <ItemLink id="singularity" />.

Pode ser uma boa ideia identificá-las com nomes ao criá-las usando uma bigorna padrão.
