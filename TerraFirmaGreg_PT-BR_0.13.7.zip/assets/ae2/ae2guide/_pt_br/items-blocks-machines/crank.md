---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Manivela de Madeira
  icon: crank
  position: 310
categories:
- machines
item_ids:
- ae2:crank
---

# A Manivela de Madeira

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/crank_on_stuff.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

A Manivela de Madeira é usada para energizar máquinas quando você não tem acesso a outra fonte de energia (ou a um <ItemLink id="energy_acceptor" />). Dificuldades do começo do jogo, não é?

## Receita

<RecipeFor id="crank" />
