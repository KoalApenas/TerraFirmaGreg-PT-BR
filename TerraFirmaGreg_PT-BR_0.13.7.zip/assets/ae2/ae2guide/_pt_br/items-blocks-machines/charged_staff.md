---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cajado Carregado
  icon: charged_staff
  position: 410
categories:
- tools
item_ids:
- ae2:charged_staff
---

# O Cajado Carregado

<ItemImage id="charged_staff" scale="4" />

O Cajado Carregado é uma haste com um <ItemLink id="charged_certus_quartz_crystal" /> na ponta. Ele causa 6 de dano e consome 300 AE
por ataque.

Sua energia pode ser recarregada em um <ItemLink id="charger" />.

## Receita

<RecipeFor id="charged_staff" />
