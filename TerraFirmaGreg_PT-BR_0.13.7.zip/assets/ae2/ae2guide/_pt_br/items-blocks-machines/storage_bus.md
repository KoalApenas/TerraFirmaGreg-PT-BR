---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ponto de Armazenamento ME
  icon: storage_bus
  position: 220
categories:
- devices
item_ids:
- ae2:storage_bus
---

# O Ponto de Armazenamento

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/storage_bus.snbt" />
</GameScene>

Sempre quis *manter* seu monstro de baús em vez de substituí-lo por algo sensato? Apresentamos o Ponto de Armazenamento!

O ponto de armazenamento transforma o inventário que toca em [armazenamento da rede](../ae2-mechanics/import-export-storage.md).
Ele faz isso permitindo que a rede veja o conteúdo daquele inventário e inserindo ou extraindo itens dele
para atender aos [dispositivos](../ae2-mechanics/devices.md) que inserem ou extraem conteúdo do armazenamento da rede.

Devido à filosofia do AE2 de criar mecânicas emergentes pela interação entre as funções dos [dispositivos](../ae2-mechanics/devices.md), você não
é obrigado a usar um ponto de armazenamento apenas para *armazenar*. Usando [sub-redes](../ae2-mechanics/subnetworks.md)
para tornar um ponto de armazenamento — ou alguns deles — o *único* armazenamento de uma rede, ele pode funcionar como origem ou destino
de transferências de itens. Consulte a [“sub-rede de tubo”](../example-setups/pipe-subnet.md).

Eles são [subpartes de cabo](../ae2-mechanics/cable-subparts.md).

## Filtragem

Por padrão, o ponto armazena tudo. Itens inseridos nos slots de filtro funcionam como uma lista branca, permitindo
armazenar apenas aqueles itens específicos.

Itens e fluidos podem ser arrastados do JEI/REI para os slots mesmo que você não possua nenhuma unidade daquele item.

Clique com o botão direito usando um recipiente de fluido, como balde ou tanque, para definir o fluido como filtro em vez do item recipiente.

## Prioridade

A prioridade pode ser definida clicando na chave inglesa no canto superior direito da interface.
Itens que entram na rede começam pelo armazenamento de maior prioridade como
seu primeiro destino. Quando dois armazenamentos possuem a mesma prioridade,
se um deles já contém o item, ele será preferido em relação a qualquer
outro. Todo armazenamento filtrado é tratado como se já contivesse o item
quando está no mesmo grupo de prioridade que outros armazenamentos. Itens removidos do armazenamento são
retirados daquele de menor prioridade. Esse sistema faz com que, à medida que itens entram e saem
do armazenamento da rede, os armazenamentos de maior prioridade sejam preenchidos e os de menor prioridade sejam esvaziados.

## Configurações

*   O ponto pode ser particionado — filtrado — de acordo com o conteúdo atual do inventário adjacente
*   É possível permitir ou impedir que a rede veja itens do inventário adjacente que o ponto não consegue extrair
    — por exemplo, um ponto de armazenamento não pode extrair itens do slot central de entrada de um <ItemLink id="inscriber" /> —
*   O ponto pode filtrar inserção e extração ou apenas inserção
*   O ponto pode ser bidirecional, somente de inserção ou somente de extração

## Melhorias

O ponto de armazenamento aceita as seguintes [melhorias](upgrade_cards.md):

*   <ItemLink id="capacity_card" /> aumenta a quantidade de slots de filtro
*   <ItemLink id="fuzzy_card" /> permite que o ponto filtre pelo nível de dano e/ou ignore o NBT do item
*   <ItemLink id="inverter_card" /> troca o filtro de lista branca para lista negra
*   <ItemLink id="void_card" /> destrói itens inseridos quando o inventário conectado está cheio, evitando o congestionamento de fazendas. Tenha cuidado ao particioná-lo!

## Receita

<RecipeFor id="storage_bus" />
