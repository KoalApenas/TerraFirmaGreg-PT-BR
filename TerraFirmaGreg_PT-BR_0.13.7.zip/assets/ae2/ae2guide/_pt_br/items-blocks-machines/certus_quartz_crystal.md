---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cristal de Quartzo Certus
  icon: certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_crystal
---

# O Cristal de Quartzo Certus

<ItemImage id="certus_quartz_crystal" scale="4" />

*"Os Cristais de Quartzo Certus possuem a característica singular de aceitar grandes quantidades de energia em sua matriz cristalina"*

Um dos principais ingredientes dos blocos, [dispositivos](../ae2-mechanics/devices.md) e itens do AE2. É obtido ao cultivá-lo a partir de [blocos geradores de Certus](../ae2-mechanics/certus-growth.md).

## Algumas Receitas Alternativas

<Recipe id="misc/deconstruction_certus_quartz_block" />

<Recipe id="transform/certus_quartz_crystals" />
