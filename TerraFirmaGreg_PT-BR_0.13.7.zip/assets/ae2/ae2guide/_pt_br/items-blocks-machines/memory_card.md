---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cartão de Memória
  icon: memory_card
  position: 410
categories:
- tools
item_ids:
- ae2:memory_card
---

# O Cartão de Memória

<ItemImage id="memory_card" scale="4" />

O Cartão de Memória é usado para copiar e colar configurações entre [dispositivos](../ae2-mechanics/devices.md) do AE2 e vincular
[túneis P2P](p2p_tunnels.md). Ele também pode inserir [cartões de melhoria](upgrade_cards.md) em dispositivos.

- Use Shift + botão direito para copiar configurações ou gerar uma nova frequência de vínculo P2P.
- Use o botão direito para colar configurações, cartões de melhoria ou a frequência de vínculo.

## Receita

<RecipeFor id="memory_card" />
