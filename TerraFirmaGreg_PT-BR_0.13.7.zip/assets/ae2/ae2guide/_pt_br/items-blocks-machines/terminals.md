---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Terminais
  icon: crafting_terminal
  position: 210
categories:
- devices
item_ids:
- ae2:terminal
- ae2:crafting_terminal
- ae2:pattern_encoding_terminal
- ae2:pattern_access_terminal
---

# Terminais

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/terminals.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Enquanto <ItemLink id="pattern_provider" />, <ItemLink id="import_bus" />, <ItemLink id="storage_bus" /> e outros semelhantes
são a principal forma de uma rede do AE2 interagir com o mundo, Terminais são a principal forma de uma rede do AE2
interagir com *você*. Existem várias versões com funções diferentes.

Terminais herdam a cor do [cabo](cables.md) no qual estão instalados.

Eles são [subpartes de cabo](../ae2-mechanics/cable-subparts.md).

## Posicionamento do Terminal

Como um terminal costuma ser a primeira [subparte](../ae2-mechanics/cable-subparts.md) que alguém instala,
é comum colocá-lo de costas por engano. Este é um exemplo do que fazer e do que não fazer:

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/terminal_placement.snbt" />
  <IsometricCamera yaw="195" pitch="30" />

  <LineAnnotation color="#ff3333" from="2.5 .5 .5" to="4.5 2.5 .5" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="2.5 2.5 .5" to="4.5 .5 .5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="-.5 2.5 .5" to="1 .5 .5" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1 .5 .5" to="1.5 1 .5" alwaysOnTop={true} thickness="0.05"/>
</GameScene>

Você ainda possui um terminal e um aceitador de energia, mas agora o terminal está voltado para o lado correto e realmente
conectado à rede, e tudo também ocupa menos espaço.

<a name="terminal-ui"></a>

# Terminal

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Seu terminal básico permite visualizar e acessar o conteúdo do [armazenamento da rede](../ae2-mechanics/import-export-storage.md)
e solicitar itens de sua instalação de [autofabricação](../ae2-mechanics/autocrafting.md).

## A Interface

A interface de um terminal básico possui várias seções.

A seção central dá acesso ao armazenamento da rede. Você pode inserir e retirar conteúdo. Existem vários
atalhos de mouse e teclado:

*   O botão esquerdo pega uma pilha; o botão direito pega metade de uma pilha.
*   Quando um item, fluido ou outro conteúdo pode ser [autofabricado](../ae2-mechanics/autocrafting.md),
    a tecla associada a “copiar bloco”, normalmente o botão do meio, abre uma interface para especificar a quantidade a fabricar. Você também pode inserir fórmulas como `3*64/2`,
    ou digitar `=32` para fabricar apenas a quantidade necessária até alcançar 32 unidades no armazenamento.
*   Manter Shift pressionado congela os itens exibidos no lugar, impedindo que se reorganizem quando as quantidades mudam ou novos itens entram no sistema.
*   Clicar com o botão direito usando um balde ou outro recipiente deposita o fluido; clicar com o botão esquerdo em um fluido no terminal usando
    um recipiente de fluido vazio retira o fluido.

A seção esquerda possui botões de configuração para:

*   Ordenar por diferentes atributos, como nome, mod e quantidade
*   Exibir conteúdo armazenado, fabricável ou ambos
*   Exibir itens, fluidos ou ambos
*   Alterar a ordem de classificação
*   Abrir a janela detalhada de configurações do terminal
*   Alterar a altura da interface do terminal

À direita, há slots para <ItemLink id="view_cell" />.

O canto superior direito da seção central — botão de martelo — abre a interface de estado da [autofabricação](../ae2-mechanics/autocrafting.md),
permitindo acompanhar o progresso das fabricações e o trabalho de cada [CPU de fabricação](crafting_cpu_multiblock.md).

## Receita

<RecipeFor id="terminal" />

<a name="crafting-terminal-ui"></a>

# Terminal de Fabricação

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/crafting_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

O Terminal de Fabricação é semelhante a um terminal comum, com as mesmas configurações e seções, mas com uma grade de fabricação adicional que é automaticamente
reabastecida pelo [armazenamento da rede](../ae2-mechanics/import-export-storage.md). Tenha cuidado ao clicar com Shift na saída!

Você deve transformar seu terminal em um terminal de fabricação assim que possível.

## A Interface

O terminal de fabricação possui a mesma interface do terminal comum, mas com uma grade de fabricação adicional no centro.

Há 2 botões adicionais: um para esvaziar a grade de fabricação no armazenamento da rede e outro para esvaziá-la no seu inventário.

## Receita

<RecipeFor id="crafting_terminal" />

<a name="pattern-encoding-terminal-ui"></a>

# Terminal de Codificação de Padrões

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/pattern_encoding_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

O Terminal de Codificação de Padrões é semelhante a um terminal comum, com as mesmas configurações e seções, mas com uma
interface de codificação de [padrões](patterns.md). Ela se parece com a interface de um terminal de fabricação, mas essa grade de fabricação não
realiza fabricações de fato.

Você deve ter um deles além de um terminal de fabricação.

## A Interface

O terminal de codificação de padrões possui a mesma interface do terminal comum, acrescida da interface de codificação de [padrões](patterns.md).

A interface de codificação de padrões possui várias seções:

Um slot para inserir <ItemLink id="blank_pattern" />s.

Uma grande seta para codificar o padrão.

Um slot para padrões codificados. Coloque nesse slot um padrão que já tenha sido codificado para editá-lo e clique na seta “codificar”.

4 abas à direita permitem alternar o tipo de padrão a ser codificado entre

*   Fabricação
*   Processamento
*   Ferraria
*   Corte de Pedra

A interface central muda conforme o tipo de padrão a ser codificado:

*   No modo de fabricação:
    *   Clique com o botão esquerdo ou arraste do JEI/REI os ingredientes para formar a receita. Clique com o botão direito para remover o ingrediente.
    *   Ativar substituições permite ações como fabricar gravetos com qualquer tipo de tábua. Isso só deve ser usado
        quando for absolutamente necessário.
    *   As substituições de fluidos permitem usar fluidos armazenados no lugar de baldes de fluido.
    *   Você também pode codificar um padrão diretamente pela tela de receitas do JEI/REI.

*   No modo de processamento:
    * Clique com o botão esquerdo ou direito, ou arraste do JEI/REI os ingredientes para especificar as entradas e saídas da receita.
    * Clique com o botão direito segurando um recipiente de fluido (como um balde ou tanque) para definir esse fluido como ingrediente no lugar do item balde ou tanque.
    * Ao segurar uma pilha, o botão esquerdo coloca a pilha inteira e o direito coloca um item. Clique com o botão esquerdo em uma pilha de ingredientes existente para
        remover a pilha inteira e com o botão direito para reduzir a pilha em 1. A tecla associada a “copiar bloco” (normalmente o botão do meio)
        permite especificar uma quantidade exata do item ou fluido.
    * Os slots de saída possuem uma saída principal e espaço para quaisquer saídas secundárias que você queira que o algoritmo de autofabricação considere.
    * Tanto os slots de entrada quanto os de saída têm rolagem, permitindo 81 ingredientes diferentes e 26 saídas secundárias
    * Você também pode codificar um padrão diretamente pela tela de receitas do JEI/REI.

*   As interfaces dos modos de ferraria e corte de pedra funcionam de forma semelhante a uma mesa de ferraria e a um cortador de pedra, respectivamente.

## Receita

<RecipeFor id="pattern_encoding_terminal" />

<a name="pattern-access-terminal-ui"></a>

# Terminal de Acesso aos Padrões

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/pattern_access_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

O Terminal de Acesso aos Padrões resolve um problema específico: em uma torre compacta de <ItemLink id="pattern_provider" />s
e <ItemLink id="molecular_assembler" />s, você não consegue acessar fisicamente os provedores para inserir novos padrões. Além disso,
talvez você esteja com preguiça e não queira atravessar sua base para inserir um [padrão](patterns.md). O terminal de acesso aos padrões
permite acessar todos os provedores de padrões da rede.

## A Interface

Este terminal possui uma interface diferente de todos os outros terminais.

Ele possui configurações para a altura do terminal e para definir quais provedores de padrões serão exibidos.

Cada linha no terminal corresponde a um provedor de padrões específico.

Os provedores de padrões no terminal são ordenados pelos blocos aos quais estão conectados ou pelo nome que você atribuiu a eles (em uma bigorna ou
com uma <ItemLink id="name_press" />).

## Receita

<RecipeFor id="pattern_access_terminal" />
