---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cristal de Fluix
  icon: fluix_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_crystal
---

# O Cristal de Fluix

<ItemImage id="fluix_crystal" scale="4" />

*“Cristais Fluix possuem a capacidade singular de absorver e converter energia de uma forma em outra e constituem a base de
toda a tecnologia de Matéria-Energia”*

Um dos principais ingredientes de blocos, [dispositivos](../ae2-mechanics/devices.md) e itens do AE2. É produzido ao jogar Quartzo do Nether, Redstone e
<ItemLink id="charged_certus_quartz_crystal" /> na água.

O processo pode ser [automatizado](../example-setups/throw-in-water-automation.md) usando um <ItemLink id="formation_plane" /> e um <ItemLink id="annihilation_plane" />.

## Receitas

<Row>
  <Recipe id="transform/fluix_crystals" />

  <Recipe id="transform/fluix_crystal" />

  <Recipe id="misc/deconstruction_fluix_block" />
</Row>
