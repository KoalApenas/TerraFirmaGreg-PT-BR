---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ponto de Exportação
  icon: export_bus
  position: 220
categories:
- devices
item_ids:
- ae2:export_bus
---

# O Ponto de Exportação

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/export_bus.snbt" />
</GameScene>

O Ponto de Exportação retira itens e fluidos (e qualquer outra coisa permitida por extensões) do [armazenamento de rede](../ae2-mechanics/import-export-storage.md)
e os insere no inventário que está tocando.

Para reduzir a defasagem, quando o Ponto de Exportação não exporta nada há algum tempo, ele entra em uma espécie de
“modo de espera”, no qual opera lentamente, e desperta e acelera até a velocidade máxima (4 operações por segundo) ao exportar algo com sucesso.

Eles são [subpartes de cabo](../ae2-mechanics/cable-subparts.md).

## Filtragem

Por padrão, o ponto não exporta nada. Itens inseridos nos espaços de filtro funcionam como uma lista de permissões,
permitindo exportar somente esses itens específicos.

Itens e fluidos podem ser arrastados do JEI/REI para os espaços mesmo que você não possua nenhuma unidade daquele item.

Clique com o botão direito usando um recipiente de fluido, como um balde ou tanque, para definir o fluido como filtro em vez do item do recipiente.

## Melhorias

O Ponto de Exportação aceita as seguintes [melhorias](upgrade_cards.md):

*   A <ItemLink id="capacity_card" /> aumenta a quantidade de espaços de filtro e disponibiliza uma configuração para definir a ordem de exportação do conteúdo filtrado.
*   A <ItemLink id="speed_card" /> aumenta a quantidade de conteúdo movido por operação
*   A <ItemLink id="fuzzy_card" /> permite filtrar pelo nível de dano e/ou ignorar o NBT do item
*   A <ItemLink id="crafting_card" /> permite que o ponto envie solicitações de fabricação ao seu sistema de [fabricação automática](../ae2-mechanics/autocrafting.md)
    para obter os itens desejados. Ele pode ser configurado para retirar os itens do armazenamento quando possível ou sempre criar uma solicitação
    de fabricação de um item novo.
*   A <ItemLink id="redstone_card" /> adiciona controle por Redstone, permitindo ativação com sinal alto, sinal baixo ou uma vez por pulso

## Velocidades

| Cartões de Aceleração | Itens Movidos por Operação |
|:-------------------|:--------------------------|
| 0                  | 1                         |
| 1                  | 8                         |
| 2                  | 32                        |
| 3                  | 64                        |
| 4                  | 96                        |

## Receita

<RecipeFor id="import_bus" />
