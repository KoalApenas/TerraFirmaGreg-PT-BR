---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Porto de Entrada/Saída Espacial
  icon: spatial_io_port
  position: 210
categories:
- devices 
item_ids:
- ae2:spatial_io_port
---

# O Porto de Entrada/Saída Espacial

<BlockImage id="spatial_io_port" p:powered="true" scale="8" />

O Porto de Entrada/Saída Espacial é usado na [E/S espacial](../ae2-mechanics/spatial-io.md) para alojar a [célula espacial](spatial_cells.md)
e controlar a operação de E/S espacial.

A célula pode ser inserida e extraída por qualquer logística de itens, como funis ou pontos do AE2, caso você queira automatizar o processo.

## Receita

<RecipeFor id="spatial_io_port" />
