---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Aceitador de Energia
  icon: energy_acceptor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_acceptor
---

# O Aceitador de Energia

<Row gap="20">
<BlockImage id="energy_acceptor" scale="8" /> 

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_energy_acceptor.snbt" />
</GameScene>
</Row>

O Aceitador de Energia converte formas comuns de energia de outros mods tecnológicos na forma interna de [energia](../ae2-mechanics/energy.md) do AE2,
AE. Embora o <ItemLink id="controller" /> também possa fazer isso, as faces do Controlador são valiosas; por isso, geralmente é melhor usar um
Aceitador de Energia.

As proporções de conversão da Energia Forge e da Energia TechReborn são

*   2 FE = 1 AE (Forge)
*   1 E  = 2 AE (Fabric)

A velocidade de conversão depende totalmente da quantidade de AE que sua rede consegue armazenar, pelos motivos explicados
[nesta página](../ae2-mechanics/energy.md).

## Variantes

Aceitadores de Energia possuem 2 variantes: normal e plana/[subparte](../ae2-mechanics/cable-subparts.md). Isso permite criar configurações mais compactas.

Aceitadores de Energia podem ser alternados entre as formas normal e plana em uma grade de fabricação.

## Receita

<RecipeFor id="energy_acceptor" />

<RecipeFor id="cable_energy_acceptor" />
