---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Manual
  icon: guide
categories:
- tools
item_ids:
- ae2:guide
---

# O Manual

<ItemImage id="guide" scale="8" />

### Este é o manual que você está lendo agora, para todas as suas necessidades de orientação sobre o AE2.

* Acesse a barra lateral à esquerda para encontrar o índice
* Muitas páginas possuem cenas interativas. Se uma cena tiver os botões ![Mais](../assets/diagrams/plus.png)
  e ![Menos](../assets/diagrams/minus.png) (zoom) ao lado, você poderá girar e mover a câmera.
  Clique com o botão esquerdo e arraste para girar; clique com o botão direito e arraste para deslocar.

## Receita

<RecipeFor id="guide" />
