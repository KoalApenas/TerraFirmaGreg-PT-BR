---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Pó de Fluix
  icon: fluix_dust
  position: 010
categories:
- misc ingredients blocks
categories:
- network infrastructure
item_ids:
- ae2:fluix_dust
---

# Pó de Fluix

<ItemImage id="fluix_dust" scale="4" />

Um <ItemLink id="fluix_crystal" /> triturado por um <ItemLink id="inscriber" />. É usado na produção de
várias máquinas e componentes do AE2.

## Receita

<RecipeFor id="fluix_dust" />
