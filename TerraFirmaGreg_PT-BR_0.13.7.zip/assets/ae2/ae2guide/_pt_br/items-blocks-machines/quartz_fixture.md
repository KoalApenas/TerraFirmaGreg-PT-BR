---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Luminárias de Quartzo
  icon: quartz_fixture
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_fixture
- ae2:light_detector
---

# Luminárias de Quartzo

<Row>
<BlockImage id="quartz_fixture" scale="8" />

<BlockImage id="light_detector" scale="8" />
</Row>

A luminária de quartzo carregado é um pequeno detalhe decorativo que emite luz.

Já a luminária detectora de luz emite um sinal de redstone conforme o nível de luz do bloco onde está instalada.

## Receitas

<RecipeFor id="quartz_fixture" />

<RecipeFor id="light_detector" />
