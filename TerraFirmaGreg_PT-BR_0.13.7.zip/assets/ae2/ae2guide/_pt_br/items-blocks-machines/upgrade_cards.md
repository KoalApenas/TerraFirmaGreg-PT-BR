---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cartões de Melhoria
  icon: speed_card
  position: 410
categories:
- tools
item_ids:
- ae2:basic_card
- ae2:advanced_card
- ae2:redstone_card
- ae2:capacity_card
- ae2:void_card
- ae2:fuzzy_card
- ae2:speed_card
- ae2:inverter_card
- ae2:crafting_card
- ae2:equal_distribution_card
- ae2:energy_card
- ae2:auto_complete_card
---

# Cartões de Melhoria

<Row>
  <ItemImage id="redstone_card" scale="2" />

  <ItemImage id="capacity_card" scale="2" />

  <ItemImage id="void_card" scale="2" />

  <ItemImage id="fuzzy_card" scale="2" />

  <ItemImage id="speed_card" scale="2" />

  <ItemImage id="inverter_card" scale="2" />

  <ItemImage id="crafting_card" scale="2" />

  <ItemImage id="equal_distribution_card" scale="2" />

  <ItemImage id="energy_card" scale="2" />

  <ItemImage id="auto_complete_card" scale="2" />
</Row>

Os cartões de melhoria alteram o comportamento dos [dispositivos](../ae2-mechanics/devices.md) e das máquinas do AE2, aumentando sua velocidade, ampliando sua
capacidade de filtragem, habilitando controle por redstone etc.

## Componentes de Cartão

<Row>
  <ItemImage id="basic_card" scale="2" />

  <ItemImage id="advanced_card" scale="2" />
</Row>

Os cartões são fabricados com bases de cartão básicas ou avançadas

<Row>
  <RecipeFor id="basic_card" />

  <RecipeFor id="advanced_card" />
</Row>

## Cartão de Redstone

<ItemImage id="redstone_card" scale="2" />

Cartões de Redstone adicionam controle por Redstone e um botão à interface do dispositivo para alternar entre várias condições de Redstone.

<RecipeFor id="redstone_card" />

## Cartão de Capacidade

<ItemImage id="capacity_card" scale="2" />

Cartões de Capacidade aumentam a quantidade de espaços de filtro nos pontos de importação, exportação e armazenamento, bem como nos planos de formação.

<RecipeFor id="capacity_card" />

## Cartão de Destruição de Sobras

<ItemImage id="void_card" scale="2" />

Cartões de Destruição de Sobras podem ser aplicados a [células de armazenamento](storage_cells.md) em uma <ItemLink id="cell_workbench" />
e excluirão os itens recebidos caso a célula esteja cheia. (Não se esqueça de [particionar](cell_workbench.md) suas células!) Quando combinado com um Cartão de Distribuição Igualitária,
um item será descartado se a seção específica dele na célula estiver cheia, mesmo que as seções de outros itens estejam vazias.

<RecipeFor id="void_card" />

## Cartão de Imprecisão

<ItemImage id="fuzzy_card" scale="2" />

Cartões de Imprecisão permitem que dispositivos e ferramentas com filtros considerem o nível de dano e/ou ignorem o NBT dos itens, permitindo exportar
todos os machados de ferro independentemente do dano e dos encantamentos, ou apenas espadas de diamante danificadas, sem exportar as totalmente reparadas.

Abaixo há um exemplo de como funcionam os modos de comparação de Dano Impreciso: à esquerda está a
configuração do ponto, e na parte superior está o item comparado.

| 25%                    | Picareta com 10% de Dano | Picareta com 30% de Dano | Picareta com 80% de Dano | Picareta Totalmente Reparada |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| Picareta Quase Quebrada | ✅                   | \*\*\*\*            | \*\*\*\*            | \*\*\*\*            |
| Picareta Totalmente Reparada | \*\*\*\*            | ✅                   | ✅                   | ✅                   |

| 50%                    | Picareta com 10% de Dano | Picareta com 30% de Dano | Picareta com 80% de Dano | Picareta Totalmente Reparada |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| Picareta Quase Quebrada | ✅                   | ✅                   | \*\*\*\*            | \*\*\*\*            |
| Picareta Totalmente Reparada | \*\*\*\*            | \*\*\*\*            | ✅                   | ✅                   |

| 75%                    | Picareta com 10% de Dano | Picareta com 30% de Dano | Picareta com 80% de Dano | Picareta Totalmente Reparada |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| Picareta Quase Quebrada | ✅                   | ✅                   | \*\*\*\*            | \*\*\*\*            |
| Picareta Totalmente Reparada | \*\*\*\*            |                     | ✅                   | ✅                   |

| 99%                    | Picareta com 10% de Dano | Picareta com 30% de Dano | Picareta com 80% de Dano | Picareta Totalmente Reparada |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| Picareta Quase Quebrada | ✅                   | ✅                   | ✅                   | \*\*\*\*            |
| Picareta Totalmente Reparada | \*\*\*\*            | \*\*\*\*            | \*\*\*\*            | ✅                   |

| Ignorar                | Picareta com 10% de Dano | Picareta com 30% de Dano | Picareta com 80% de Dano | Picareta Totalmente Reparada |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| Picareta Quase Quebrada | ✅                   | ✅                   | ✅                   | **✅**               |
| Picareta Totalmente Reparada | **✅**               | **✅**               | **✅**               | ✅                   |

<RecipeFor id="fuzzy_card" />

## Cartão de Aceleração

<ItemImage id="speed_card" scale="2" />

Cartões de Aceleração fazem as coisas funcionarem mais depressa: pontos de importação e exportação movem mais itens por operação, enquanto Inscritores
e Montadores Moleculares trabalham mais rápido.

<RecipeFor id="speed_card" />

## Cartão Inversor

<ItemImage id="inverter_card" scale="2" />

Cartões Inversores alternam os filtros de dispositivos e ferramentas entre lista de permissões e lista de bloqueio.

<RecipeFor id="inverter_card" />

## Cartão de Fabricação

<ItemImage id="crafting_card" scale="2" />

Cartões de Fabricação permitem que o dispositivo envie solicitações ao sistema de [fabricação automática](../ae2-mechanics/autocrafting.md)
para obter os itens desejados.

<RecipeFor id="crafting_card" />

## Cartão de Distribuição Igualitária

<ItemImage id="equal_distribution_card" scale="2" />

Cartões de Distribuição Igualitária podem ser aplicados a [células de armazenamento](storage_cells.md) em uma <ItemLink id="cell_workbench" /> e
dividem a célula em seções do mesmo tamanho de acordo com o [particionamento](cell_workbench.md) do cartão. Isso impede que um único tipo de item
preencha toda a célula.

<RecipeFor id="equal_distribution_card" />

## Cartão de Energia

<ItemImage id="energy_card" scale="2" />

Cartões de Energia aumentam o armazenamento de energia de certas ferramentas, como terminais portáteis, e tornam a <ItemLink id="vibration_chamber" />
mais eficiente.

<RecipeFor id="energy_card" />

## Cartão de Autocompletar

<ItemImage id="auto_complete_card" scale="2" />

Cartões de Autocompletar são uma melhoria para Provedores de Padrões;
eles marcam uma fabricação como concluída assim que todas as entradas necessárias do padrão forem enviadas.

<RecipeFor id="auto_complete_card" />
