---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ferramentas de Fluix
  icon: fluix_pickaxe
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_axe
- ae2:fluix_hoe
- ae2:fluix_shovel
- ae2:fluix_pickaxe
- ae2:fluix_sword
---

# Ferramentas de Fluix

<Row>
  <ItemImage id="fluix_axe" scale="4" />

  <ItemImage id="fluix_hoe" scale="4" />

  <ItemImage id="fluix_shovel" scale="4" />

  <ItemImage id="fluix_pickaxe" scale="4" />

  <ItemImage id="fluix_sword" scale="4" />
</Row>

As ferramentas de [Fluix](fluix_crystal.md) são semelhantes às de ferro, mas possuem 3x a durabilidade, além de dano de ataque e velocidade de mineração ligeiramente maiores.

Todas as ferramentas de Fluix agem como se tivessem pelo menos Fortuna/Pilhagem 1, algo útil antes de você obter acesso a uma mesa de encantamentos.

Você precisará produzir um <ItemLink id="fluix_upgrade_smithing_template" />

## Receitas

<Column>
  <Row>
    <RecipeFor id="fluix_axe" />

    <RecipeFor id="fluix_hoe" />

    <RecipeFor id="fluix_shovel" />
  </Row>

  <Row>
    <RecipeFor id="fluix_pickaxe" />

    <RecipeFor id="fluix_sword" />
  </Row>
</Column>
