---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Provedor de Padrões
  icon: pattern_provider
  position: 210
categories:
- devices
item_ids:
- ae2:pattern_provider
- ae2:cable_pattern_provider
---

# O Provedor de Padrões

<Row gap="20">
<BlockImage id="pattern_provider" scale="8" />
<BlockImage id="pattern_provider" p:push_direction="up" scale="8" />
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_pattern_provider.snbt" />
</GameScene>
</Row>

Provedores de Padrões são a principal forma de seu sistema de [autofabricação](../ae2-mechanics/autocrafting.md) interagir com o mundo. Eles enviam os ingredientes de
seus [padrões](patterns.md) aos inventários adjacentes, e itens podem ser inseridos neles para entrar na rede. Muitas vezes,
é possível economizar um canal conduzindo a saída de uma máquina de volta a um provedor próximo — geralmente o mesmo que enviou os ingredientes —
em vez de usar um <ItemLink id="import_bus" /> para puxar a saída da máquina para a rede.

É importante notar que, como eles enviam ingredientes diretamente do [armazenamento de fabricação](crafting_cpu_multiblock.md#crafting-storage) de uma CPU de fabricação,
os ingredientes nunca ficam no inventário do provedor; portanto, não é possível extraí-los com tubos. O provedor precisa enviá-los
a outro inventário, como um barril, do qual serão retirados.

Também é importante notar que o provedor precisa enviar TODOS os ingredientes de uma só vez; ele não consegue enviar lotes parciais. Isso pode ser útil
e explorado de várias maneiras.

Provedores de Padrões possuem uma interação especial com interfaces em [sub-redes](../ae2-mechanics/subnetworks.md): se a interface não estiver modificada — nada nos slots de solicitação —,
o provedor ignora a interface por completo e envia diretamente ao [armazenamento](../ae2-mechanics/import-export-storage.md) daquela sub-rede,
sem preencher a interface com lotes da receita e, principalmente, sem inserir o lote seguinte até haver espaço na máquina.
Isso funciona corretamente no modo de bloqueio: o provedor monitora os slots da máquina em busca de ingredientes, e não os slots da interface.

Por exemplo, esta instalação envia o item a ser fundido e o combustível diretamente aos slots correspondentes da fornalha.
Você pode usar isso para fornecer padrões a vários lados de uma máquina ou a várias máquinas.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/furnace_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Provedor de Padrões: variante direcional, obtida com uma chave de quartzo Certus, contendo os padrões de processamento relevantes.

        ![Padrão de Ferro](../assets/diagrams/furnace_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (2) Interface: em sua configuração padrão.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="1.3 2 1">
        (3) Ponto de Armazenamento nº 1: filtrado para carvão.
        <ItemImage id="minecraft:coal" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 2 0" max="1 2.3 1">
        (4) Ponto de Armazenamento nº 2: configurado para colocar carvão na lista negra usando um cartão inversor.
        <Row><ItemImage id="minecraft:coal" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        Para a Rede Principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Esta é uma ilustração geral do fornecimento a várias máquinas.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        Interface — deve ser plana, não um bloco inteiro
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        Pontos de Armazenamento
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        Locais aos quais você deseja fornecer padrões
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

Vários provedores de padrões com padrões idênticos são aceitos e funcionam em paralelo.

Provedores de padrões tentam distribuir seus lotes alternadamente entre todas as faces, usando assim todas as máquinas conectadas em paralelo.

## Variantes

Provedores de Padrões possuem 3 variantes: normal, direcional e plana, ou [subparte](../ae2-mechanics/cable-subparts.md). Isso afeta os lados específicos aos quais eles enviam
ingredientes, dos quais recebem itens e aos quais fornecem conexão de rede.

*   Provedores de padrões normais enviam ingredientes e recebem entradas por todos os lados e, como a maioria das máquinas do AE2, funcionam
    como um cabo que fornece conexão de rede a todos os lados.

*   Provedores direcionais são criados usando uma <ItemLink id="certus_quartz_wrench" /> em um provedor normal para alterar sua
    direção. Eles enviam ingredientes apenas ao lado selecionado, recebem entradas de todos os lados e especificamente não fornecem conexão de rede
    no lado selecionado. Isso permite enviar conteúdo a máquinas do AE2 sem conectar as redes, caso você queira criar uma sub-rede.

*   Provedores planos são [subpartes de cabo](../ae2-mechanics/cable-subparts.md), portanto vários podem ser colocados no mesmo cabo, permitindo instalações compactas.
    Eles funcionam como o lado selecionado de um provedor direcional: fornecem padrões, recebem entradas e **não**
    fornecem conexão de rede em sua face.

Provedores de padrões podem ser convertidos entre as versões normal e plana em uma grade de fabricação.

## Configurações

Provedores de padrões possuem vários modos:

*   O **Modo de Bloqueio** impede que o provedor envie um novo lote de ingredientes quando já houver
    ingredientes na máquina.
*   **Bloquear Fabricação** pode bloquear o provedor sob várias condições de redstone ou até que o resultado da
    fabricação anterior seja inserido naquele provedor de padrões específico.
*   O provedor pode ser exibido ou ocultado em <ItemLink id="pattern_access_terminal" />.

## Prioridade

A prioridade pode ser definida clicando na chave inglesa no canto superior direito da interface. Quando existem vários [padrões](patterns.md)
para o mesmo item, os padrões de provedores com prioridade maior são usados antes daqueles de prioridade menor,
exceto quando a rede não possui os ingredientes do padrão de maior prioridade.

## Um Equívoco Comum

Por algum motivo, as pessoas continuam fazendo isto. Não entendo por quê, mas incluí esta explicação para tentar ajudar. Talvez
elas pensem, por engano, que um <ItemLink id="export_bus" /> é a única forma de algo sair da rede, sem saber
que provedores de padrões também exportam conteúdo.

Isto não fará o que você espera. Como explicado em [cabos](cables.md), cabos não são tubos de itens e não possuem inventário
interno; provedores não enviam itens para dentro deles.

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_1.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        Não É um Alto-forno
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

Como o provedor não possui nenhum destino para o qual enviar conteúdo, ele
não consegue funcionar. Tudo o que faz aqui é agir como um cabo, conectando o <ItemLink id="export_bus" /> à
rede.

O provedor tampouco informa magicamente ao <ItemLink id="export_bus" /> o que exportar; o ponto de exportação simplesmente exportará
tudo o que for colocado em seu filtro.

Na prática, o que fizemos aqui foi isto:

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_2.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        Não É um Alto-forno
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

Provavelmente, o que você realmente deseja construir é isto, em que o provedor de padrões pode exportar o conteúdo dos padrões para
a máquina adjacente:

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_3.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        Não É um Alto-forno
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

## Receitas

<RecipeFor id="pattern_provider" />

<RecipeFor id="cable_pattern_provider" />
