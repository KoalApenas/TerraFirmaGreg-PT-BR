---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Facas de Corte
  icon: certus_quartz_cutting_knife
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_cutting_knife
- ae2:nether_quartz_cutting_knife
---

# Ferramentas de Quartzo

<Row>
  <ItemImage id="certus_quartz_cutting_knife" scale="4" />

  <ItemImage id="nether_quartz_cutting_knife" scale="4" />
</Row>

Facas de corte são usadas para produzir a <ItemLink id="name_press" /> e a <ItemLink id="cable_anchor" />.

Para fabricar uma prensa de nome, clique com o botão direito na faca de corte e insira um lingote metálico; depois, digite o nome que
deseja gravar na placa e simplesmente retire a placa pronta.

## Receitas

<Row>
  <RecipeFor id="certus_quartz_cutting_knife" />

  <RecipeFor id="nether_quartz_cutting_knife" />
</Row>
