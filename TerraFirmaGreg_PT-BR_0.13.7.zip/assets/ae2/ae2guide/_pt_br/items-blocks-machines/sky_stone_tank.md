---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Tanque de Pedra Celeste
  icon: sky_stone_tank
  position: 310
categories:
- machines
item_ids:
- ae2:sky_stone_tank
---

# O Tanque de Pedra Celeste

<BlockImage id="sky_stone_tank" scale="8" />

É um tanque de fluido que armazena 16 baldes. Ele não mantém o conteúdo quando é recolhido. Não há muito mais a dizer.

## Receita

<RecipeFor id="sky_stone_tank" />
