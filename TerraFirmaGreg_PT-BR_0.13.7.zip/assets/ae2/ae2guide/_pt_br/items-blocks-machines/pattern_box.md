---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Caixa de Padrões
  icon: pattern_box
  position: 411
categories:
- tools
item_ids:
- ae2:pattern_box
---

# Caixa de Padrões

<ItemImage id="pattern_box" scale="4" />

A Caixa de Padrões se parece um pouco com a [Ferramenta de Rede](network_tool.md), mas armazena e transporta [Padrões Codificados](patterns.md) em vez de [Cartões de Melhoria](upgrade_cards.md).

Ela possui 27 slots para armazenar, bem... [Padrões Codificados](patterns.md), que ficam disponíveis na interface de qualquer dispositivo do AE2 enquanto a ferramenta
estiver em qualquer lugar de seu inventário.
