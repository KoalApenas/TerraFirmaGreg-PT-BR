---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Condensador de Matéria
  icon: condenser
  position: 310
categories:
- machines
item_ids:
- ae2:condenser
---

# O Condensador de Matéria

<BlockImage id="condenser" scale="8" />

O Condensador de Matéria pode ser usado como lixeira ou para criar <ItemLink id="matter_ball" />s e
[singularidades](singularities.md). Ele aceita qualquer item, fluido ou outro conteúdo que uma célula de armazenamento possa guardar.

## Configurações/Receitas

*   No modo lixeira, o Condensador de Matéria simplesmente elimina tudo o que entra nele
*   No modo bola de matéria, o condensador transforma em <ItemLink id="matter_ball" />s tudo o que você inserir.
    Esse modo exige que você coloque um componente de armazenamento no espaço superior do condensador. Cada bola de matéria consome 256 itens ou baldes;
    portanto, um <ItemLink id="cell_component_1k" /> (que fornece 8192 bits de capacidade) é mais do que suficiente.
*   No modo singularidade de matéria, o condensador transforma em [singularidades](singularities.md) tudo o que você inserir.
    Esse modo exige que você coloque um componente de armazenamento no espaço superior do condensador. Cada singularidade consome 256,000 itens ou baldes;
    portanto, um <ItemLink id="cell_component_64k" /> (que fornece 524,288 bits de capacidade) é mais do que suficiente.

Observe que, nos dois últimos modos, em que um recurso é produzido, o Condensador de Matéria *pode* ficar obstruído e
deixará de aceitar novas entradas se os buffers de energia e do item produzido estiverem completamente cheios.

## Receita

<RecipeFor id="condenser" />
