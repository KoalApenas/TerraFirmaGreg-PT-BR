---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cubo Misterioso
  icon: mysterious_cube
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:mysterious_cube
- ae2:not_so_mysterious_cube
---

# O Cubo Misterioso

<BlockImage id="mysterious_cube" scale="8" />

Lembra quando era necessário encontrar vários meteoros para conseguir todas as prensas? Isso acabou! Agora os meteoritos vêm com um Cubo Misterioso.

O que será que acontece ao quebrá-lo sem Toque Suave...

Você também pode fabricar uma réplica: o Cubo Não Tão Misterioso.

## Receita

<RecipeFor id="not_so_mysterious_cube" />
