---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Interface
  icon: interface
  position: 210
categories:
- devices
item_ids:
- ae2:interface
- ae2:cable_interface
---

# A Interface

<Row gap="20">
<BlockImage id="interface" scale="8" />
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_interface.snbt" />
</GameScene>
</Row>

Interfaces funcionam como pequenos baús e tanques de fluido que se abastecem e esvaziam usando o [armazenamento da rede](../ae2-mechanics/import-export-storage.md)
de acordo com o estoque configurado em seus slots. Elas tentam concluir isso em um único tick de jogo, portanto podem se abastecer com
ou esvaziar até 9 pilhas por tick de jogo, sendo um método rápido de importação ou exportação quando você possui tubos de itens velozes.

Outra característica útil é que, enquanto a maioria dos tanques armazena apenas 1 tipo de fluido, interfaces armazenam até 9 tipos, além de itens.
Elas são basicamente baús ou tanques para vários fluidos com algumas funções adicionais; você pode impedir essas funções mantendo-as
desconectadas de qualquer rede.
Assim, elas são úteis em situações específicas nas quais se deseja armazenar pequenas quantidades de muitos tipos diferentes de conteúdo.

## Funcionamento Interno de uma Interface

Como mencionado, uma interface é basicamente um baú ou tanque com vários <ItemLink id="import_bus" /> superpotentes e
<ItemLink id="export_bus" /> superpotentes conectados, além de vários <ItemLink id="level_emitter" />.

<GameScene zoom="3" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_internals.snbt" />

  <BoxAnnotation color="#dddddd" min="1.3 0.3 1.3" max="9.7 1 1.7">
        Vários emissores de nível para controlar a quantidade solicitada em estoque
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/level_emitter.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 4 1.3" max="9.7 4.7 1.7">
        Vários emissores de nível para controlar a quantidade solicitada em estoque
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/level_emitter.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 1.3 1.3" max="9.7 2 1.7">
        Vários pontos de importação superpotentes capazes de transferir 1 pilha por tick de jogo
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/import_bus.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 3 1.3" max="9.7 3.7 1.7">
        Vários pontos de exportação superpotentes capazes de transferir 1 pilha por tick de jogo
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/export_bus.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 1" max="10 3 2">
        9 slots internos separados
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="15" />
</GameScene>

## Interações Especiais

Interfaces também possuem algumas funções especiais com outros [dispositivos](../ae2-mechanics/devices.md) do AE2:

Um <ItemLink id="storage_bus" /> em uma interface não configurada apresenta todo o [armazenamento da rede](../ae2-mechanics/import-export-storage.md)
de sua rede à rede do ponto de armazenamento, como se a rede da interface fosse um grande baú no qual o ponto estivesse conectado.
Configurar um item para ser mantido nos slots de filtro da interface desativa esse comportamento.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_storage.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Provedores de Padrões possuem uma interação especial com interfaces em [sub-redes](../ae2-mechanics/subnetworks.md): se a interface não estiver configurada,
o provedor ignora a interface por completo e envia diretamente ao [armazenamento](../ae2-mechanics/import-export-storage.md) daquela sub-rede,
sem preencher a interface com lotes da receita e, principalmente, sem inserir o lote seguinte até haver espaço no armazenamento.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        Interface — deve ser plana, não um bloco inteiro
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        Pontos de Armazenamento
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        Locais aos quais você deseja fornecer padrões — várias máquinas ou várias faces de 1 máquina
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## Variantes

Interfaces possuem 2 variantes: normal e plana, ou [subparte](../ae2-mechanics/cable-subparts.md). Isso afeta os lados específicos pelos quais seus inventários podem ser acessados
e aos quais fornecem conexão de rede.

*   Interfaces normais permitem inserir, extrair e acessar o inventário por todos os lados e, como a maioria das máquinas do AE2, funcionam
    como um cabo que fornece conexão de rede a todos os lados.

*   Interfaces planas são [subpartes de cabo](../ae2-mechanics/cable-subparts.md), portanto várias podem ser colocadas no mesmo cabo, permitindo instalações compactas.
    Elas permitem inserir, extrair e acessar o inventário pela face frontal, mas não fornecem conexão de rede nessa face.

Interfaces podem ser convertidas entre as versões normal e plana em uma grade de fabricação.

## Configurações

Os slots superiores da interface determinam o estoque que ela manterá internamente. Quando algo é colocado
neles ou arrastado do JEI/REI, aparece uma chave inglesa que permite definir a quantidade.

Clique com o botão direito usando um recipiente de fluido, como balde ou tanque, para definir o fluido como filtro em vez do item recipiente.

## Melhorias

A interface aceita as seguintes [melhorias](upgrade_cards.md):

*   <ItemLink id="fuzzy_card" /> permite que o ponto filtre pelo nível de dano e/ou ignore o NBT do item
*   <ItemLink id="crafting_card" /> permite que a interface envie solicitações de fabricação ao seu sistema de [autofabricação](../ae2-mechanics/autocrafting.md)
    para obter os itens desejados. Se possível, ela retira os itens do armazenamento antes de fazer uma solicitação
    para fabricar um novo item.

## Prioridade

A prioridade pode ser definida clicando na chave inglesa no canto superior direito da interface. Interfaces com prioridade maior recebem seus itens
antes daquelas com prioridade menor,

## Receitas

<Recipe id="network/blocks/interfaces_interface" />

<RecipeFor id="cable_interface" />
