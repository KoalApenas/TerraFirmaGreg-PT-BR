---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fibra de Quartzo
  icon: quartz_fiber
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:quartz_fiber
---

# A Fibra de Quartzo

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/quartz_fiber.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

A fibra de quartzo compartilha energia entre [redes](../ae2-mechanics/me-network-connections.md), mantendo-as separadas. Isso permite alimentar
[sub-redes](../ae2-mechanics/subnetworks.md)
sem colocar aceitadores de energia e cabos elétricos por toda parte. Ela também pode impedir que cabos se conectem,
embora usar cabos de cores diferentes ou um <ItemLink id="cable_anchor" /> seja mais barato e eficiente.

Elas são [subpartes de cabo](../ae2-mechanics/cable-subparts.md).

## Receita

<RecipeFor id="quartz_fiber" />
