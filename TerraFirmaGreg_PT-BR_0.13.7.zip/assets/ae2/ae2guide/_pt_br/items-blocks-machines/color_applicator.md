---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Aplicador de Cores
  icon: color_applicator
  position: 410
categories:
- tools
item_ids:
- ae2:color_applicator
---

# O Aplicador de Cores

<ItemImage id="color_applicator" scale="4" />

O Aplicador de Cores é usado para pintar blocos coloríveis, como [cabos](cables.md), lã, terracota, vidro e concreto. Ele usa
[bolas de tinta](paintballs.md) ou corantes; bolas de neve podem ser usadas para remover a cor dos cabos e as manchas de bolas de tinta dos blocos.

Sua energia pode ser recarregada em um <ItemLink id="charger" />.

Os Aplicadores de Cores funcionam como [células de armazenamento](storage_cells.md), e seu armazenamento de tinta pode ser preenchido facilmente ao colocar
o aplicador no espaço de célula de armazenamento de um <ItemLink id="chest" />.

Para usar um Aplicador de Cores, clique com o botão direito para aplicar e use Shift + roda do mouse para alternar entre as bolas de tinta e os corantes armazenados.

## Melhorias

Os Aplicadores de Cores aceitam as seguintes [melhorias](upgrade_cards.md), inseridas por meio de uma <ItemLink id="cell_workbench" />:

*   <ItemLink id="equal_distribution_card" /> reserva a mesma quantidade de bytes da célula para cada tipo, impedindo que um tipo ocupe a célula inteira
*   <ItemLink id="void_card" /> elimina os itens inseridos se a célula estiver cheia (ou se o espaço reservado àquele tipo específico estiver cheio,
    no caso de um cartão de distribuição igualitária). Tenha cuidado ao particionar a célula!
*   <ItemLink id="energy_card" /> aumenta a capacidade da bateria

## Receita

<RecipeFor id="color_applicator" />
