---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ponte Quântica
  icon: quantum_ring
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:quantum_link
- ae2:quantum_ring
---

# A Ponte de Rede Quântica

![Uma Ponte de Rede Quântica formada](../assets/diagrams/quantum_bridge_demonstration.png)

Pontes de Rede Quântica podem estender uma [rede](../ae2-mechanics/me-network-connections.md) por distâncias infinitas e até entre dimensões.
Elas transportam 32 canais no total, independentemente de como os cabos estão conectados a cada face, funcionando essencialmente
como um [cabo denso](cables.md#dense-cable) sem fio.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/quantum_bridge_internal_structure_1.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/quantum_bridge_internal_structure_2.snbt" />

  <BoxAnnotation color="#33dd33" min="1 1 1" max="6 2 3">
        Um cabo imaginário entre as duas extremidades
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

É importante notar que **os dois lados precisam permanecer carregados**; portanto, um <ItemLink id="spatial_anchor" /> ou outro carregador de chunks deve ser usado
quando os 2 lados estão muito distantes.

# Anel Quântico

<BlockImage id="quantum_ring" scale="8" />

Oito destes blocos colocados ao redor de uma <ItemLink id="quantum_link" /> criam uma
Ponte de Rede Quântica. Apenas os 4 blocos <ItemLink id="quantum_ring" /> adjacentes à
<ItemLink id="quantum_link" /> aceitam conexões de rede;
os 4 blocos dos cantos não podem se conectar a cabos.

## Receita

<RecipeFor id="quantum_ring" />

# Câmara de Ligação Quântica

<BlockImage id="quantum_link" scale="8" />

Um destes blocos cercado por um <ItemLink id="quantum_ring" />
cria uma Ponte de Rede Quântica. Este bloco não se conecta a nenhum cabo e só é registrado
como parte da rede quando a ponte completa está formada.

O inventário deste bloco comporta apenas uma <ItemLink id="quantum_entangled_singularity" /> e pode
ser acessado por automação.

## Receita

<RecipeFor id="quantum_link" />
