---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ferramenta de Rede
  icon: network_tool
  position: 410
categories:
- tools
item_ids:
- ae2:network_tool
---

# Ferramenta de Rede

<ItemImage id="network_tool" scale="4" />

A Ferramenta de Rede é uma [chave inglesa](wrench.md) modificada que também exibe informações de diagnóstico da rede e armazena [cartões de melhoria](upgrade_cards.md).
Embora mantenha a capacidade da chave inglesa de desmontar coisas rapidamente e remover [subpartes](../ae2-mechanics/cable-subparts.md)
de um cabo, ela não consegue girar blocos.

Ela possui 9 slots para armazenar [cartões de melhoria](upgrade_cards.md), que ficam disponíveis na interface de qualquer dispositivo do AE2 enquanto a ferramenta
estiver em qualquer lugar de seu inventário.

Clicar com o botão direito em qualquer parte de uma rede exibe uma janela de diagnóstico semelhante à aberta ao clicar em um <ItemLink id="controller" />.
Essa janela exibe:

*   A quantidade de canais em uso na rede
*   Uma opção para alternar a exibição global de energia entre AE e E/FE
*   A quantidade de [energia](../ae2-mechanics/energy.md) armazenada na rede e sua capacidade máxima
*   A quantidade de energia que entra na rede e é consumida por ela
*   Uma lista de todos os [dispositivos](../ae2-mechanics/devices.md) e componentes da rede

Essa janela também ajuda a determinar se dois cabos ou dispositivos diferentes pertencem à mesma rede durante a configuração de
[sub-redes](../ae2-mechanics/subnetworks.md).

## Ocultando Fachadas

<a href="facades.md">Fachadas</a> ficam ocultas enquanto você segura uma ferramenta de rede em qualquer uma das mãos.

É possível interagir com os blocos atrás das fachadas ocultas sem precisar removê-las primeiro.

## Receita

<RecipeFor id="network_tool" />
