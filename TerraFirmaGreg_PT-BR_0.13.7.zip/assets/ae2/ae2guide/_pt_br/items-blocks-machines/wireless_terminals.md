---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Terminais Sem Fio
  icon: wireless_crafting_terminal
  position: 410
categories:
- tools
item_ids:
- ae2:wireless_terminal
- ae2:wireless_crafting_terminal
---

# Terminais Sem Fio

<Row>
  <ItemImage id="wireless_terminal" scale="4" />

  <ItemImage id="wireless_crafting_terminal" scale="4" />
</Row>

Terminais sem fio são versões portáteis dos [terminais](terminals.md) comuns conectados por cabo. Suas interfaces são idênticas às dos
equivalentes com fio, mas, em vez de espaços para <ItemLink id="view_cell" />, possuem espaços para [cartões de melhoria](upgrade_cards.md).

Para vinculá-los a uma rede, insira o terminal no espaço superior direito de um <ItemLink id="wireless_access_point" />
conectado àquela rede. (É o espaço com a imagem de um terminal sem fio e uma seta abaixo.)

Para funcionar, eles precisam estar dentro do alcance de um <ItemLink id="wireless_access_point" />.

Sua energia pode ser recarregada em um <ItemLink id="charger" />.

# Terminal Sem Fio

<ItemImage id="wireless_terminal" scale="4" />

Seu terminal básico, agora portátil! Visualize e acesse o conteúdo do [armazenamento da rede](../ae2-mechanics/import-export-storage.md)
e solicite itens ao sistema de [fabricação automática](../ae2-mechanics/autocrafting.md) de qualquer ponto dentro do alcance de um
<ItemLink id="wireless_access_point" />.

## A Interface

Consulte [terminais](terminals.md).

## Melhorias

O Terminal Sem Fio aceita as seguintes [melhorias](upgrade_cards.md):

*   <ItemLink id="energy_card" /> para aumentar a capacidade da bateria

## Receita

<RecipeFor id="wireless_terminal" />

# Terminal de Fabricação Sem Fio

<ItemImage id="wireless_crafting_terminal" scale="4" />

O Terminal de Fabricação Sem Fio é semelhante ao terminal sem fio comum, com as mesmas configurações e seções, mas possui uma grade de fabricação adicional que é automaticamente
reabastecida a partir do [armazenamento da rede](../ae2-mechanics/import-export-storage.md). Tenha cuidado ao usar Shift + clique na saída!

## A Interface

Consulte [terminais](terminals.md).

## Melhorias

O Terminal de Fabricação Sem Fio aceita as seguintes [melhorias](upgrade_cards.md):

*   <ItemLink id="energy_card" /> para aumentar a capacidade da bateria

## Receita

<RecipeFor id="wireless_crafting_terminal" />
