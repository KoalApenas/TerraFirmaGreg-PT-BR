---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Célula de Visualização
  icon: view_cell
  position: 410
categories:
- tools
item_ids:
- ae2:view_cell
---

# Célula de Visualização

<ItemImage id="view_cell" scale="2" />

Células de Visualização são usadas para filtrar o que os [terminais](terminals.md) exibem. Elas são particionadas em uma <ItemLink id="cell_workbench" />.

Por exemplo, suponha que você queira que um terminal exiba apenas uma seleção de materiais de construção de pedra. Particione a Célula de Visualização com esses
materiais e coloque-a no terminal; somente esses itens serão exibidos.

Células de Visualização são aditivas: se você tiver uma para tábuas de carvalho e outra para pedregulho, colocar as duas exibirá
tanto as tábuas quanto o pedregulho.

## Receita

<Recipe id="network/cells/view_cell_storage" />

<Recipe id="network/cells/view_cell" />
