---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Multibloco da CPU de Fabricação (Armazenamento, Coprocessador, Monitor, Unidade)
  icon: 1k_crafting_storage
  position: 210
categories:
- devices
item_ids:
- ae2:1k_crafting_storage
- ae2:4k_crafting_storage
- ae2:16k_crafting_storage
- ae2:64k_crafting_storage
- ae2:256k_crafting_storage
- ae2:singularity_crafting_storage
- ae2:crafting_accelerator
- ae2:crafting_monitor
- ae2:crafting_unit
---

# A CPU de Fabricação

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/crafting_cpus.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="crafting_accelerator" scale="4" />

  <BlockImage id="crafting_monitor" scale="4" />

  <BlockImage id="crafting_unit" scale="4" />
</Row>

As CPUs de Fabricação gerenciam solicitações e tarefas de fabricação. Elas armazenam os ingredientes intermediários enquanto tarefas com várias etapas estão
sendo executadas e determinam o tamanho das tarefas e, até certo ponto, a velocidade de conclusão. Consulte [fabricação automática](../ae2-mechanics/autocrafting.md)
para ver mais detalhes.

Cada CPU de Fabricação processa 1 solicitação ou tarefa; portanto, se quiser solicitar ao mesmo tempo um processador de cálculo e 256 pedras lisas, você precisará de 2 multiblocos de CPU.

Elas podem ser configuradas para processar solicitações de jogadores, da automação (barramentos de exportação e interfaces) ou de ambos.

Clicar com o botão direito em uma delas abre uma interface de estado da fabricação, na qual você pode verificar o progresso da tarefa processada pela CPU.

## Configurações

*   A CPU pode ser configurada para aceitar solicitações somente de jogadores, somente da automação (como <ItemLink id="export_bus" />s com
    <ItemLink id="crafting_card" />s) ou de ambos.

## Construção

As CPUs de fabricação são multiblocos e devem formar prismas retangulares sólidos, sem lacunas. Elas são compostas por vários componentes.

Cada CPU deve conter pelo menos 1 bloco de armazenamento de fabricação (e a menor CPU funcional é, de fato, um único armazenamento de fabricação de 1k).

# Unidade de Fabricação

<BlockImage id="crafting_unit" scale="4" />

(Opcional) Unidades de fabricação simplesmente preenchem o espaço de uma CPU para que ela forme um prisma retangular sólido, caso não haja componentes suficientes
dos outros tipos. Elas também são um ingrediente básico dos demais componentes.

<RecipeFor id="crafting_unit" />

# Armazenamento de Fabricação

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="4k_crafting_storage" scale="4" />

  <BlockImage id="16k_crafting_storage" scale="4" />

  <BlockImage id="64k_crafting_storage" scale="4" />

  <BlockImage id="256k_crafting_storage" scale="4" />

  <BlockImage id="singularity_crafting_storage" scale="4" />
</Row>

(Obrigatório) Armazenamentos de fabricação estão disponíveis em todos os tamanhos de célula padrão (1k, 4k, 16k, 64k, 256k) e como <ItemLink id="ae2:singularity_crafting_storage" />(mais detalhes abaixo).
Eles guardam os ingredientes intermediários envolvidos em uma fabricação; portanto, são necessários armazenamentos maiores ou em maior quantidade para que a CPU processe tarefas de fabricação
com mais ingredientes.

<Column>
  <Row>
    <RecipeFor id="1k_crafting_storage" />

    <RecipeFor id="4k_crafting_storage" />

    <RecipeFor id="16k_crafting_storage" />
  </Row>

  <Row>
    <RecipeFor id="64k_crafting_storage" />

    <RecipeFor id="256k_crafting_storage" />
  </Row>
</Column>

# Unidade de Co Processamento de Fabricação

<BlockImage id="crafting_accelerator" scale="4" />

(Opcional) Coprocessadores de fabricação fazem o sistema enviar lotes de ingredientes com mais frequência a partir de cada <ItemLink id="pattern_provider" />.
Isso permite acompanhar máquinas de processamento rápido. Um exemplo é um provedor de padrões cercado por
máquinas do tipo <ItemLink id="molecular_assembler" />, o que permite enviar ingredientes mais depressa do que um único montador consegue processá-los e, assim,
distribuir os lotes de ingredientes entre os montadores ao redor.

<RecipeFor id="crafting_accelerator" />

# Monitor de Fabricação

<BlockImage id="crafting_monitor" scale="4" />

(Opcional) O monitor de fabricação exibe a tarefa que a CPU está processando no momento.
A tela pode ser colorida com um <ItemLink id="color_applicator" />.

<RecipeFor id="crafting_monitor" />

# Armazenamento de Fabricação de Singularidade

<BlockImage id="singularity_crafting_storage" scale="4" />

O armazenamento de fabricação de singularidade é um armazenamento especial que fornece MAX_LONG(2^63-1) bytes de capacidade.

É realmente muito poderoso, mas também um pouco perigoso: para usá-lo, ele precisa ser o único armazenamento de fabricação neste multibloco de CPU;
caso contrário, você não conseguirá selecionar essa CPU ao tentar fabricar algo.
