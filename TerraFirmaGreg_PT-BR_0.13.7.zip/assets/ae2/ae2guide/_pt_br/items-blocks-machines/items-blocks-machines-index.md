---
navigation:
  title: Itens, Blocos e Máquinas
  position: 50
---

# Itens, Blocos e Máquinas

Uma lista do conteúdo do mod para o qual outras páginas podem apontar, acompanhada de uma descrição de suas funções.

## Ingredientes e Blocos Diversos

<CategoryIndex category="misc ingredients blocks" />

## Infraestrutura de Rede

<CategoryIndex category="network infrastructure" />

## Dispositivos

<CategoryIndex category="devices" />

## Máquinas

<CategoryIndex category="machines" />

## Ferramentas

<CategoryIndex category="tools" />
