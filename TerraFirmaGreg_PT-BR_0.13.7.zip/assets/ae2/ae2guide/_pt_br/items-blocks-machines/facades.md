---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fachadas
  icon: facade
  icon_nbt: '{item: "minecraft:stone"}'
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:facade
---

# Fachadas

Fachadas podem deixar sua base com uma aparência mais organizada. Elas cobrem cabos de ambos os tamanhos e podem ser produzidas com muitos
tipos de bloco.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/facades_1.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Elas podem cobrir todos os lados de um cabo, mas permitem que [subpartes](../ae2-mechanics/cable-subparts.md) e conexões de cabo
se projetem para fora.

<GameScene zoom="6"  interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Use-as com criatividade para melhorar a estética da base ou criar blocos com texturas diferentes em cada lado.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_3.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Ocultando Fachadas

As fachadas ficam ocultas enquanto você segura uma <a href="network_tool.md">ferramenta de rede</a> em qualquer uma das mãos.

Você pode interagir com os blocos atrás de fachadas ocultas sem precisar remover primeiro as fachadas.

## Receita

Coloque o bloco cuja textura você deseja no centro de 4 unidades de <ItemLink id="cable_anchor" />.

![Receita da Fachada](../assets/diagrams/facade_recipe.png)
