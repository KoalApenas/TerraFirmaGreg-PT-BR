---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Pó do Fim
  icon: ender_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:ender_dust
---

# Pó do Fim

<ItemImage id="ender_dust" scale="4" />

Uma Pérola de Ender triturada por um <ItemLink id="inscriber" />. É usada na produção de <ItemLink id="wireless_booster" />
e de pares de <ItemLink id="quantum_entangled_singularity" />.

## Receita

<RecipeFor id="ender_dust" />
