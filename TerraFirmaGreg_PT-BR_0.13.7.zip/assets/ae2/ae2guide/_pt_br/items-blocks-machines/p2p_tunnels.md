---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Túneis P2P
  icon: me_p2p_tunnel
  position: 210
categories:
- devices
item_ids:
- ae2:me_p2p_tunnel
- ae2:redstone_p2p_tunnel
- ae2:item_p2p_tunnel
- ae2:fluid_p2p_tunnel
- ae2:fe_p2p_tunnel
- ae2:light_p2p_tunnel
---

# Túneis Ponto a Ponto

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_tunnels.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Túneis P2P são uma forma de transportar itens, fluidos, sinais de redstone, energia, luz e [canais](../ae2-mechanics/channels.md)
por uma rede sem que interajam diretamente com ela. Existem muitas variantes de túnel P2P, mas cada uma
transporta apenas seu tipo específico de conteúdo. Na prática, eles funcionam como portais que conectam diretamente
duas faces de blocos à distância. Eles não são bidirecionais: possuem entradas e saídas definidas.

![Portal](../assets/assemblies/p2p_portal.png)

Por exemplo, o funil voltado para o P2P de Itens funciona como se estivesse conectado diretamente ao barril, permitindo o fluxo dos itens.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_hopper_barrel.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Porém, dois barris colocados lado a lado não transferem itens entre si.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_barrel_barrel.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Também existem outras variantes, como o P2P de Redstone.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_redstone.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Tipos de Túnel P2P e Sintonização

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_tunnels.snbt" />
  <IsometricCamera yaw="180" pitch="90" />
</GameScene>

Há muitos tipos de túnel P2P. Apenas o P2P ME pode ser fabricado diretamente; os demais são obtidos clicando com o botão direito em outros
túneis P2P usando determinados itens:
- Túneis P2P ME são selecionados clicando com o botão direito usando qualquer [cabo](../items-blocks-machines/cables.md).
- Túneis P2P de Redstone são selecionados clicando com o botão direito usando vários componentes de redstone.
- Túneis P2P de Itens são selecionados clicando com o botão direito usando um baú ou funil.
- Túneis P2P de Fluidos são selecionados clicando com o botão direito usando um balde ou frasco.
- Túneis P2P de Energia são selecionados clicando com o botão direito usando quase qualquer item que contenha energia.
- Túneis P2P de Luz são selecionados clicando com o botão direito usando uma tocha ou pedra luminosa.

Alguns tipos de túnel possuem particularidades. Por exemplo, os canais de túneis P2P ME não podem atravessar outros túneis P2P ME, e
túneis P2P de Energia cobram indiretamente uma taxa de 2,5% sobre a FE que passa por eles ao aumentar o próprio
consumo de [energia](../ae2-mechanics/energy.md).

## A Forma Mais Usada de P2P

O uso mais comum dos túneis P2P é empregar um P2P ME para compactar a densidade do transporte de [canais](../ae2-mechanics/channels.md).
Em vez de um feixe de cabos densos, um único cabo denso pode transportar muitos canais pela instalação.

Neste exemplo, 8 entradas P2P ME recebem 256 canais (8*32) do <ItemLink id="controller" /> da rede principal, e 8 saídas P2P ME
os enviam para outro lugar. Observe que cada entrada ou saída de túnel P2P consome 1 canal. Assim, podemos conduzir muitos canais
por um cabo fino. E, como nossos túneis P2P estão em uma [sub-rede](../ae2-mechanics/subnetworks.md) dedicada, nem sequer
consumimos canais da rede principal para fazer isso! Observe também que, embora os túneis P2P possam ser colocados diretamente
contra um controlador, um [cabo inteligente denso](../items-blocks-machines/cables.md#smart-cable) pode ser instalado entre eles para visualizar os canais com mais facilidade.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/p2p_compact_channels.snbt" />

  <BoxAnnotation color="#dddddd" min="1.3 1.3 6.3" max="2 2.7 6.7">
        A Fibra de Quartzo compartilha energia entre a rede principal e a sub-rede P2P.
  </BoxAnnotation>

  <IsometricCamera yaw="225" pitch="30" />
</GameScene>

Para outro exemplo, incluindo o uso com [Pontes Quânticas](quantum_bridge.md), veja este diagrama do MS Paint que não tive vontade
de retocar:

![P2P e pontes quânticas](../assets/diagrams/p2p_quantum_network.png)

## Aninhamento

Porém, isso não permite enviar infinitos canais por um único cabo. O canal de um túnel P2P ME não
atravessa outro túnel P2P ME, portanto eles não podem ser aninhados recursivamente. Observe que a camada externa de túneis P2P ME
nos cabos vermelhos está desconectada. Isso se aplica apenas a túneis P2P ME; outros tipos de túnel P2P podem atravessar um túnel P2P ME,
como demonstram os túneis P2P de Redstone funcionando normalmente.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_nesting.snbt" />
  <IsometricCamera yaw="225" pitch="30" />
</GameScene>

## Vinculação

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_linking_frequency.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

As extremidades de uma conexão por túnel P2P podem ser vinculadas usando um <ItemLink id="memory_card" />. A frequência será exibida
como uma matriz de cores 2x2 na parte traseira do túnel.
- Use Shift + botão direito para gerar uma nova frequência de vínculo P2P.
- Use o botão direito para colar configurações, cartões de melhoria ou a frequência de vínculo.

O túnel no qual você usar Shift + botão direito será a entrada, e aquele no qual usar apenas o botão direito será a saída. É possível ter várias saídas,
mas, com túneis P2P ME, os canais da entrada serão divididos entre elas; portanto, não é possível duplicar canais.

## Receita

<RecipeFor id="me_p2p_tunnel" />
