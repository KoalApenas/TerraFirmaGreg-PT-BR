---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Pedra Celeste
  icon: sky_stone_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:sky_stone_block
- ae2:smooth_sky_stone_block
---

# Pedra Celeste

<BlockImage id="sky_stone_block" scale="8" />

O material que compõe os [meteoritos](../ae2-mechanics/meteorites.md), usado nas receitas de <ItemLink id="sky_stone_tank" />, <ItemLink id="not_so_mysterious_cube" />,
<ItemLink id="cell_component_256k" /> e, principalmente, <ItemLink id="controller" />.

## Receitas

coloque um plano de aniquilação voltado para cima na altura máxima do mundo para obter pó de pedra celeste

<RecipeFor id="sky_stone_block" />

<RecipeFor id="smooth_sky_stone_block" />
