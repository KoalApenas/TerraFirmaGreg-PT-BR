---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bolas de Tinta
  icon: green_lumen_paint_ball
  position: 410
categories:
- tools
item_ids:
- ae2:white_paint_ball
- ae2:orange_paint_ball
- ae2:magenta_paint_ball
- ae2:light_blue_paint_ball
- ae2:yellow_paint_ball
- ae2:lime_paint_ball
- ae2:pink_paint_ball
- ae2:gray_paint_ball
- ae2:light_gray_paint_ball
- ae2:cyan_paint_ball
- ae2:purple_paint_ball
- ae2:blue_paint_ball
- ae2:brown_paint_ball
- ae2:green_paint_ball
- ae2:red_paint_ball
- ae2:black_paint_ball
- ae2:white_lumen_paint_ball
- ae2:orange_lumen_paint_ball
- ae2:magenta_lumen_paint_ball
- ae2:light_blue_lumen_paint_ball
- ae2:yellow_lumen_paint_ball
- ae2:lime_lumen_paint_ball
- ae2:pink_lumen_paint_ball
- ae2:gray_lumen_paint_ball
- ae2:light_gray_lumen_paint_ball
- ae2:cyan_lumen_paint_ball
- ae2:purple_lumen_paint_ball
- ae2:blue_lumen_paint_ball
- ae2:brown_lumen_paint_ball
- ae2:green_lumen_paint_ball
- ae2:red_lumen_paint_ball
- ae2:black_lumen_paint_ball
---

# Bolas de Tinta

<Row gap="-8">
  <ItemImage id="white_paint_ball" scale="4" />

  <ItemImage id="orange_paint_ball" scale="4" />

  <ItemImage id="green_paint_ball" scale="4" />

  <ItemImage id="blue_paint_ball" scale="4" />

  <ItemImage id="red_paint_ball" scale="4" />
</Row>

Bolas de tinta são usadas em um <ItemLink id="color_applicator" /> para pintar blocos que aceitam cores, como [cabos](cables.md),
lã, terracota, vidro e concreto. Elas também podem ser usadas em um <ItemLink id="matter_cannon" /> para disparar pequenas manchas de tinta.

## Receitas

8 bolas de matéria ao redor de um corante

<Column>
  <Row>
    <RecipeFor id="white_paint_ball" />

    <RecipeFor id="orange_paint_ball" />

    <RecipeFor id="green_paint_ball" />
  </Row>

  <Row>
    <RecipeFor id="blue_paint_ball" />

    <RecipeFor id="red_paint_ball" />

    <RecipeFor id="black_paint_ball" />
  </Row>

  <br />
</Column>

# Bolas de Tinta Luminosas

<Row gap="-8">
  <ItemImage id="white_lumen_paint_ball" scale="4" />

  <ItemImage id="orange_lumen_paint_ball" scale="4" />

  <ItemImage id="green_lumen_paint_ball" scale="4" />

  <ItemImage id="blue_lumen_paint_ball" scale="4" />

  <ItemImage id="red_lumen_paint_ball" scale="4" />
</Row>

Elas funcionam como bolas de tinta comuns, mas as manchas emitem luz quando disparadas por um <ItemLink id="matter_cannon" />.
Servem como uma espécie de sinalizador, eu acho.

## Receitas

8 bolas de tinta ao redor de um pó de pedra luminosa

<Column>
  <Row>
    <RecipeFor id="white_lumen_paint_ball" />

    <RecipeFor id="orange_lumen_paint_ball" />

    <RecipeFor id="green_lumen_paint_ball" />
  </Row>

  <Row>
    <RecipeFor id="blue_lumen_paint_ball" />

    <RecipeFor id="red_lumen_paint_ball" />

    <RecipeFor id="black_lumen_paint_ball" />
  </Row>
</Column>
