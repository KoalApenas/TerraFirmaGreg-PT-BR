---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Processadores
  icon: logic_processor
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:logic_processor
- ae2:calculation_processor
- ae2:engineering_processor
- ae2:printed_silicon
- ae2:printed_logic_processor
- ae2:printed_calculation_processor
- ae2:printed_engineering_processor
- ae2:silicon
---

# Processadores

<Row>
  <ItemImage id="logic_processor" scale="4" />

  <ItemImage id="calculation_processor" scale="4" />

  <ItemImage id="engineering_processor" scale="4" />
</Row>

Processadores são um dos principais ingredientes dos [dispositivos](../ae2-mechanics/devices.md) e das máquinas do AE2. Também são um de seus primeiros
grandes desafios de automação. Existem três tipos de processador, feitos respectivamente com ouro, <ItemLink id="certus_quartz_crystal" />
e diamante. Eles são produzidos usando [prensas](presses.md) em um <ItemLink id="inscriber" />, por meio de um processo de várias etapas
normalmente automatizado com uma série de inscritores e tubos com filtros.

## Etapas de Produção

<Column gap="5">
  1.  Reúna ou produza os ingredientes necessários: silício, redstone, ouro, <ItemLink id="certus_quartz_crystal" /> e diamante.

  <RecipeFor id="silicon" />

  <br />

  2.  Prense os componentes de circuito impresso necessários

  <Row>
    <RecipeFor id="printed_silicon" />

    <RecipeFor id="printed_logic_processor" />
  </Row>

  <Row>
    <RecipeFor id="printed_calculation_processor" />

    <RecipeFor id="printed_engineering_processor" />
  </Row>

  <br />

  3.  Montagem final

  <Row>
    <RecipeFor id="logic_processor" />

    <RecipeFor id="calculation_processor" />
  </Row>

  <RecipeFor id="engineering_processor" />
</Column>
