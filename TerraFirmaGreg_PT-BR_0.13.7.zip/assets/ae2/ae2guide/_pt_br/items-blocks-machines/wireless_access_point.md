---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ponto de Acesso Sem Fio
  icon: wireless_access_point
  position: 210
categories:
- devices
item_ids:
- ae2:wireless_booster
- ae2:wireless_access_point
---

# O Ponto de Acesso Sem Fio

<BlockImage id="wireless_access_point" p:state="has_channel" scale="8" />

Permite acesso sem fio por meio de um <ItemLink id="wireless_terminal" />.
O alcance e o consumo de energia dependem da quantidade de <ItemLink id="wireless_booster" /> instalada.

Uma rede pode ter qualquer quantidade de Pontos de Acesso Sem Fio, cada um com qualquer quantidade
de <ItemLink id="wireless_booster" />, permitindo otimizar o consumo de energia
e o alcance ao modificar sua configuração.

Exige um [canal](../ae2-mechanics/channels.md).

Também é usado para vincular [terminais sem fio](wireless_terminals.md).

# Amplificador Sem Fio

<ItemImage id="wireless_booster" scale="2" />

Usado para aumentar o alcance do Ponto de Acesso Sem Fio.

## Receitas

<RecipeFor id="wireless_access_point" />

<RecipeFor id="wireless_booster" />
