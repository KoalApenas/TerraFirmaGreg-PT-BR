---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Plano de Aniquilação
  icon: annihilation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:annihilation_plane
---

# O Plano de Aniquilação

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/annihilation_plane.snbt" />
</GameScene>

O Plano de Aniquilação quebra blocos e coleta itens. Ele funciona de forma semelhante a um <ItemLink id="import_bus" />, enviando as coisas
para o [armazenamento da rede](../ae2-mechanics/import-export-storage.md). Para que os itens sejam coletados, eles precisam colidir com a
face do plano; ele não coleta itens em uma área.

Os Planos de Aniquilação podem receber qualquer encantamento de picareta; portanto, sim, você pode colocar níveis absurdos de Fortuna em alguns deles e
[automatizar o processamento de minérios](../example-setups/ore-fortuner.md), se o seu modpack permitir. Além disso, Toque Suave funciona como
esperado, Eficiência reduz o custo de energia para quebrar um bloco e Inquebrável concede uma chance de não consumir energia.

Eles são [subpartes de cabo](../ae2-mechanics/cable-subparts.md).

**LEMBRE-SE DE HABILITAR JOGADORES FALSOS NA REIVINDICAÇÃO DO SEU CHUNK**

## Filtragem

O Plano de Aniquilação só quebrará um bloco ou coletará um item se puder armazenar os itens resultantes
na sua rede. Isso significa que, para filtrá-lo, *você precisa restringir o que pode ser armazenado na rede*, provavelmente colocando-o
em uma [sub-rede](../ae2-mechanics/subnetworks.md). Um <ItemLink id="storage_bus" /> ou uma [célula](../items-blocks-machines/storage_cells.md)
pode ser [particionada](cell_workbench.md) para fazer isso.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/annihilation_filtering.snbt" />

  <DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
        Filtrado para os itens derrubados por aquilo que você deseja quebrar.
  </DiamondAnnotation>

  <DiamondAnnotation pos=".5 0.5 2.5" color="#00ff00">
        Particionada para os itens derrubados por aquilo que você deseja quebrar.
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Novamente, o filtro considera *os itens derrubados*. Por exemplo, se você quiser filtrar a quebra de <ItemLink id="minecraft:amethyst_cluster" />s,
precisará de um plano encantado com Toque Suave; caso contrário, cada estágio anterior de crescimento não derrubará nada, e o plano os quebrará de qualquer
forma, pois a rede sempre consegue armazenar nada.

## Receita

<RecipeFor id="annihilation_plane" />
