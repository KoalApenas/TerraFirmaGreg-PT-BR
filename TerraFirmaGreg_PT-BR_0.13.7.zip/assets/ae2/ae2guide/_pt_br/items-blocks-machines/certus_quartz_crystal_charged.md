---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cristal de Quartzo Certus Carregado
  icon: charged_certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:charged_certus_quartz_crystal
---

# O Cristal de Quartzo Certus Carregado

<ItemImage id="charged_certus_quartz_crystal" scale="4" />

Um <ItemLink id="certus_quartz_crystal" /> que passou por um <ItemLink id="charger" />. É usado na produção de
<ItemLink id="fluix_crystal" /> e [blocos geradores de Certus](../items-blocks-machines/budding_certus.md).

## Receita

<RecipeFor id="charged_certus_quartz_crystal" />
