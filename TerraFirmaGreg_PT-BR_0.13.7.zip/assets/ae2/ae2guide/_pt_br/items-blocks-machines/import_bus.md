---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ponto de Importação
  icon: import_bus
  position: 220
categories:
- devices
item_ids:
- ae2:import_bus
---

# O Ponto de Importação

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/import_bus.snbt" />
</GameScene>

O Ponto de Importação retira itens e fluidos (e qualquer outra coisa permitida por extensões) do inventário que está tocando e os insere no
[armazenamento de rede](../ae2-mechanics/import-export-storage.md).

Para reduzir a defasagem, quando o Ponto de Importação não importa nada há algum tempo, ele entra em uma espécie de
“modo de espera”, no qual opera lentamente, e desperta e acelera até a velocidade máxima (4 operações por segundo) ao importar algo com sucesso.

Eles são [subpartes de cabo](../ae2-mechanics/cable-subparts.md).

## Filtragem

Por padrão, o ponto importa qualquer coisa à qual tenha acesso. Itens inseridos nos espaços de filtro funcionam como uma lista de permissões e somente
esses itens específicos podem ser importados.

Itens e fluidos podem ser arrastados do JEI/REI para os espaços mesmo que você não possua nenhuma unidade daquele item.

Clique com o botão direito usando um recipiente de fluido, como um balde ou tanque, para definir o fluido como filtro em vez do item do recipiente.

## Melhorias

O Ponto de Importação aceita as seguintes [melhorias](upgrade_cards.md):

*   A <ItemLink id="capacity_card" /> aumenta a quantidade de espaços de filtro
*   A <ItemLink id="speed_card" /> aumenta a quantidade de conteúdo movido por operação
*   A <ItemLink id="fuzzy_card" /> permite que o ponto filtre pelo nível de dano e/ou ignore o NBT do item
*   A <ItemLink id="inverter_card" /> alterna o filtro de uma lista de permissões para uma lista de bloqueio
*   A <ItemLink id="redstone_card" /> adiciona controle por Redstone, permitindo ativação com sinal alto, sinal baixo ou uma vez por pulso

## Velocidades

| Cartões de Aceleração | Itens Movidos por Operação |
|:-------------------|:--------------------------|
| 0                  | 1                         |
| 1                  | 8                         |
| 2                  | 32                        |
| 3                  | 64                        |
| 4                  | 96                        |

## Receita

<RecipeFor id="import_bus" />
