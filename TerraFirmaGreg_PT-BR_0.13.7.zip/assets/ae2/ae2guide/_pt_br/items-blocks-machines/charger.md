---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Carregador
  icon: charger
  position: 310
categories:
- machines
item_ids:
- ae2:charger
---

# O Carregador

<BlockImage id="charger" scale="8" />

O Carregador permite carregar
ferramentas compatíveis e <ItemLink id="certus_quartz_crystal" />.

A energia pode ser fornecida por cima ou por baixo, usando os [cabos](cables.md) do AE2 ou cabos de energia de outros mods. Ele pode
aceitar a energia do AE2 (AE) ou a Energia Forge (FE). Itens podem ser inseridos ou removidos por qualquer lado. Somente os resultados podem
ser removidos; portanto, não são necessários filtros para evitar a retirada de cristais de Certus em vez dos carregados. Ele pode ser girado com uma
<ItemLink id="certus_quartz_wrench" /> para facilitar a automação.

Pode ser usado para criar <ItemLink id="charged_certus_quartz_crystal" />
a partir de <ItemLink id="certus_quartz_crystal" />, e <ItemLink id="meteorite_compass" /> a partir de <ItemLink id="minecraft:compass" />.

Para energizá-lo manualmente, coloque uma <ItemLink id="crank" /> em cima ou embaixo e clique nela com o botão direito até o item estar carregado.

Ele também funciona como estação de trabalho do aldeão do AE2.

## Automação Simples

Por exemplo, a possibilidade de girá-lo permite semiautomatizar carregadores desta forma:

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/charger_hopper.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Receita

<RecipeFor id="charger" />
