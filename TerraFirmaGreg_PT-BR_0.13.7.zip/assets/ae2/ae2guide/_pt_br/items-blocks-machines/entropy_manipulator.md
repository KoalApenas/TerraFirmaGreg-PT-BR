---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Manipulador de Entropia
  icon: entropy_manipulator
  position: 410
categories:
- tools
item_ids:
- ae2:entropy_manipulator
---

# O Manipulador de Entropia

<ItemImage id="entropy_manipulator" scale="4" />

O Manipulador de Entropia permite aquecer e resfriar objetos ao clicar com o botão direito e ao clicar com Shift + botão direito, respectivamente. Ele não faz muita coisa,
apenas ações como evaporar ou congelar água, solidificar lava em obsidiana, transformar toras em carvão vegetal e fundir pedregulho em pedra diretamente no mundo.

Quando não houver uma ação específica disponível para um bloco, ele funcionará como um isqueiro.

Sua energia pode ser recarregada em um <ItemLink id="charger" />.

## Receita

<RecipeFor id="entropy_manipulator" />
