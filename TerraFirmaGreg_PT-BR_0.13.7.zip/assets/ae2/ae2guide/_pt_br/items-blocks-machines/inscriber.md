---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Inscritor
  icon: inscriber
  position: 310
categories:
- machines
item_ids:
- ae2:inscriber
---

# O Inscritor

<BlockImage id="inscriber" scale="8" />

O Inscritor é usado para inscrever circuitos e [processadores](processors.md) com [prensas](presses.md), além de triturar vários itens em pó.
Ele aceita tanto a energia do AE2 (AE) quanto a Energia Fabric/Forge (E/FE). Pode operar por lados, de modo que inserir itens por lados diferentes
os coloque em espaços distintos do inventário. Para facilitar, ele pode ser girado com uma <ItemLink id="certus_quartz_wrench" />.
Também pode ser configurado para enviar os resultados das fabricações a inventários adjacentes.

O tamanho do buffer de entrada pode ser ajustado. Por exemplo, para alimentar um grande conjunto de Inscritores a partir de um único inventário,
é melhor usar um buffer pequeno, para que os materiais sejam distribuídos de modo mais eficiente entre os Inscritores (em vez de o primeiro
Inscritor acumular 64 itens enquanto os demais permanecem vazios).

As 4 prensas de circuito são usadas para fabricar [processadores](processors.md)

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

A prensa de nome pode ser usada para nomear blocos como uma bigorna, o que é útil para identificá-los em um <ItemLink id="pattern_access_terminal" />.

<ItemImage id="name_press" scale="4" />

## Configurações

* O Inscritor pode ser configurado para operar por lados (como explicado abaixo) ou aceitar entradas em qualquer espaço por qualquer lado, com um filtro interno decidindo
    o destino de cada item. No modo sem distinção de lados, itens não podem ser extraídos dos espaços superior e inferior.
* O Inscritor pode ser configurado para enviar itens a inventários adjacentes.
* O tamanho do buffer de entrada pode ser ajustado: a opção grande é destinada a um Inscritor independente alimentado manualmente; a
opção pequena torna mais viáveis as grandes configurações paralelizadas.

## A Interface e o Acesso por Lados

No modo por lados, o inscritor filtra o destino de cada item de acordo com o lado usado para inseri-lo ou extraí-lo.

![Interface do Inscritor](../assets/diagrams/inscriber_gui.png) ![Lados do Inscritor](../assets/diagrams/inscriber_sides.png)

A. **Entrada Superior**, acessada pelo lado de cima do inscritor — itens podem ser inseridos e extraídos deste slot.

B. **Entrada Central**, acessada pelos lados esquerdo, direito, frontal e traseiro do inscritor — itens só podem ser inseridos neste slot, não extraídos.

C. **Entrada Inferior**, acessada pelo lado de baixo do inscritor — itens podem ser inseridos e extraídos deste slot.

D. **Saída**, acessada para extração pelos lados esquerdo, direito, frontal e traseiro do inscritor — itens só podem ser extraídos deste slot, não inseridos.

## Automação Simples

Por exemplo, o acesso por lados e a possibilidade de girar o bloco permitem semiautomatizar inscritores desta forma:

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/inscriber_hopper_automation.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Ou simplesmente conecte tubos à entrada e à saída do inscritor quando ele estiver no modo sem lados.

## Melhorias

O inscritor aceita as seguintes [melhorias](upgrade_cards.md):

*   <ItemLink id="speed_card" />

## Receita

<RecipeFor id="inscriber" />
