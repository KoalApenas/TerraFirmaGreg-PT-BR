---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Pilão Espacial
  icon: spatial_pylon
  position: 210
categories:
- devices
item_ids:
- ae2:spatial_pylon
---

# O Pilão Espacial

<BlockImage id="spatial_pylon" p:powered_on="true" scale="8" />

O Pilão Espacial é usado na [E/S espacial](../ae2-mechanics/spatial-io.md) para gerar o campo espacial e definir o volume
que será afetado.

Cada linha contínua de pilões usa 1 [canal](../ae2-mechanics/channels.md).

As linhas de pilões precisam ter pelo menos 2 blocos de comprimento para funcionar.

## Receita

<RecipeFor id="spatial_pylon" />
