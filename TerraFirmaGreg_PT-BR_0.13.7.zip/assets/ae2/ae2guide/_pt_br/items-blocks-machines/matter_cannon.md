---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Canhão de Matéria
  icon: matter_cannon
  position: 410
categories:
- tools
item_ids:
- ae2:matter_cannon
---

# O Canhão de Matéria

<ItemImage id="matter_cannon" scale="4" />

O canhão de matéria é um canhão eletromagnético portátil capaz de disparar pequenos itens como projéteis, incluindo <ItemLink id="matter_ball" /> e pepitas de metal. O dano
depende do item disparado: itens “mais pesados”, como pepitas de ouro — 10 de dano —, causam mais dano que itens leves, como bolas de matéria — 2 de dano.
Ele consome uma energia básica de 1600 AE por disparo.

Quando a opção de configuração “matterCannonBlockDamage” está habilitada, o canhão quebra blocos conforme a dureza deles e
o dano da munição.

Sua energia pode ser recarregada em um <ItemLink id="charger" />.

Canhões de matéria funcionam como [células de armazenamento](storage_cells.md), e a maneira mais fácil de abastecer seus carregadores de munição é colocar
o canhão no slot de célula de armazenamento de um <ItemLink id="chest" />.

## Melhorias

Canhões de matéria aceitam as seguintes [melhorias](upgrade_cards.md), inseridas por meio de uma <ItemLink id="cell_workbench" />:

*   <ItemLink id="fuzzy_card" /> permite particionar a célula por nível de dano e/ou ignorar o NBT do item
*   <ItemLink id="inverter_card" /> troca o filtro de lista branca para lista negra
*   <ItemLink id="speed_card" /> aumenta a energia usada em cada disparo, fazendo-o sair com mais potência.
*   <ItemLink id="void_card" /> destrói itens inseridos quando a célula está cheia. Tenha cuidado ao particioná-la!
*   <ItemLink id="energy_card" /> aumenta a capacidade da bateria

## Receita

<RecipeFor id="matter_cannon" />
