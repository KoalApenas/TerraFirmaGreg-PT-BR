---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Montador Molecular
  icon: molecular_assembler
  position: 310
categories:
- machines
item_ids:
- ae2:molecular_assembler
---

# O Montador Molecular

<BlockImage id="molecular_assembler" scale="8" />

O montador molecular recebe itens e executa a operação definida por um <ItemLink id="pattern_provider" /> adjacente
ou pelo <ItemLink id="crafting_pattern" />, <ItemLink id="smithing_table_pattern" /> ou <ItemLink id="stonecutting_pattern" /> inserido;
em seguida, envia o resultado aos inventários adjacentes.

Este montador possui um padrão de fabricação que especifica a receita de 1 tora de carvalho = 4 tábuas de carvalho. Quando toras entram pelo funil superior,
o montador fabrica as tábuas de carvalho e as envia ao funil inferior.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/standalone_assembler.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## O Principal Uso do Montador Molecular

Porém, seu uso principal é ao lado de um <ItemLink id="pattern_provider" />. Provedores de Padrões possuem um comportamento especial nesse caso:
eles enviam aos montadores adjacentes as informações do padrão relevante junto com os ingredientes. Como os montadores ejetam automaticamente os resultados das
fabricações para inventários adjacentes — e, portanto, para os slots de retorno do provedor de padrões —, um montador junto a um provedor
é tudo o que se precisa para automatizar padrões de fabricação.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Melhorias

O Montador Molecular aceita as seguintes [melhorias](upgrade_cards.md):

*   <ItemLink id="speed_card" />

## Receita

<RecipeFor id="molecular_assembler" />

## Observação

O OptiFine interrompe a função de “enviar a inventários adjacentes”, portanto a maioria das instalações de fabricação com montadores não funciona.
