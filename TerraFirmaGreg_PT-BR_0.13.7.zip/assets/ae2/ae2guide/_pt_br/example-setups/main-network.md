---
navigation:
  parent: example-setups/example-setups-index.md
  title: Exemplo de "Rede Principal"
  icon: controller
---

# Exemplo de "Rede Principal"

Muitas outras configurações fazem referência a uma "Rede Principal". Você talvez também queira saber como todos esses [dispositivos](../ae2-mechanics/devices.md) se
combinam em um sistema funcional. Veja um exemplo:

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/treelike_network_structure.snbt" />

    <BoxAnnotation color="#dddddd" min="3.9 0 1.9" max="9.1 5 7.1" thickness="0.05">
        Um grande conjunto de Provedores de Padrões e Montadores Moleculares oferece bastante espaço para padrões de fabricação, corte de pedras e ferraria.
        A disposição em tabuleiro de xadrez permite que os Provedores usem vários Montadores em paralelo sem ocupar muito espaço.
        Grupos de 8 impedem que os canais sejam roteados incorretamente.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="3.9 0 9.9" max="5.1 3 12.1" thickness="0.05">
        Algumas máquinas, com uma sub-rede de tubos para enviar suas saídas aos Provedores.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="-0.1 0 8.9" max="1.1 3 13.1" thickness="0.05">
      Alguns terminais e várias bugigangas utilitárias. (Provavelmente você vai querer apenas um Terminal de Fabricação, e não um Terminal comum _e_ um Terminal de Fabricação.)
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="-0.1 0 -0.1" max="2.1 3 8.1" thickness="0.05">
      Um conjunto de CPUs de Fabricação: algumas com maior armazenamento e algumas outras com menor armazenamento.
      Em uma configuração real, provavelmente convém usar mais Coprocessadores de Fabricação, mas isso deixaria esta cena grande demais.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5.9 0 13.9" max="7.1 1 15.1" thickness="0.05">
      O Controlador ME deve ficar no centro da base e provavelmente ser um pouco maior que este. Um formato alongado funciona bem.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="11.9 0 7.9" max="13.1 4 13.1" thickness="0.05">
        Vários métodos de armazenamento, usando Gabinetes ME ou Pontos de Armazenamento. Observe que todos estão em grupos de 8.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="10.9 0 0.9" max="13.1 2 7.1" thickness="0.05">
        Vários métodos de armazenamento, usando Gabinetes ME ou Pontos de Armazenamento. Observe que todos estão em grupos de 8.
    </BoxAnnotation>

  <IsometricCamera yaw="315" pitch="30" />
</GameScene>
