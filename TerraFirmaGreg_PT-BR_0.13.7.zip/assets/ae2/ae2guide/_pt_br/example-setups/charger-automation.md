---
navigation:
  parent: example-setups/example-setups-index.md
  title: Automação do Carregador
  icon: charger
---

# Automação do Carregador

Como esta configuração usa um <ItemLink id="pattern_provider" />, ela foi projetada para integrar seu sistema de [fabricação automática](../ae2-mechanics/autocrafting.md).
Se você só quiser automatizar um <ItemLink id="charger" /> independente, use funis, baús e componentes semelhantes.

Automatizar um <ItemLink id="charger" /> é relativamente simples. Um <ItemLink id="pattern_provider" /> envia o ingrediente ao Carregador; depois, uma [sub-rede de tubos](pipe-subnet.md)
ou outro tubo de itens devolve o resultado ao Provedor.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/charger_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Provedor de Padrões: em sua configuração padrão, com os Padrões de Processamento relevantes. Também fornece energia ao Carregador.

        ![Padrão do Carregador](../assets/diagrams/charger_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 0" max="1 1.3 1">
        (2) Ponto de Importação: em sua configuração padrão.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (3) Ponto de Armazenamento: em sua configuração padrão.
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        Para a Rede Principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurações

* O <ItemLink id="pattern_provider" /> (1) está em sua configuração padrão, com os <ItemLink id="processing_pattern" /> relevantes.
  Ele também fornece [energia](../ae2-mechanics/energy.md) ao <ItemLink id="charger" />, pois funciona como um [cabo](../items-blocks-machines/cables.md).
  
    ![Padrão do Carregador](../assets/diagrams/charger_pattern.png)

* O <ItemLink id="import_bus" /> (2) está em sua configuração padrão.
* O <ItemLink id="storage_bus" /> (3) está em sua configuração padrão.

## Como Funciona

1. O <ItemLink id="pattern_provider" /> envia os ingredientes ao <ItemLink id="charger" />.
2. O Carregador faz seu trabalho de carregamento.
3. O <ItemLink id="import_bus" /> da sub-rede verde retira o resultado do Carregador e tenta armazená-lo no
   [armazenamento da rede](../ae2-mechanics/import-export-storage.md).
4. O único armazenamento da sub-rede verde é o <ItemLink id="storage_bus" />, que armazena os itens resultantes no Provedor de Padrões, devolvendo-os à rede principal.
