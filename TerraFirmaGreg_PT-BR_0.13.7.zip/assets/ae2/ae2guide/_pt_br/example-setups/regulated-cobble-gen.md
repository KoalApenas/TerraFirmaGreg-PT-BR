---
navigation:
  parent: example-setups/example-setups-index.md
  title: Gerador de Pedregulho Autorregulado
  icon: minecraft:cobblestone
---

# Gerador de Pedregulho Autorregulado

Automatizar um gerador de pedregulho é simples: basta apontar um <ItemLink id="annihilation_plane" /> para um gerador manual de pedregulho
padrão do Minecraft. Porém, isso acabará entupindo sua rede com pedregulho, portanto algum tipo de controle
é necessário.

Devido ao funcionamento dos planos de aniquilação — eles agem como <ItemLink id="import_bus" /> —, não podemos simplesmente colocar um <ItemLink id="level_emitter" />
voltado para um <ItemLink id="export_bus" /> com um <ItemLink id="redstone_card" /> — pois não é possível ir diretamente da importação à exportação
sem armazenamento entre elas. Precisamos usar uma solução um pouco mais indireta.

Os <ItemLink id="toggle_bus" /> permitem conectar e desconectar partes da rede com sinais de redstone, mas fazem
a rede reiniciar sempre que isso ocorre. Há uma solução simples: coloque o ponto interruptor em uma [sub-rede](../ae2-mechanics/subnetworks.md)
para que apenas essa sub-rede reinicie.

Podemos usar uma [sub-rede](../ae2-mechanics/subnetworks.md) independente com <ItemLink id="annihilation_plane" /> e <ItemLink id="storage_bus" />
que envia itens para uma <ItemLink id="interface" /> na rede principal. O ponto interruptor conectará e desconectará a sub-rede de uma
<ItemLink id="quartz_fiber" />, interrompendo a energia dos planos.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/regulated_cobble_gen.snbt" />

<BoxAnnotation color="#dddddd" min="3 2 2" max="7 2.3 3">
        (1) Planos de Aniquilação: Não possuem interface para configurar, mas podem receber Eficiência e Inquebrável para reduzir o consumo de energia.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 2 2" max="2.3 3 3">
        (2) Ponto de Armazenamento: Na configuração padrão.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 2.3 2" max="2.7 2.7 2.3">
        (3) Ponto Interruptor: É muito importante que o ponto interruptor esteja na
        sub-rede, e não na rede principal.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 3 2.3" max="2.7 3.3 2.7">
        (4) Emissor de Nível: Configurado com pedregulho e a quantidade desejada; definido como “Emitir quando os níveis estiverem abaixo do limite”.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 3" max="2 3 2">
        (5) Interface: Na configuração padrão.
  </BoxAnnotation>

<DiamondAnnotation pos="0 2.5 1.5" color="#00ff00">
        Para a Rede Principal
    </DiamondAnnotation>

<DiamondAnnotation pos="5 1.5 3.5" color="#00ff00">
        Escadas alagadas impedem a água de fluir e transformar a lava em obsidiana.
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurações

* Os <ItemLink id="annihilation_plane" /> (1) não possuem interface para configurar, mas podem receber Eficiência e Inquebrável para reduzir o consumo de energia.
* O <ItemLink id="storage_bus" /> (2) está na configuração padrão.
* O <ItemLink id="toggle_bus" /> (3) deve ficar no lado da sub-rede da fibra de quartzo, e não no lado da rede principal, ou a rede principal
  reiniciará toda vez que ele alternar.
* O <ItemLink id="level_emitter" /> (4) é configurado com o item e a quantidade desejados e definido como “Emitir quando os níveis estiverem abaixo do limite”.
* A <ItemLink id="interface" /> (5) está na configuração padrão.

## Como Funciona

1. O gerador de pedregulho produz um pouco de pedregulho.
2. Os <ItemLink id="annihilation_plane" /> quebram o pedregulho. 
3. O <ItemLink id="storage_bus" /> armazena o pedregulho na <ItemLink id="interface" />, enviando-o para a rede principal.
4. Quando a quantidade de pedregulho na rede principal ultrapassa o valor definido, o <ItemLink id="level_emitter" /> para
   de emitir um sinal, desligando o <ItemLink id="toggle_bus" />.
5. Isso interrompe a energia da sub-rede, fazendo os planos de aniquilação pararem de funcionar.
