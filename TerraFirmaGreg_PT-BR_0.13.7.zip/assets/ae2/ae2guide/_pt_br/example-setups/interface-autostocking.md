---
navigation:
  parent: example-setups/example-setups-index.md
  title: Reposição Automática com Interfaces
  icon: interface
---

# Reposição Automática com Interfaces

Talvez você se pergunte: "Como mantenho em estoque uma quantidade específica de vários itens, fabricando mais conforme necessário?"

Uma solução é usar uma <ItemLink id="interface" /> e um <ItemLink id="crafting_card" /> para solicitar novos itens automaticamente
ao sistema de [fabricação automática](../ae2-mechanics/autocrafting.md) da rede. Esta configuração é mais adequada para manter uma pequena quantidade de uma grande
variedade de itens.

Esta configuração de demonstração foi encurtada para não ficar larga demais; provavelmente o ideal é usar 4 <ItemLink id="interface" /> e 4 <ItemLink id="storage_bus" />,
aproveitando todos os 8 [canais](../ae2-mechanics/channels.md) de um [cabo](../items-blocks-machines/cables.md) comum.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_autostocking.snbt" />

<BoxAnnotation color="#dddddd" min="0 0 0" max="2 1 1">
        (1) Interfaces: configuradas para manter dentro de si os itens desejados. Possuem Cartões de Fabricação.
        <ItemImage id="crafting_card" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 0" max="2 1.3 1">
        (2) Pontos de Armazenamento: "Modo de Entrada/Saída" definido como "Somente Extração".
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        Para a Rede Principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurações

* As <ItemLink id="interface" /> (1) estão configuradas para manter dentro de si os itens desejados: clique com o item desejado em seus
   espaços superiores ou arraste-o do JEI até esses espaços; depois, clique no ícone de chave acima deles para definir a quantidade. Elas possuem <ItemLink id="crafting_card" />.
* Os <ItemLink id="storage_bus" /> (2) estão configurados com o "Modo de Entrada/Saída" definido como "Somente Extração".

## Como Funciona

1. Se uma <ItemLink id="interface" /> não conseguir retirar do [armazenamento da rede](../ae2-mechanics/import-export-storage.md) uma quantidade suficiente de um item configurado,
   (e possuir um <ItemLink id="crafting_card" />), ela solicitará que o sistema de [fabricação automática](../ae2-mechanics/autocrafting.md) da rede produza mais desse item.
2. Os <ItemLink id="storage_bus" /> permitem que a rede acesse o conteúdo das Interfaces.
