---
navigation:
  parent: example-setups/example-setups-index.md
  title: Sub-rede de "Tubos" de Itens/Fluidos
  icon: storage_bus
---

# Sub-rede de "Tubos" de Itens/Fluidos

Um método simples de simular um tubo de itens e/ou fluidos com [dispositivos](../ae2-mechanics/devices.md) do AE2, útil para qualquer tarefa em que você usaria um desses tubos.
Isso inclui devolver o resultado de uma fabricação a um <ItemLink id="pattern_provider" />.

Em geral, há dois métodos diferentes para fazer isso:

## Ponto de Importação -> Ponto de Armazenamento

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        (1) Ponto de Importação: pode ser filtrado.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        (2) Ponto de Armazenamento: pode ser filtrado. Este (e qualquer outro Ponto de Armazenamento que você queira usar como destino)
        deve ser o único armazenamento da rede.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
        Origem
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
        Destino
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

O <ItemLink id="import_bus" /> (1) no inventário de origem importa os itens ou o fluido e tenta armazená-los no [armazenamento da rede](../ae2-mechanics/import-export-storage.md).
Como o único armazenamento da rede é o <ItemLink id="storage_bus" /> (2) — motivo pelo qual esta é uma sub-rede e não faz parte da rede principal —, os itens ou o fluido
são colocados no inventário de destino e, assim, transferidos. A energia é fornecida por uma <ItemLink id="quartz_fiber" />.
Tanto o Ponto de Importação quanto o Ponto de Armazenamento podem ser filtrados, mas a configuração transfere tudo a que tiver acesso quando nenhum filtro é aplicado.
Esta configuração também funciona com vários Pontos de Importação e vários Pontos de Armazenamento.

## Ponto de Armazenamento -> Ponto de Exportação

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/storage_export_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        (1) Ponto de Armazenamento: pode ser filtrado. Este (e qualquer outro Ponto de Armazenamento que você queira usar como origem)
        deve ser o único armazenamento da rede.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        (2) Ponto de Exportação: precisa ser filtrado.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
        Origem
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
        Destino
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

O <ItemLink id="export_bus" /> no inventário de destino tenta retirar do [armazenamento da rede](../ae2-mechanics/import-export-storage.md) os itens definidos em seu filtro.
Como o único armazenamento da rede é o <ItemLink id="storage_bus" /> — motivo pelo qual esta é uma sub-rede e não faz parte da rede principal —, os itens ou o fluido
são retirados do inventário de origem e, assim, transferidos. A energia é fornecida por uma <ItemLink id="quartz_fiber" />.
Como Pontos de Exportação precisam de um filtro para funcionar, esta configuração só opera se você filtrar o Ponto de Exportação.
Esta configuração também funciona com vários Pontos de Armazenamento e vários Pontos de Exportação.

## Uma Configuração que Não Funciona (Ponto de Importação -> Ponto de Exportação)

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_export_pipe.snbt" />

<BoxAnnotation color="#dd3333" min="3.7 0 0" max="4 1 1">
        Ponto de Importação: como a rede não possui armazenamento, não há para onde importar.
  </BoxAnnotation>

<BoxAnnotation color="#dd3333" min="1 0 0" max="1.3 1 1">
        (2) Ponto de Exportação: como a rede não possui armazenamento, não há nada para exportar.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#ff0000">
        Origem
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#ff0000">
        Destino
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Uma configuração apenas com Pontos de Importação e Exportação não funciona. O Ponto de Importação tentará retirar conteúdo do inventário de origem
e armazenar os itens ou o fluido no armazenamento da rede. O Ponto de Exportação tentará retirar conteúdo do armazenamento da rede e colocar os
itens ou o fluido no inventário de destino. Entretanto, como esta rede **não possui armazenamento**, o Ponto de Importação não consegue importar
e o Ponto de Exportação não consegue exportar; portanto, nada acontece.

## Entrada e Saída por 1 Face

Suponha que você tenha uma máquina capaz de receber entradas e permitir a retirada da saída por 1 única face. (Como um <ItemLink id="charger" />.)
É possível inserir os ingredientes e retirar o resultado combinando os 2 métodos de sub-rede de tubos:

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_export_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="4 1 1" max="5 1.3 2">
        (1) Ponto de Importação: pode ser filtrado.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
        (2) Ponto de Armazenamento: pode ser filtrado. Este (e qualquer outro Ponto de Armazenamento que você queira usar para inserir e retirar itens)
        deve ser o único armazenamento da rede.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0 1" max="3 1 2">
        (3) Elemento no Qual Você Deseja Inserir e do Qual Deseja Retirar: neste caso, um Carregador.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 1" max="1 1.3 2">
        (4) Ponto de Exportação: precisa ser filtrado.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 1.5" color="#00ff00">
        Origem
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 1.5" color="#00ff00">
        Destino
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Interfaces

Além dos Pontos de Importação e Exportação, há outros [dispositivos](../ae2-mechanics/devices.md) que inserem itens no
e retiram itens do [armazenamento da rede](../ae2-mechanics/import-export-storage.md)!
O dispositivo relevante aqui é a <ItemLink id="interface" />. Se for inserido um item que a Interface não esteja configurada para manter, ela o
enviará ao armazenamento da rede, algo que podemos aproveitar de modo semelhante ao tubo de Ponto de Importação -> Ponto de Armazenamento. Configurar uma Interface para
manter algum item fará com que ela o retire do armazenamento da rede, de modo semelhante ao tubo de Ponto de Armazenamento -> Ponto de Exportação. Interfaces podem ser configuradas para
manter alguns itens e não manter outros, permitindo inserir e retirar conteúdo remotamente por Pontos de Armazenamento, caso você queira fazer isso por algum motivo.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/interface_pipes.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        Interface
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        Ponto de Armazenamento
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.7 0 2" max="4 1 3">
        Ponto de Armazenamento
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 2" max="1 1.3 3">
        Ponto de Armazenamento
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Um-para-Muitos e Muitos-para-Um (e muitos-para-muitos)

Naturalmente, você não precisa usar apenas um <ItemLink id="import_bus" />, <ItemLink id="export_bus" /> ou <ItemLink id="storage_bus" />.

<GameScene zoom="3" background="transparent">
<ImportStructure src="../assets/assemblies/many_to_many_pipe.snbt" />

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## Fornecimento para Vários Lugares

Com tudo isso, podemos derivar um método para enviar ingredientes de uma face de um <ItemLink id="pattern_provider" /> a vários
locais diferentes, como um conjunto de máquinas ou várias faces de uma única máquina.

Não queremos um tubo de Importação -> Armazenamento nem um tubo de Armazenamento -> Exportação, pois o <ItemLink id="pattern_provider" /> nunca
contém de fato os ingredientes. Em vez disso, os Provedores *enviam* os ingredientes aos inventários adjacentes, então precisamos de algum 
inventário adjacente que também possa importar itens.

Isso parece ser... uma <ItemLink id="interface" />!
Certifique-se de que o Provedor esteja no modo direcional ou de subparte plana e/ou de que a Interface esteja no modo de subparte plana, para que os dois não formem uma
conexão de rede.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        Interface (deve ser plana, não um bloco inteiro)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        Pontos de Armazenamento
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        Locais aos quais você deseja fornecer os padrões (várias máquinas ou várias faces de 1 máquina)
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>
