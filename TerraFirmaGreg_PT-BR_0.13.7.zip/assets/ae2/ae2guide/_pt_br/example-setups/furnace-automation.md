---
navigation:
  parent: example-setups/example-setups-index.md
  title: Automação da Fornalha
  icon: minecraft:furnace
---

# Automação da Fornalha

Como esta configuração usa um <ItemLink id="pattern_provider" />, ela foi projetada para integrar seu sistema de [fabricação automática](../ae2-mechanics/autocrafting.md).
Se você só quiser automatizar uma Fornalha independente, use funis, baús e componentes semelhantes.

Automatizar uma <ItemLink id="minecraft:furnace" /> é um pouco mais complexo que automatizar máquinas mais simples, como um [Carregador](../example-setups/charger-automation.md).
Uma Fornalha exige entradas por dois lados diferentes e extração por um terceiro. O item a fundir deve ser inserido pela face superior,
o combustível deve entrar por uma face lateral e o resultado deve ser retirado por baixo. 

Isso poderia ser feito com um <ItemLink id="pattern_provider" />
na parte superior, um <ItemLink id="export_bus" /> na lateral para inserir combustível continuamente e um <ItemLink id="import_bus" />
na parte inferior para importar os resultados para a rede. Entretanto, isso usa 3 [canais](../ae2-mechanics/channels.md).

Veja como fazer isso usando apenas 1 canal:

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/furnace_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Provedor de Padrões: variante direcional obtida com uma Chave de Quartzo Certus, contendo os Padrões de Processamento relevantes.

        ![Padrão de Ferro](../assets/diagrams/furnace_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (2) Interface: em sua configuração padrão.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="1.3 2 1">
        (3) Ponto de Armazenamento nº 1: filtrado para Carvão.
        <ItemImage id="minecraft:coal" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 2 0" max="1 2.3 1">
        (4) Ponto de Armazenamento nº 2: filtrado para bloquear Carvão, usando um Cartão Inversor.
        <Row><ItemImage id="minecraft:coal" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        Para a Rede Principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurações

* O <ItemLink id="pattern_provider" /> (1) está em sua configuração padrão, com os <ItemLink id="processing_pattern" /> relevantes.
    Ele se torna direcional quando uma <ItemLink id="certus_quartz_wrench" /> é usada nele.

  ![Padrão de Ferro](../assets/diagrams/furnace_pattern.png)

* A <ItemLink id="interface" /> (2) está em sua configuração padrão.
* O primeiro <ItemLink id="storage_bus" /> (3) é filtrado para Carvão ou para qualquer combustível que você deseje usar.
* O segundo <ItemLink id="storage_bus" /> (4) é filtrado para bloquear o combustível usado por meio de um <ItemLink id="inverter_card" />.

## Como Funciona

1. O <ItemLink id="pattern_provider" /> envia os ingredientes à <ItemLink id="interface" />.
   (Na verdade, como otimização, ele os envia diretamente através dos Pontos de Armazenamento, como se fossem extensões das faces do Provedor. Os itens nunca entram de fato na Interface.)
2. A Interface está configurada para não armazenar nada, então tenta enviar os ingredientes ao [armazenamento da rede](../ae2-mechanics/import-export-storage.md).
3. Os únicos armazenamentos da sub-rede verde são os <ItemLink id="storage_bus" />. O ponto filtrado para Carvão coloca o carvão no espaço de combustível da Fornalha pela face lateral.
    O ponto filtrado para itens que NÃO sejam Carvão coloca os itens a fundir no espaço superior pela face de cima.
4. A Fornalha faz seu trabalho de fornalha.
5. O funil retira os resultados pela parte inferior da Fornalha e os coloca nos espaços de retorno do Provedor, devolvendo-os à rede principal.
