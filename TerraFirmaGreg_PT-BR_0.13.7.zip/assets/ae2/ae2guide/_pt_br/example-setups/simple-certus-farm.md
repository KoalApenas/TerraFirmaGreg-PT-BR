---
navigation:
  parent: example-setups/example-setups-index.md
  title: Fazenda Simples de Certus
  icon: certus_quartz_crystal
  position: 110
---

# Fazenda Simples de Certus

Como mencionado em [Crescimento de Certus](../ae2-mechanics/certus-growth.md), a automação da coleta de <ItemLink id="certus_quartz_crystal" />
envolve <ItemLink id="annihilation_plane" /> e <ItemLink id="storage_bus" />. 
Os <ItemLink id="growth_accelerator" /> são usados para acelerar enormemente o crescimento das gemas de quartzo Certus, e então os planos
quebram o <ItemLink id="quartz_cluster" /> totalmente crescido. A filtragem aproveita a característica curiosamente conveniente de que gemas ainda imaturas
de Certus derrubam <ItemLink id="certus_quartz_dust" /> em vez de não derrubarem nada.

Esta fazenda funciona de modo totalmente automático com <ItemLink id="flawless_budding_quartz" />, mas, com drusas imperfeitas, lascadas ou danificadas
de quartzo Certus, você terá de substituir a drusa manualmente. Ou fazer isso automaticamente, conforme descrito na [Fazenda Semiautomática de Certus](semiauto-certus-farm.md)
e na [Fazenda Avançada de Certus](advanced-certus-farm.md).

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/simple_certus_farm.snbt" />

  <BoxAnnotation color="#dddddd" min="3.7 1 1" max="4 2 2">
        (1) Plano de Aniquilação: Não possui interface para configurar, mas pode receber Fortuna.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="3.3 2 2">
        (2) Ponto de Armazenamento #1: Filtrado para Cristal de Quartzo Certus.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 .7" max="2 2 1">
        (3) Ponto de Armazenamento #2: Filtrado para Cristal de Quartzo Certus. Possui prioridade maior que a do armazenamento principal.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
        Para a Rede Principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurações

* O primeiro <ItemLink id="annihilation_plane" /> (1) não possui interface e não pode ser configurado, mas pode receber Fortuna.
* O primeiro <ItemLink id="storage_bus" /> (2) é filtrado para <ItemLink id="certus_quartz_crystal" />.
* O segundo <ItemLink id="storage_bus" /> (3) é filtrado para <ItemLink id="certus_quartz_crystal" /> e possui
  [prioridade](../ae2-mechanics/import-export-storage.md#storage-priority) maior que a do armazenamento principal.

## Como Funciona

1. O <ItemLink id="annihilation_plane" /> tenta quebrar o que estiver à sua frente, mas só consegue quebrar <ItemLink id="quartz_cluster" />
   porque o único armazenamento da sub-rede é o <ItemLink id="storage_bus" />, filtrado para <ItemLink id="certus_quartz_crystal" />.
4. O primeiro <ItemLink id="storage_bus" /> armazena os cristais de quartzo Certus no barril.
5. O segundo <ItemLink id="storage_bus" /> dá à rede principal acesso a todos os cristais de quartzo Certus no barril. Ele possui
   [prioridade](../ae2-mechanics/import-export-storage.md#storage-priority) alta para que os cristais de quartzo Certus sejam colocados preferencialmente
   de volta no barril, em vez de irem para o armazenamento principal.
