---
navigation:
  parent: example-setups/example-setups-index.md
  title: Reposição Automática com Emissor de Nível
  icon: level_emitter
---

# Reposição Automática com Emissor de Nível

Talvez você se pergunte: "Como mantenho em estoque uma quantidade específica de um item, fabricando mais conforme necessário?"

Uma solução é usar um <ItemLink id="export_bus" />, um <ItemLink id="level_emitter" /> e um <ItemLink id="crafting_card" /> para solicitar novos itens automaticamente
ao sistema de [fabricação automática](../ae2-mechanics/autocrafting.md) da rede. Esta configuração serve para manter uma grande quantidade de um único item.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/level_emitter_autostocking.snbt" />

  <BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (1) Ponto de Exportação: filtrado para o item desejado. Possui um Cartão de Redstone e um Cartão de Fabricação. Modo de Redstone definido como
        "Ativo com sinal" e Comportamento de Fabricação definido como "Não usar itens em estoque".
        <Row><ItemImage id="redstone_card" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0.7 1 0" max="1 2 1">
        (2) Emissor de Nível: configurado com o item e a quantidade desejados, definido como "Emitir quando os níveis estiverem abaixo do limite".
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (3) Interface: em sua configuração padrão.
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        Para a Rede Principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurações

* O <ItemLink id="export_bus" /> (1) é filtrado para o item desejado. Ele possui um <ItemLink id="redstone_card" /> e um <ItemLink id="crafting_card" />.
  O "Modo de Redstone" está definido como "Ativo com sinal" e o "Comportamento de Fabricação" como "Não usar itens em estoque".
* O <ItemLink id="level_emitter" /> (2) está configurado com o item e a quantidade desejados e definido como "Emitir quando os níveis estiverem abaixo do limite".
* A <ItemLink id="interface" /> (3) está em sua configuração padrão.

## Como Funciona

1. Se a quantidade do item desejado no [armazenamento da rede](../ae2-mechanics/import-export-storage.md) estiver abaixo do valor especificado no
   <ItemLink id="level_emitter" />, ele emitirá um sinal de Redstone.
2. Ao receber um sinal de Redstone (e por possuir o <ItemLink id="crafting_card" /> e estar configurado para não usar itens em estoque),
   o <ItemLink id="export_bus" /> solicitará que o sistema de [fabricação automática](../ae2-mechanics/autocrafting.md) da rede produza
   mais unidades do item desejado e, em seguida, o exportará.
3. Ao receber um item (sem estar configurada para manter nada em seu inventário interno), a <ItemLink id="interface" /> o enviará ao armazenamento da rede.
