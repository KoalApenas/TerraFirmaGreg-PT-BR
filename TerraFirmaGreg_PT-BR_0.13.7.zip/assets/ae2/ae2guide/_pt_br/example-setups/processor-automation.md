---
navigation:
  parent: example-setups/example-setups-index.md
  title: Automação de Processadores
  icon: inscriber
---

# Automação da Produção de Processadores

Há muitas maneiras de automatizar [processadores](../items-blocks-machines/processors.md), e esta é uma delas.

Este esquema geral pode ser montado com qualquer tipo de tubo, conduíte ou duto de logística de itens, qualquer que seja o nome usado pelo mod, desde
que ele possa ser filtrado.

![Diagrama de Fluxo do Processo](../assets/diagrams/processor_flow_diagram.png)

Veja aqui, em detalhes, como fazer isso apenas com o AE2, usando [sub-redes de tubo](pipe-subnet.md).

Observe que, como esta montagem usa um <ItemLink id="pattern_provider" />, ela foi projetada para integrar sua estrutura de [autofabricação](../ae2-mechanics/autocrafting.md).
Se você quiser apenas automatizar processadores de forma independente, substitua o provedor de padrões por outro barril e coloque os ingredientes diretamente no barril superior.

Esta montagem também é retrocompatível
com versões anteriores do AE2, pois, mesmo que os <ItemLink id="inscriber" /> tenham lados definidos, as sub-redes de tubo ainda inserem e
extraem pelas faces corretas.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/processor_automation.snbt" />

  <BoxAnnotation color="#dddddd" min="5 1 0" max="6 2 1" thickness=".05">
        (1) Provedor de Padrões: Na configuração padrão, com os padrões de processamento pertinentes.

        <Row>
            ![Padrão Lógico](../assets/diagrams/logic_pattern_small.png)
            ![Padrão de Cálculo](../assets/diagrams/calculation_pattern_small.png)
            ![Padrão de Engenharia](../assets/diagrams/engineering_pattern_small.png)
        </Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4.7 2 0" max="5 3 1" thickness=".05">
        (2) Ponto de Armazenamento #1: Na configuração padrão.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 0" max="4.3 2 1" thickness=".05">
        (3) Ponto de Exportação #1: Filtrado para Silício, possui 2 Cartões de Aceleração
        <Row><ItemImage id="silicon" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 4 0" max="4.3 3 1" thickness=".05">
        (4) Ponto de Exportação #2: Filtrado para Lingote de Ouro, possui 2 Cartões de Aceleração
        <Row><ItemImage id="minecraft:gold_ingot" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 5 0" max="4.3 4 1" thickness=".05">
        (5) Ponto de Exportação #3: Filtrado para Cristal de Quartzo Certus, possui 2 Cartões de Aceleração
        <Row><ItemImage id="certus_quartz_crystal" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 6 0" max="4.3 5 1" thickness=".05">
        (6) Ponto de Exportação #4: Filtrado para Diamante, possui 2 Cartões de Aceleração
        <Row><ItemImage id="minecraft:diamond" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 3 0" max="2 2 1" thickness=".05">
        (7) Ponto de Exportação #5: Filtrado para Pó de Redstone, possui 2 Cartões de Aceleração
        <Row><ItemImage id="minecraft:redstone" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 0" max="3 2 1" thickness=".05">
        (8) Inscritor #1: Na configuração padrão. Possui uma Prensa Inscritora de Silício e 4 Cartões de Aceleração
        <Row><ItemImage id="silicon_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 3 0" max="3 4 1" thickness=".05">
        (9) Inscritor #2: Na configuração padrão. Possui uma Prensa Inscritora Lógica e 4 Cartões de Aceleração
        <Row><ItemImage id="logic_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 4 0" max="3 5 1" thickness=".05">
        (10) Inscritor #3: Na configuração padrão. Possui uma Prensa Inscritora de Cálculo e 4 Cartões de Aceleração
        <Row><ItemImage id="calculation_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 5 0" max="3 6 1" thickness=".05">
        (11) Inscritor #4: Na configuração padrão. Possui uma Prensa Inscritora de Engenharia e 4 Cartões de Aceleração
        <Row><ItemImage id="engineering_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 2 0" max="1 3 1" thickness=".05">
        (12) Inscritor #5: Na configuração padrão. Possui 4 Cartões de Aceleração
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 2 0" max="3 1 1" thickness=".05">
        (13) Ponto de Importação #1: Na configuração padrão, possui 2 Cartões de Aceleração
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 4 0" max="3 3 1" thickness=".05">
        (14) Ponto de Importação #2: Na configuração padrão, possui 2 Cartões de Aceleração
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 5 0" max="3 4 1" thickness=".05">
        (15) Ponto de Importação #3: Na configuração padrão, possui 2 Cartões de Aceleração
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 6 0" max="3 5 1" thickness=".05">
        (16) Ponto de Importação #4: Na configuração padrão, possui 2 Cartões de Aceleração
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 3 0" max="1 3.3 1" thickness=".05">
        (17) Ponto de Armazenamento #2: Na configuração padrão.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1.7 0" max="1 2 1" thickness=".05">
        (18) Ponto de Armazenamento #3: Na configuração padrão.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 0" max="0.7 3 1" thickness=".05">
        (19) Ponto de Importação #5: Na configuração padrão, possui 2 Cartões de Aceleração
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="5 0.7 0" max="6 1 1" thickness=".05">
        (20) Ponto de Armazenamento #4: Na configuração padrão.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.3 2.7 0.3" max="3.7 3 0.7" thickness=".05">
        A Fibra de Quartzo fornece energia a todos os 3 Inscritores, pois os Inscritores agem como cabos e, portanto, transmitem energia
  </BoxAnnotation>

<DiamondAnnotation pos="7 1.5 0.5" color="#00ff00">
        Para a Rede Principal
    </DiamondAnnotation>

  <IsometricCamera yaw="185" pitch="5" />
</GameScene>

## Configurações

* O <ItemLink id="pattern_provider" /> (1) está na configuração padrão, com os <ItemLink id="processing_pattern" /> pertinentes.

  ![Padrão Lógico](../assets/diagrams/logic_pattern.png)
  ![Padrão de Cálculo](../assets/diagrams/calculation_pattern.png)
  ![Padrão de Engenharia](../assets/diagrams/engineering_pattern.png)

* Os <ItemLink id="storage_bus" /> (2, 17, 18, 20) estão nas configurações padrão.
* Os <ItemLink id="export_bus" /> (3-7) são filtrados para os ingredientes correspondentes. Eles possuem 2 <ItemLink id="speed_card" />.
    <Row>
      <ItemImage id="silicon" scale="2" />
      <ItemImage id="minecraft:gold_ingot" scale="2" />
      <ItemImage id="certus_quartz_crystal" scale="2" />
      <ItemImage id="minecraft:diamond" scale="2" />
      <ItemImage id="minecraft:redstone" scale="2" />
    </Row>
* Os <ItemLink id="import_bus" /> (13-16, 19) estão nas configurações padrão. Eles possuem 2 <ItemLink id="speed_card" />.
* Os <ItemLink id="inscriber" /> estão nas configurações padrão. Eles possuem a [prensa](../items-blocks-machines/presses.md) correspondente,
   e 4 <ItemLink id="speed_card" />.
   <Row>
     <ItemImage id="silicon_press" scale="2" />
     <ItemImage id="logic_processor_press" scale="2" />
     <ItemImage id="calculation_processor_press" scale="2" />
     <ItemImage id="engineering_processor_press" scale="2" />
   </Row>

## Como Funciona

1. O <ItemLink id="pattern_provider" /> envia os ingredientes para o barril.
2. A primeira [sub-rede de tubo](pipe-subnet.md) (laranja) retira do barril o silício, o pó de redstone e o ingrediente do processador correspondente
   (Lingote de Ouro, Cristal de Quartzo Certus ou Diamante) e os coloca no <ItemLink id="inscriber" /> apropriado.
3. Os primeiros quatro <ItemLink id="inscriber" /> produzem o <ItemLink id="printed_silicon" /> e o <ItemLink id="printed_logic_processor" />,
   <ItemLink id="printed_calculation_processor" /> ou <ItemLink id="printed_engineering_processor" />.
4. A segunda e a terceira [sub-redes de tubo](pipe-subnet.md) (verdes) retiram os circuitos impressos dos primeiros quatro <ItemLink id="inscriber" />
    e os colocam no quinto <ItemLink id="inscriber" />, responsável pela montagem final.
5. O quinto <ItemLink id="inscriber" /> monta o [processador](../items-blocks-machines/processors.md).
6. A quarta [sub-rede de tubo](pipe-subnet.md) (roxa) coloca o processador no provedor de padrões, devolvendo-o à rede principal.
