---
navigation:
  parent: example-setups/example-setups-index.md
  title: Fazenda Avançada de Certus
  icon: certus_quartz_crystal
  position: 120
---

# Fazenda Avançada de Certus

Esta configuração é basicamente a [Fazenda Semiautomática de Certus](semiauto-certus-farm.md), mas foi totalmente integrada ao seu
sistema ME.

Em vez de manter um grande estoque de blocos em brotamento e renová-los manualmente de tempos em tempos,
esta configuração usa a [Automação do Carregador](charger-automation.md) e a [Automação de Lançamento na Água](throw-in-water-automation.md)
para fazer isso automaticamente.

**ESTA É UMA CONSTRUÇÃO COMPLEXA, COM ELEMENTOS ESCONDIDOS ATRÁS DE OUTROS; MOVA A CÂMERA PARA OBSERVÁ-LA DE TODOS OS ÂNGULOS**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/advanced_certus_farm.snbt" />

  <BoxAnnotation color="#ddaaaa" min="3.7 2 1" max="4 3 2">
        (1) Plano de Aniquilação nº 1: não possui interface para configurar, mas pode receber o encantamento Fortuna.
  </BoxAnnotation>

  <BoxAnnotation color="#ddaaaa" min="2 2 1.7" max="3 3 2">
        (2) Ponto de Armazenamento nº 1: filtrado para Cristal de Quartzo Certus.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 2.5 1.5" color="#ff0000">
    Sub-rede Destruidora de Aglomerados
  </DiamondAnnotation>

  <BoxAnnotation color="#aaddaa" min="3.7 1 1" max="4 2 2">
        (3) Plano de Aniquilação nº 2: não possui interface para configurar, mas está encantado com Toque Suave.
  </BoxAnnotation>

  <BoxAnnotation color="#aaddaa" min="2 1 1.7" max="3 2 2">
        (4) Ponto de Armazenamento nº 2: filtrado para Bloco de Quartzo Certus.
        <BlockImage id="quartz_block" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 1.5 1.5" color="#00ff00">
    Sub-rede Destruidora de Blocos de Certus
  </DiamondAnnotation>

  <BoxAnnotation color="#ffddaa" min="4 0.7 1" max="5 1 2">
        (5) Plano de Formação: em sua configuração padrão.
  </BoxAnnotation>

  <BoxAnnotation color="#ffddaa" min="2 0.7 2" max="3 1 3">
        (6) Ponto de Importação: filtrado para Drusa de Quartzo Certus Imperfeita.
        <BlockImage id="flawed_budding_quartz" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 0.5 1.5" color="#ddcc00">
    Sub-rede Posicionadora de Blocos em Brotamento
  </DiamondAnnotation>

  <BoxAnnotation color="#aaaadd" min="1.7 2 2" max="2 3 3">
        (7) Ponto de Armazenamento nº 3: filtrado para Cristal de Quartzo Certus. Sua prioridade é maior que a do armazenamento principal.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#aaaadd" min="2 1 2" max="3 2 3">
        (8) Interface: configurada para manter 1 Drusa de Quartzo Certus Imperfeita dentro de si e equipada com um Cartão de Fabricação.
        <Row><BlockImage id="flawed_budding_quartz" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="1.5 0.5 0" color="#00ff00">
        Para a Rede Principal, a Automação do Carregador e a Automação de Lançamento na Água
        <Row>
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/charger_automation.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/throw_in_water.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
        </Row>
    </DiamondAnnotation>

  <IsometricCamera yaw="165" pitch="5" />
</GameScene>

## Configurações

### Destruidora de Aglomerados:

* O primeiro <ItemLink id="annihilation_plane" /> (1) não possui interface e não pode ser configurado, mas pode receber o encantamento Fortuna.
* O primeiro <ItemLink id="storage_bus" /> (2) é filtrado para <ItemLink id="certus_quartz_crystal" />.

### Destruidora de Blocos de Certus:

* O segundo <ItemLink id="annihilation_plane" /> (3) não possui interface e não pode ser configurado, mas precisa receber o encantamento Toque Suave.
* O segundo <ItemLink id="storage_bus" /> (4) é filtrado para <ItemLink id="quartz_block" />.

### Posicionadora de Blocos em Brotamento:

* O <ItemLink id="formation_plane" /> (5) está em sua configuração padrão.
* O <ItemLink id="import_bus" /> (6) é filtrado para <ItemLink id="flawed_budding_quartz" />.

### Na Rede Principal:

* O terceiro <ItemLink id="storage_bus" /> (7) é filtrado para <ItemLink id="certus_quartz_crystal" /> e tem sua
  [prioridade](../ae2-mechanics/import-export-storage.md#storage-priority) definida acima da prioridade do armazenamento principal.
* A <ItemLink id="interface" /> (8) está configurada para manter 1 Drusa de Quartzo Certus Imperfeita dentro de si e possui um <ItemLink id="crafting_card" />.

## Como Funciona

### Destruidora de Aglomerados:

A sub-rede destruidora de aglomerados funciona de modo muito semelhante à sub-rede da [fazenda simples de Certus](simple-certus-farm.md).

1. O <ItemLink id="annihilation_plane" /> tenta quebrar o que está à sua frente, mas só consegue quebrar um <ItemLink id="quartz_cluster" />
   porque o único armazenamento da sub-rede é o <ItemLink id="storage_bus" />, filtrado para <ItemLink id="certus_quartz_crystal" />.
2. O <ItemLink id="storage_bus" /> armazena os Cristais de Quartzo Certus no barril.

### Destruidora de Blocos de Certus

A sub-rede destruidora de blocos de Certus serve para quebrar o bloco em brotamento esgotado quando ele se transforma em um <ItemLink id="quartz_block" /> comum.
Ela funciona de modo semelhante à destruidora de aglomerados.

1. O <ItemLink id="annihilation_plane" /> tenta quebrar o que está à sua frente, mas só consegue quebrar um <ItemLink id="quartz_block" />
   porque o único armazenamento da sub-rede é o <ItemLink id="storage_bus" />, filtrado para <ItemLink id="quartz_block" />. 
   O plano precisa ter Toque Suave para que o bloco em brotamento não se degrade ao ser quebrado e, assim, não seja quebrado antes da hora.
2. O <ItemLink id="storage_bus" /> armazena o Bloco de Quartzo Certus na <ItemLink id="interface" />, permitindo que a
   [Automação de Lançamento na Água](throw-in-water-automation.md) o use para criar uma nova <ItemLink id="flawed_budding_quartz" />.

### Posicionadora de Blocos em Brotamento

A sub-rede posicionadora de blocos em brotamento serve para colocar uma nova <ItemLink id="flawed_budding_quartz" /> quando a sub-rede destruidora quebra o bloco antigo já esgotado.

1. O <ItemLink id="import_bus" /> importa um bloco em brotamento da <ItemLink id="interface" /> para o [armazenamento da rede](../ae2-mechanics/import-export-storage.md).
2. O único armazenamento da sub-rede é o <ItemLink id="formation_plane" />, que coloca o bloco em brotamento.

### Na Rede Principal

* O <ItemLink id="storage_bus" /> dá à rede principal (e também à [Automação do Carregador](charger-automation.md)) acesso a todos os Cristais de Quartzo Certus no barril. Ele está configurado com
  [prioridade](../ae2-mechanics/import-export-storage.md#storage-priority) alta para que os Cristais de Quartzo Certus sejam, de preferência,
  devolvidos ao barril em vez de enviados ao armazenamento principal.
* A <ItemLink id="interface" /> dá à sub-rede posicionadora de blocos em brotamento acesso a uma <ItemLink id="flawed_budding_quartz" /> e
    oferece à sub-rede destruidora de blocos de Certus uma forma de devolver os blocos esgotados à rede principal. O
    <ItemLink id="crafting_card" /> permite que a Interface solicite novos blocos em brotamento ao sistema de [fabricação automática](../ae2-mechanics/autocrafting.md) da rede principal.
