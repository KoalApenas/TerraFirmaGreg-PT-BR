---
navigation:
  parent: example-setups/example-setups-index.md
  title: Aplicação Automática de Fortuna em Minérios
  icon: minecraft:raw_iron
---

# Automação da Aplicação de Fortuna em Minérios

O <ItemLink id="annihilation_plane" /> pode receber qualquer encantamento de picareta, inclusive Fortuna; portanto, um uso evidente é
aplicar Fortuna a alguns deles e fazer <ItemLink id="formation_plane" /> e <ItemLink id="annihilation_plane" /> colocarem e
quebrarem minérios rapidamente.

Como os <ItemLink id="import_bus" /> aumentam gradualmente a velocidade, a configuração começará devagar e atingirá a velocidade máxima após alguns segundos.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/ore_fortuner.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 0 2" max="3 1 3">
        (1) Ponto de Importação: possui alguns Cartões de Aceleração.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 2" max="2 1 2.3">
        (2) Planos de Formação: em suas configurações padrão.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 0.7" max="2 1 1">
        (3) Planos de Aniquilação: não possuem interface para configurar, mas estão encantados com Fortuna.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 0 0" max="3 1 1">
        (4) Ponto de Armazenamento: em sua configuração padrão.
  </BoxAnnotation>

<DiamondAnnotation pos="3.5 0.5 2.5" color="#00ff00">
        Entrada
    </DiamondAnnotation>

<DiamondAnnotation pos="3.5 0.5 0.5" color="#00ff00">
        Saída
    </DiamondAnnotation>

<DiamondAnnotation pos="4 0.5 1.5" color="#00ff00">
        Para a Rede Principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurações

*   O <ItemLink id="import_bus" /> (1) possui alguns <ItemLink id="speed_card" />. Quanto mais Planos de Formação
    houver no conjunto, mais cartões serão necessários, pois eles fazem o Ponto de Importação retirar mais itens de uma vez.
*   Os <ItemLink id="formation_plane" /> (2) estão em suas configurações padrão.
*   Os <ItemLink id="annihilation_plane" /> (3) não possuem interface e não podem ser configurados, mas estão encantados com Fortuna.
*   O <ItemLink id="storage_bus" /> (4) está em sua configuração padrão.

## Como Funciona

1.  O <ItemLink id="import_bus" /> da sub-rede verde importa blocos do primeiro barril para o [armazenamento da rede](../ae2-mechanics/import-export-storage.md).
2.  O único armazenamento da sub-rede verde é o <ItemLink id="formation_plane" />, que coloca os blocos.
3.  O <ItemLink id="annihilation_plane" /> da sub-rede laranja quebra os blocos e aplica Fortuna a eles.
4.  O <ItemLink id="storage_bus" /> da sub-rede laranja armazena no segundo barril os resultados da quebra.
