---
navigation:
  parent: example-setups/example-setups-index.md
  title: Automação de Lançamento na Água
  icon: fluix_crystal
---

# Automação de Receitas por Lançamento na Água

Observe que, como esta montagem usa um <ItemLink id="pattern_provider" />, ela deve ser integrada à sua estrutura de [autofabricação](../ae2-mechanics/autocrafting.md)
já existente.

Algumas receitas exigem que itens sejam lançados na água — embora uma montagem semelhante possa lançá-los em outros lugares.
Isso pode ser automatizado com um <ItemLink id="formation_plane" />, um <ItemLink id="annihilation_plane" /> e alguma
infraestrutura de apoio — essencialmente, são 2 [sub-redes de tubo](pipe-subnet.md) modificadas.

Esta montagem deve ser usada em conjunto com a [automação do carregador](charger-automation.md) para fornecer os <ItemLink id="charged_certus_quartz_crystal" />.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/throw_in_water.snbt" />

<BoxAnnotation color="#dddddd" min="2 0 1" max="3 1 2">
        (1) Provedor de Padrões: Na configuração padrão, com os padrões de processamento pertinentes.

        ![Padrão de Fluix](../assets/diagrams/fluix_pattern_small.png) ![Padrão de Drusa Imperfeita](../assets/diagrams/flawed_budding_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1.7 0 1" max="2 1 2">
        (2) Interface: Na configuração padrão.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 .7 1" max="2 1 2">
        (3) Plano de Formação: Configurado para soltar as entradas como itens.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 2 1" max="2 2.3 2">
        (4) Plano de Aniquilação: Não possui interface para configurar.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
        (5) Ponto de Armazenamento: Filtrado para as saídas dos padrões
        <Row><ItemImage id="fluix_crystal" scale="2" /><BlockImage id="flawless_budding_quartz" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="3.9 0.5 1.5" color="#00ff00">
        Para a Rede Principal e a Automação do Carregador
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/charger_automation.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
    </DiamondAnnotation>

  <IsometricCamera yaw="180" pitch="0" />
</GameScene>

## Configurações e Padrões

* O <ItemLink id="pattern_provider" /> (1) está na configuração padrão, com os <ItemLink id="processing_pattern" /> pertinentes
  * Para <ItemLink id="fluix_crystal" />, a receita padrão do JEI/REI funciona bem:

    ![Padrão de Fluix](../assets/diagrams/fluix_pattern.png)

  * Para <ItemLink id="flawed_budding_quartz" />, provavelmente é melhor produzi-la diretamente a partir de <ItemLink id="quartz_block" />,
    evitando problemas em que a entrada de uma receita é a saída de outra e impede o ponto de armazenamento de filtrar corretamente:

    ![Padrão de Drusa Imperfeita](../assets/diagrams/flawed_budding_pattern.png)

* A <ItemLink id="interface" /> (2) está na configuração padrão.
* O <ItemLink id="formation_plane" /> (3) está configurado para soltar as entradas como itens.
* O <ItemLink id="annihilation_plane" /> (4) não possui interface e não pode ser configurado.
* O <ItemLink id="storage_bus" /> (5) é filtrado para as saídas dos padrões.

## Como Funciona

1.  O <ItemLink id="pattern_provider" /> envia os ingredientes para a <ItemLink id="interface" /> ao seu lado, na sub-rede verde
2.  A interface — configurada para não armazenar nada por padrão — tenta enviar seu conteúdo ao [armazenamento da rede](../ae2-mechanics/import-export-storage.md)
3.  O único armazenamento da sub-rede verde é o <ItemLink id="formation_plane" />, que solta na água os itens recebidos
4.  O <ItemLink id="annihilation_plane" /> da sub-rede laranja tenta recolher os itens que acabaram de ser soltos, mas não consegue, pois
    o <ItemLink id="storage_bus" /> sobre o provedor de padrões — o único armazenamento da sub-rede laranja — só aceita os resultados das fabricações possíveis
5.  Os itens realizam sua transformação no mundo.
6.  O plano de aniquilação agora consegue recolher os itens à sua frente, pois o ponto de armazenamento pode armazená-los.
7.  O ponto de armazenamento guarda os itens resultantes no provedor de padrões, devolvendo-os à rede.
