---
navigation:
  parent: example-setups/example-setups-index.md
  title: Armazenamento Local Especializado
  icon: drive
---

# Armazenamento Local Especializado

Usando um dos [comportamentos especiais da Interface](../items-blocks-machines/interface.md#special-interactions), uma
[sub-rede](../ae2-mechanics/subnetworks.md) pode apresentar o conteúdo de seu armazenamento à rede principal sem conseguir
ver o armazenamento da rede principal e ocupando apenas 1 [canal](../ae2-mechanics/channels.md).

Isso é útil para o armazenamento local de uma fazenda, evitando que os itens transbordem para o armazenamento principal.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/local_storage.snbt" />

<BoxAnnotation color="#dddddd" min="4 0 0" max="5 2 1">
        (1) Algum método para importar itens (neste caso, uma Interface)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 0 0" max="4 1 1">
        (2) Gabinete ME: Contém algumas células. As células devem ser filtradas para os itens produzidos pela fazenda.
        As células podem receber Cartões de Distribuição Igualitária e Cartões de Destruição de Sobras.
        <Row><ItemImage id="item_storage_cell_4k" scale="2" /> <ItemImage id="equal_distribution_card" scale="2" /> <ItemImage id="void_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1 0" max="4 2 0.3">
        (3) Terminal de Fabricação: Pode ver o conteúdo do Gabinete ME na sub-rede, mas não o conteúdo do armazenamento da rede principal.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0 0" max="2.3 1 1">
        (4) Interface #2: Na configuração padrão.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1.7 0 0" max="2 1 1">
        (5) Ponto de Armazenamento: Possui prioridade maior que a do armazenamento principal e pode ser filtrado para os itens produzidos pela fazenda.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 2 0.3">
        Terminal de Fabricação: Pode ver tanto o conteúdo do armazenamento da rede principal quanto o da *sub-rede*.
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        Para a Rede Principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurações

* A primeira <ItemLink id="interface" /> (1) simplesmente recebe os itens da fazenda escolhida e os envia para a sub-rede.
* O <ItemLink id="drive" /> (2) contém algumas [células](../items-blocks-machines/storage_cells.md). Elas devem ser
  [particionadas](../items-blocks-machines/cell_workbench.md) para os itens produzidos pela fazenda.
  As células podem receber <ItemLink id="equal_distribution_card" /> e <ItemLink id="void_card" />.
* A segunda <ItemLink id="interface" /> (4) está na configuração padrão.
* O <ItemLink id="storage_bus" /> possui [prioridade](../ae2-mechanics/import-export-storage.md#storage-priority)
  maior que a do armazenamento principal. Ele pode ser filtrado para os itens produzidos pela fazenda.

## Como Funciona

* A <ItemLink id="interface" /> da sub-rede mostra ao <ItemLink id="storage_bus" /> da rede principal o conteúdo do
<ItemLink id="drive" />. Isso significa que o ponto de armazenamento pode retirar itens diretamente das células do gabinete ou inseri-los nelas.
* O ponto de armazenamento possui [prioridade](../ae2-mechanics/import-export-storage.md#storage-priority) alta para que os itens sejam colocados preferencialmente
  de volta na sub-rede, em vez de irem para o armazenamento principal.
* É importante observar que, se as células da sub-rede ficarem cheias, os itens não transbordarão para a rede principal. Se a fazenda for do tipo
que para de funcionar quando fica congestionada, <ItemLink id="void_card" /> podem ser usados para destruir os itens excedentes. 
* Se a fazenda produzir vários itens, <ItemLink id="equal_distribution_card" /> podem impedir que um deles ocupe todas as células
e impossibilite o armazenamento dos demais.
