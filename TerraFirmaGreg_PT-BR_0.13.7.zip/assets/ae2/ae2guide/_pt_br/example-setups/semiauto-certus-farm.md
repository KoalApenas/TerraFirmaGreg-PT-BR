---
navigation:
  parent: example-setups/example-setups-index.md
  title: Fazenda Semiautomática de Certus
  icon: certus_quartz_crystal
  position: 115
---

# Fazenda Semiautomática de Certus

Infelizmente, a [fazenda simples de Certus](simple-certus-farm.md) exige uma <ItemLink id="flawless_budding_quartz" /> para funcionar de modo totalmente
automático. Isso requer usar [E/S Espacial](../ae2-mechanics/spatial-io.md) ou construir a fazenda no [meteorito](../ae2-mechanics/meteorites.md).

Porém, o AE2 consegue colocar e quebrar blocos, então talvez
seja possível fazer sua fazenda *substituir a drusa de Certus para você*. (Periodicamente, você terá de inserir algumas
<ItemLink id="flawed_budding_quartz" /> no barril de entrada e retirar <ItemLink id="quartz_block" /> do barril de
drusas de Certus esgotadas.)

Para fazer isso de modo totalmente automático, consulte a [Fazenda Avançada de Certus](advanced-certus-farm.md).

Esta fazenda é um pouco mais complexa que a [fazenda simples de Certus](simple-certus-farm.md), pois na verdade consiste em
3 montagens diferentes reunidas no mesmo espaço.

**ESTA É UMA CONSTRUÇÃO COMPLEXA, COM ELEMENTOS ESCONDIDOS ATRÁS DE OUTROS; MOVA A CÂMERA PARA OBSERVÁ-LA DE TODOS OS ÂNGULOS**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/semiauto_certus_farm.snbt" />

  <BoxAnnotation color="#ddaaaa" min="3.7 2 1" max="4 3 2">
        (1) Plano de Aniquilação #1: Não possui interface para configurar, mas pode receber Fortuna.
  </BoxAnnotation>

  <BoxAnnotation color="#ddaaaa" min="2 2 1" max="2.3 3 2">
        (2) Ponto de Armazenamento #1: Filtrado para Cristal de Quartzo Certus.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 2.5 1.5" color="#ff0000">
    Sub-rede Quebradora de Aglomerados
  </DiamondAnnotation>

  <BoxAnnotation color="#aaddaa" min="3.7 1 1" max="4 2 2">
        (3) Plano de Aniquilação #2: Não possui interface para configurar, mas recebe Toque Suave.
  </BoxAnnotation>

  <BoxAnnotation color="#aaddaa" min="2 1 1" max="2.3 2 2">
        (4) Ponto de Armazenamento #2: Filtrado para Bloco de Quartzo Certus.
        <BlockImage id="quartz_block" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 1.5 1.5" color="#00ff00">
    Sub-rede Quebradora de Blocos de Certus
  </DiamondAnnotation>

  <BoxAnnotation color="#ffddaa" min="4 0.7 1" max="5 1 2">
        (5) Plano de Formação: Na configuração padrão.
  </BoxAnnotation>

  <BoxAnnotation color="#ffddaa" min="2 0 1" max="2.3 1 2">
        (6) Ponto de Importação: Na configuração padrão.
  </BoxAnnotation>

  <DiamondAnnotation pos="3 0.5 1.5" color="#ddcc00">
    Sub-rede Posicionadora de Drusas
  </DiamondAnnotation>

  <BoxAnnotation color="#aaaadd" min="0.7 2 1" max="1 3 2">
        (7) Ponto de Armazenamento #3: Filtrado para Cristal de Quartzo Certus. Possui prioridade maior que a do armazenamento principal.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

    <DiamondAnnotation pos="1.5 0.5 1.5" color="#00ff00">
        Insira manualmente Drusa de Quartzo Certus Imperfeita.
        <BlockImage id="flawed_budding_quartz" scale="2" />
    </DiamondAnnotation>

    <DiamondAnnotation pos="1.5 1.5 1.5" color="#00ff00">
        Retire manualmente Bloco de Quartzo Certus.
        <BlockImage id="quartz_block" scale="2" />
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0" color="#00ff00">
        Para a Rede Principal
    </DiamondAnnotation>

  <IsometricCamera yaw="165" pitch="5" />
</GameScene>

## Configurações

### Quebrador de Aglomerados:

* O primeiro <ItemLink id="annihilation_plane" /> (1) não possui interface e não pode ser configurado, mas pode receber Fortuna.
* O primeiro <ItemLink id="storage_bus" /> (2) é filtrado para <ItemLink id="certus_quartz_crystal" />.

### Quebrador de Blocos de Certus:

* O segundo <ItemLink id="annihilation_plane" /> (3) não possui interface e não pode ser configurado, mas precisa receber Toque Suave.
* O segundo <ItemLink id="storage_bus" /> (4) é filtrado para <ItemLink id="quartz_block" />.

### Posicionador de Drusas:

* O <ItemLink id="formation_plane" /> (5) está na configuração padrão.
* O <ItemLink id="import_bus" /> (6) está na configuração padrão.

### Na Rede Principal:

* O terceiro <ItemLink id="storage_bus" /> (7) é filtrado para <ItemLink id="certus_quartz_crystal" /> e possui
  [prioridade](../ae2-mechanics/import-export-storage.md#storage-priority) maior que a do armazenamento principal.

## Como Funciona

### Quebrador de Aglomerados:

A sub-rede quebradora de aglomerados funciona de forma muito semelhante à sub-rede da [fazenda simples de Certus](simple-certus-farm.md).

1. O <ItemLink id="annihilation_plane" /> tenta quebrar o que estiver à sua frente, mas só consegue quebrar <ItemLink id="quartz_cluster" />
   porque o único armazenamento da sub-rede é o <ItemLink id="storage_bus" />, filtrado para <ItemLink id="certus_quartz_crystal" />.
2. O <ItemLink id="storage_bus" /> armazena os cristais de quartzo Certus no barril.

### Quebrador de Blocos de Certus

A sub-rede quebradora de blocos de Certus serve para quebrar a drusa esgotada assim que ela se transforma em um simples <ItemLink id="quartz_block" />.
Ela funciona de forma semelhante ao quebrador de aglomerados.

1. O <ItemLink id="annihilation_plane" /> tenta quebrar o que estiver à sua frente, mas só consegue quebrar <ItemLink id="quartz_block" />
   porque o único armazenamento da sub-rede é o <ItemLink id="storage_bus" />, filtrado para <ItemLink id="quartz_block" />.
   O plano precisa ter Toque Suave para que a drusa não se degrade ao ser quebrada e, assim, não seja destruída prematuramente pelo plano.
2. O <ItemLink id="storage_bus" /> armazena o bloco de quartzo Certus no barril de
   drusas de Certus esgotadas; você terá de lançá-lo manualmente na água com <ItemLink id="charged_certus_quartz_crystal" /> para restaurá-lo.

### Posicionador de Drusas

A sub-rede posicionadora de drusas coloca uma nova <ItemLink id="flawed_budding_quartz" /> quando a sub-rede quebradora destrói a antiga drusa esgotada.

1. O <ItemLink id="import_bus" /> importa uma drusa do barril de entrada.
2. O único armazenamento da sub-rede é o <ItemLink id="formation_plane" />, que coloca a drusa.

### Na Rede Principal

* O <ItemLink id="storage_bus" /> dá à rede principal — e também à [Automação do Carregador](charger-automation.md) — acesso a todos os cristais de quartzo Certus no barril. Ele possui
  [prioridade](../ae2-mechanics/import-export-storage.md#storage-priority) alta para que os cristais de quartzo Certus sejam colocados preferencialmente
  de volta no barril, em vez de irem para o armazenamento principal.
