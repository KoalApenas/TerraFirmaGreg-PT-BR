---
navigation:
  parent: example-setups/example-setups-index.md
  title: Esvaziador ou Preenchedor de Células
  icon: io_port
---

# Esvaziador ou Preenchedor de Células

Talvez você se pergunte: "Como esvazio rapidamente uma célula em um baú, conjunto de gavetas ou mochila ou, no sentido inverso, preencho uma célula a partir deles?"

A resposta é usar um <ItemLink id="io_port" /> e algumas sub-redes para restringir onde ele pode colocar itens ou de onde pode retirá-los.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/cell_dumper_filler.snbt" />

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 2 1">
        (1) Porto de Entrada/Saída para Itens e Fluidos: pode ser configurado como "Transferir dados para a rede" ou "Transferir dados para a célula de armazenamento" usando o botão de seta
        no centro da interface. Possui 3 Cartões de Aceleração.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0.7 0" max="1 1 1">
        (2) Ponto de Armazenamento: em sua configuração padrão.
  </BoxAnnotation>

<BoxAnnotation color="#33dd33" min="0 1 0" max="1 2 1">
        Coloque aqui o que deseja preencher ou esvaziar.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0.35 0.35" max="2.3 0.65 0.65">
        Fibra de Quartzo: necessária somente quando a fonte de energia é outra rede.
  </BoxAnnotation>

<DiamondAnnotation pos="3 0.5 0.5" color="#00ff00">
        Para alguma fonte de energia, como outra rede ou um Aceitador de Energia.
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurações

* O <ItemLink id="io_port" /> (1) pode ser configurado como "Transferir dados para a rede" ou "Transferir dados para a célula de armazenamento" usando o botão de seta
  no centro da interface. Ele possui 3 Cartões de Aceleração para atingir a velocidade máxima.
* O <ItemLink id="storage_bus" /> (2) está em sua configuração padrão.

## Como Funciona

### No Modo "Transferir para a Rede"

1. O <ItemLink id="io_port" /> tenta descarregar o conteúdo da [célula de armazenamento](../items-blocks-machines/storage_cells.md) inserida
    no [armazenamento da rede](../ae2-mechanics/import-export-storage.md).
2. O único armazenamento da sub-rede é o <ItemLink id="storage_bus" />, que armazena os itens, fluidos ou outros conteúdos em qualquer inventário
    colocado à sua frente.
* A <ItemLink id="energy_cell" /> fornece uma reserva de [energia](../ae2-mechanics/energy.md) grande o bastante para que a rede
    não fique sem energia devido ao consumo da transferência de tantos itens por tick de jogo.

### No Modo "Transferir para a Célula de Armazenamento"

1. O <ItemLink id="io_port" /> tenta descarregar o conteúdo do [armazenamento da rede](../ae2-mechanics/import-export-storage.md)
   na [célula de armazenamento](../items-blocks-machines/storage_cells.md) inserida.
2. O único armazenamento da sub-rede é o <ItemLink id="storage_bus" />, que retira os itens, fluidos ou outros conteúdos de qualquer inventário
   colocado à sua frente.
* A <ItemLink id="energy_cell" /> fornece uma reserva de [energia](../ae2-mechanics/energy.md) grande o bastante para que a rede
  não fique sem energia devido ao consumo da transferência de tantos itens por tick de jogo.
