---
navigation:
  parent: example-setups/example-setups-index.md
  title: Fazenda de Ametista
  icon: minecraft:amethyst_shard
---

# Cultivo de Ametista

Embora o <ItemLink id="growth_accelerator" /> funcione com ametista, os métodos comuns para filtrar [brotos de Certus](../items-blocks-machines/budding_certus.md)
com um <ItemLink id="annihilation_plane" /> não funcionam com brotos de ametista. Ao contrário dos brotos imaturos de Certus, que soltam
<ItemLink id="certus_quartz_dust" />, brotos imaturos de ametista não soltam nada; por isso, um Plano de Aniquilação sempre os quebrará,
pois uma rede sempre pode armazenar “nada”.

A solução é encantar o Plano de Aniquilação com Toque Suave. Assim, os brotos imaturos de ametista *passam* a soltar algo
(os blocos físicos correspondentes às diferentes fases do broto) e, portanto, podem ser filtrados.

O <ItemLink id="minecraft:amethyst_cluster" /> deve então ser recolocado por um <ItemLink id="formation_plane" /> para, em seguida, ser
quebrado novamente por um <ItemLink id="annihilation_plane" /> sem Toque Suave, produzindo <ItemLink id="minecraft:amethyst_shard" />.

Observe que, devido à orientação do aglomerado, deve haver uma face sólida de bloco diretamente em frente ao Plano de Formação.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/amethyst_farm.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 1 1" max="3 2 2">
        (1) Plano de Aniquilação nº 1: não possui interface para configurar, mas está encantado com Toque Suave.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1 1" max="2.3 2 2">
        (2) Plano de Formação: filtrado para Aglomerado de Ametista.
        <ItemImage id="minecraft:amethyst_cluster" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 0.7 1" max="2 1 2">
        (3) Plano de Aniquilação nº 2: não possui interface para configurar, mas pode receber o encantamento Fortuna.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 1" max="1.3 1 2">
        (4) Ponto de Armazenamento nº 1: filtrado para Fragmento de Ametista.
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 .7" max="1 1 1">
        (5) Ponto de Armazenamento nº 2: filtrado para Fragmento de Ametista. Sua prioridade é maior que a do armazenamento principal.
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        Para a Rede Principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurações

* O primeiro <ItemLink id="annihilation_plane" /> (1) não possui interface e não pode ser configurado, mas precisa receber o encantamento Toque Suave.
* O <ItemLink id="formation_plane" /> (2) é filtrado para <ItemLink id="minecraft:amethyst_cluster" />.
* O segundo <ItemLink id="annihilation_plane" /> (3) não possui interface e não pode ser configurado, mas pode receber o encantamento Fortuna.
* O primeiro <ItemLink id="storage_bus" /> (4) é filtrado para <ItemLink id="minecraft:amethyst_shard" />.
* O segundo <ItemLink id="storage_bus" /> (5) é filtrado para <ItemLink id="minecraft:amethyst_shard" /> e tem sua
  [prioridade](../ae2-mechanics/import-export-storage.md#storage-priority) definida acima da prioridade do armazenamento principal.

## Como Funciona

1. O primeiro <ItemLink id="annihilation_plane" /> tenta quebrar o que está à sua frente, mas só consegue quebrar um <ItemLink id="minecraft:amethyst_cluster" />
    porque o único armazenamento da sub-rede é o <ItemLink id="formation_plane" />, filtrado para Aglomerado de Ametista. Isso só funciona porque
o plano está encantado com Toque Suave; caso contrário, ele conseguiria quebrar brotos imaturos, pois eles não soltam nada.
2. O <ItemLink id="formation_plane" /> coloca o aglomerado no bloco à sua frente.
3. O segundo <ItemLink id="annihilation_plane" /> quebra o aglomerado, produzindo <ItemLink id="minecraft:amethyst_shard" />.
4. O primeiro <ItemLink id="storage_bus" /> armazena os fragmentos no barril. Tecnicamente, ele não precisa ser filtrado, pois a única
coisa que o segundo Plano de Aniquilação deve encontrar são aglomerados totalmente crescidos.
5. O segundo <ItemLink id="storage_bus" /> dá à rede principal acesso a todos os Fragmentos de Ametista do barril. Ele está configurado com
[prioridade](../ae2-mechanics/import-export-storage.md#storage-priority) alta para que os Fragmentos de Ametista sejam, de preferência,
devolvidos ao barril em vez de enviados ao armazenamento principal.
