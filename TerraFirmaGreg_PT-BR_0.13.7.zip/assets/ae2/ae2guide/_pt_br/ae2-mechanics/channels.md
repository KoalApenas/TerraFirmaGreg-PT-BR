---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Canais
  icon: controller
---

# Canais

As [Redes ME](me-network-connections.md) do Applied Energistics 2 exigem
Canais para dar suporte aos [dispositivos](../ae2-mechanics/devices.md) que usam armazenamento em rede ou outros
serviços de rede. Pense nos canais como cabos USB ligados a todos os dispositivos. Um computador possui uma quantidade limitada de portas USB e só consegue comportar
determinada quantidade de dispositivos conectados. A maioria das máquinas, dos dispositivos de bloco inteiro e dos cabos comuns só consegue transmitir
até 8 canais. Você pode imaginar os dispositivos de bloco inteiro e os cabos comuns como um feixe de 8 “fios de canal”. Porém, os [cabos densos](../items-blocks-machines/cables.md#dense-cable) comportam
até 32 canais. Os únicos outros dispositivos capazes de transmitir 32 são o <ItemLink id="me_p2p_tunnel" />
e a [Ponte de Rede Quântica](../items-blocks-machines/quantum_bridge.md). Sempre que um dispositivo consome um canal, imagine retirar um “fio” USB
do feixe, o que evidentemente significa que esse “fio” não estará disponível mais adiante.

<GameScene zoom="7" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_demonstration_1.snbt" />

  <LineAnnotation color="#33ff33" from="1 .4 .7" to="2.4 .4 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .7" to="2.4 .6 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .6" to="2.6 .4 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.4 .6 .7" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .4 .7" to="2.4 .4 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .6 .6" to="2.6 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 .6" to="2.6 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.1 .6 1.5" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 1.5" to="2.9 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.6 .6 1.5" to="2.6 .9 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .1 1.5" to="2.4 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .4" to="3.5 .6 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="3.5 .6 .4" to="3.5 .9 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="3.5 .1 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .3" to="1.5 .6 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1.5 .6 .3" to="1.5 .9 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1.5 .1 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#ff3333" from="3.5 .5 .5" to="5.5 .5 .5" alwaysOnTop={true}>
  Todos os 8 canais do cabo foram usados, portanto o Gabinete ME não recebe nenhum.  
  </LineAnnotation>

  <LineAnnotation color="#993333" from="1 .5 .5" to="1.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="1.5 .5 .5" to="1.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2 .5 .5" to="2.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2.5 .5 .5" to="2.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="3 .5 .5" to="3.25 .5 .5" alwaysOnTop={true}/>

  <DiamondAnnotation pos="3.6 0.5 0.5" color="#ff0000">
        Todos os 8 canais do cabo foram usados, portanto o Gabinete ME não recebe nenhum.
    </DiamondAnnotation>

  <IsometricCamera yaw="15" pitch="30" />
</GameScene>

Uma maneira simples de visualizar como os canais são usados e roteados pela rede é utilizar [cabos inteligentes](../items-blocks-machines/cables.md), que exibem os caminhos e a utilização dos canais.

Os canais consomem 1⁄128 AE/t por nó atravessado; isso significa que,
ao adicionar um <ItemLink id="controller" /> a uma
rede com 8 dispositivos e mais de 96 nós, seu uso de energia pode na verdade
diminuir, pois isso altera a maneira como os canais são alocados.

É importante observar que **OS CANAIS NÃO TÊM NENHUMA RELAÇÃO COM A COR DO CABO**; a cor serve apenas para impedir que determinados cabos se conectem.

## Roteamento de Canais

Ao usar um <ItemLink id="controller" />,
os canais são roteados em 3 etapas. Primeiro, seguem o caminho mais curto pelas máquinas adjacentes até o [cabo comum](../items-blocks-machines/cables.md) mais próximo
— de vidro, revestido ou inteligente. Depois, seguem o caminho mais curto por esse cabo comum até o [cabo denso](../items-blocks-machines/cables.md) mais próximo
— denso ou inteligente denso. Por fim, seguem o caminho mais curto pelo cabo denso até o <ItemLink id="controller" />.
Se o caminho mais curto já estiver na capacidade máxima, alguns [dispositivos](devices.md) podem não receber os canais necessários. Use
cabos coloridos, âncoras de cabo e túneis a seu favor para garantir que os canais sigam o caminho desejado.

Por exemplo, neste caso alguns gabinetes não recebem canais porque, embora haja capacidade suficiente nos cabos,
os canais tentam seguir o caminho mais curto, sobrecarregando alguns cabos e deixando outros vazios.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 3.6" to="1.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.4 0.5 3.6" to="1.4 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 1.6" to="0.6 .5 1.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 1.6" to="0.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 3.4" to="1.4 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 3.4" to="1.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <BoxAnnotation color="#dddddd" min="1.2 0.2 3.2" max="1.8 0.8 3.8" alwaysOnTop={true} thickness="0.05">
        Mais de 8 canais tentam passar por aqui, portanto alguns são interrompidos.
  </BoxAnnotation>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

Isso pode ser corrigido limitando com mais cuidado os caminhos disponíveis aos canais. As redes devem ter formato de árvore — ou arbusto.
Ciclos e caminhos de canal ambíguos devem ser minimizados.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue_fix.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 5.6" to="1 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

## Redes Ad Hoc

Uma Rede sem um <ItemLink id="controller" />
é considerada Ad Hoc e comporta até 8 dispositivos que usam canais.
Ao ultrapassar 8 dispositivos, aqueles que usam canais na rede serão desligados;
você pode remover dispositivos ou adicionar um <ItemLink id="controller" />.

Diferentemente das redes com controlador, os [cabos inteligentes](../items-blocks-machines/cables.md) em redes ad hoc exibem a quantidade
de canais usados em toda a rede, e não a quantidade de canais que passa por aquele cabo específico.

Em redes ad hoc, cada dispositivo
usa 1 canal em toda a rede. Isso é muito diferente da forma como um <ItemLink id="controller" /> aloca canais de acordo com
o caminho mais curto.

## Projeto

Como mencionado anteriormente em [roteamento de canais](channels.md#channel-routing), o melhor é projetar a rede em forma de árvore: cabos densos ramificam-se a partir do controlador e cabos comuns
ramificam-se a partir dos densos, com grupos de 8 [dispositivos](../ae2-mechanics/devices.md) ou menos nos cabos comuns.

Este é um exemplo do que não fazer:

Acompanhando os caminhos dos canais:

1. Logo ao sair do controlador para a direita, ficamos limitados a 8 canais porque o gabinete age como um cabo comum.
Porém, como não estamos usando um cabo inteligente aqui, não podemos ver quantos canais estão em uso. Restam 8 canais.
2. O gabinete consome um canal.
Restam 7 canais.
3. 2 canais sobem até os terminais.
Restam 5 canais.
4. Continuando para a direita, a interface consome outro canal.
Restam 4 canais.
5. 1 canal sobe até o provedor de padrões.
Restam 3 canais.
6. Continuando para a direita, 1 canal sobe até o ponto de importação.
Restam 2 canais.
7. O grupo de provedores de padrões que alimenta os montadores recebe apenas 2 canais, portanto 2 provedores ficam sem canais.

Em última análise, o erro está em criar um gargalo para os canais e não considerar como eles serão distribuídos.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/bad_network_structure.snbt" />

<LineAnnotation color="#33ff33" from="6.5 .5 1.5" to="6 .5 1.5" alwaysOnTop={true} thickness="0.4">
  32 canais
</LineAnnotation>

<LineAnnotation color="#33ff33" from="6 .5 1.5" to="5.5 .5 1.5" alwaysOnTop={true} thickness="0.2">
  8 canais
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 1.5 1.5" alwaysOnTop={true} thickness="0.1">
  2 canais
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 1.5 1.5" to="5.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 2.5 1.5" to="5.5 2.5 1.1" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="4.5 .5 1.5" alwaysOnTop={true} thickness="0.158">
  5 canais
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 1.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="3.5 .5 1.5" alwaysOnTop={true} thickness="0.122">
  3 canais
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="3.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 2.5 1.5" to="3.7 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="1.5 .5 1.5" alwaysOnTop={true} thickness="0.1">
  2 canais
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="1.5 0.3 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="0.5 0.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="0.5 0.5 1.5" to="0.5 0.5 0.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#ff3333" from="0.5 1.5 1.5" to="0.5 1.3 1.5" alwaysOnTop={true} thickness="0.071">
  sem canais
</LineAnnotation>

<LineAnnotation color="#ff3333" from="1.5 1.5 0.5" to="1.5 1.3 0.5" alwaysOnTop={true} thickness="0.071">
  sem canais
</LineAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

---

Este é um exemplo de uma boa estrutura:

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/treelike_network_structure.snbt" />

    <BoxAnnotation color="#dddddd" min="6.9 0 4.9" max="9.1 4 7.1" thickness="0.05">
        Observe que os provedores de padrões estão em grupos separados de 8.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 4 4" max="8 5 5" thickness="0.05">
        Quando dois cabos comuns cheios de canais se encontram, é necessário usar um cabo denso.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 0 13" max="8 1 14" thickness="0.05">
        Cabos de cores diferentes são usados para impedir a conexão entre cabos adjacentes.
    </BoxAnnotation>


  <IsometricCamera yaw="315" pitch="30" />
</GameScene>

## Modos de Canal

O AE2 10.0.0 para Minecraft 1.18 introduz novas opções para alterar o funcionamento dos canais do AE2 em seu mundo.
Há uma nova opção na seção geral das configurações (`channels`) que controla esse comportamento, além de um novo
comando para operadores alterarem o modo e a configuração dentro do jogo. O comando é `/ae2 channelmode <mode>`
para alterá-lo e `/ae2 channelmode` para exibir o modo atual. Quando o modo é alterado no jogo, todas as redes existentes
reiniciam e passam a usar o novo modo imediatamente.

Isso recupera e aprimora a opção disponível no Minecraft 1.12 e introduz alternativas melhores para
jogadores que desejam uma experiência um pouco mais tranquila sem remover completamente essa mecânica.

A tabela a seguir lista os modos disponíveis tanto no arquivo de configuração quanto no comando.

| Configuração | Descrição                                                                                                                                                                                                                               |
| ---------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `default`  | O modo padrão, com as capacidades de canal dos cabos e das redes ad hoc descritas ao longo deste guia                                                                                                                                    |
| `x2`       | Todas as capacidades de canal são duplicadas (16 no cabo comum, 64 no cabo denso e redes ad hoc comportam 16 canais)                                                                                                                    |
| `x3`       | Todas as capacidades de canal são triplicadas (24 no cabo comum, 92 no cabo denso e redes ad hoc comportam 24 canais)                                                                                                                   |
| `x4`       | Todas as capacidades de canal são quadruplicadas (32 no cabo comum, 128 no cabo denso e redes ad hoc comportam 32 canais)                                                                                                               |
| `infinite` | Todas as restrições de canais são removidas. Controladores ainda reduzem *significativamente* o consumo de energia das redes. Cabos inteligentes apenas alternam entre totalmente desligados (nenhum canal transmitido) e totalmente ligados (1 ou mais canais transmitidos). |
