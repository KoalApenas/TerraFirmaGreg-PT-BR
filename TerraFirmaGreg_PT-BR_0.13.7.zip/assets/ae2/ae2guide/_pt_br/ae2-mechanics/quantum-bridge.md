---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Ponte Quântica
  icon: quantum_ring
---

# A Ponte de Rede Quântica

Consulte [Ponte de Rede Quântica](../items-blocks-machines/quantum_bridge.md)
