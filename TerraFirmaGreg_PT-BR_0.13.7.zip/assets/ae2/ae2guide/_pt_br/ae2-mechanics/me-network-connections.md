---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Conexões de Rede
  icon: fluix_glass_cable
---

# Conexões de Rede

## O que Significa “Rede”?

Uma “Rede” é um grupo de [dispositivos](../ae2-mechanics/devices.md) ligados por blocos capazes de transmitir [canais](../ae2-mechanics/channels.md),
como [cabos](../items-blocks-machines/cables.md), máquinas de bloco inteiro e [dispositivos](../ae2-mechanics/devices.md). 
(<ItemLink id="charger" />, <ItemLink id="interface" />, <ItemLink id="drive" /> etc.)
Tecnicamente, até mesmo um único cabo já é uma rede.

## Um Comentário sobre o Posicionamento dos Dispositivos

Para [dispositivos](../ae2-mechanics/devices.md) que possuem alguma função específica na rede — como uma <ItemLink id="interface" />
enviando e retirando itens do [armazenamento da rede](../ae2-mechanics/import-export-storage.md), um <ItemLink id="level_emitter" />
lendo o conteúdo do armazenamento da rede ou um <ItemLink id="drive" /> servindo como armazenamento da rede —,
a posição física do dispositivo não importa.

Novamente: **a posição física do dispositivo não importa**. O importante é que ele esteja conectado à rede
— e, naturalmente, a qual rede está conectado.

## Conexões de Rede

Uma maneira simples de determinar o que está conectado a uma rede é usar uma <ItemLink id="network_tool" />. Ela mostra todos os
componentes da rede; portanto, se você enxergar algo que não deveria ou não encontrar algo que deveria, há um problema.

Por exemplo, estas são 2 redes separadas.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
        Rede 1
  </BoxAnnotation>

<BoxAnnotation color="#915dcd" min="2 0 0" max="3 2 2">
        Rede 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Estas também são 2 redes separadas, pois a <ItemLink id="quartz_fiber" /> compartilha [energia](../ae2-mechanics/energy.md)
sem fornecer uma conexão de rede.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
        Rede 1
  </BoxAnnotation>

  <BoxAnnotation color="#915dcd" min="1.3 0 0" max="3 2 2">
        Rede 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Porém, esta é apenas 1 rede, e não 2 redes separadas. A [ponte quântica](../items-blocks-machines/quantum_bridge.md) funciona como
um [cabo denso](../items-blocks-machines/cables.md#dense-cable) sem fio; portanto, as duas extremidades pertencem à mesma rede.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="7 3 3">
        Tudo: 1 rede
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Esta também é apenas 1 rede, pois a cor do [cabo](../items-blocks-machines/cables.md) não interfere nas conexões de rede, exceto por impedir que cabos de cores diferentes
se conectem. Cabos de todas as cores se conectam a cabos de Fluix — ou “sem cor”.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
        Tudo: 1 rede
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Conexões Menos Intuitivas

Neste caso, há apenas 1 rede porque o <ItemLink id="pattern_provider" />, por ser um dispositivo de bloco inteiro, funciona como
um cabo, e o <ItemLink id="inscriber" /> faz algo semelhante. Assim, a conexão de rede passa pelo
provedor e pelo Inscritor.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
        Tudo: 1 rede
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Para impedir isso — algo útil em muitas estruturas de autofabricação que envolvem [sub-redes](../ae2-mechanics/subnetworks.md) —,
você pode clicar com o botão direito no provedor usando uma <ItemLink id="certus_quartz_wrench" /> para torná-lo direcional; nesse caso, ele
não transmitirá canais por um dos lados.

<Row gap="40">
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="2 2 2">
        Rede 1
  </BoxAnnotation>

  <BoxAnnotation color="#915dcd" min="2 0 0" max="4 2 2">
        Rede 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_directional_connection.snbt" />

  <BoxAnnotation color="#ee3333" min="1 .3 .3" max="1.3 .7 .7">
        Observe que o cabo não se conecta
  </BoxAnnotation>

  <IsometricCamera yaw="255" pitch="30" />
</GameScene>
</Row>

Outros componentes que não fornecem conexões direcionais de rede são a maioria das [subpartes](../ae2-mechanics/cable-subparts.md)
que funcionam como [dispositivos](../ae2-mechanics/devices.md), como <ItemLink id="import_bus" />, <ItemLink id="storage_bus" /> e
<ItemLink id="cable_interface" />.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/subpart_no_connection.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
