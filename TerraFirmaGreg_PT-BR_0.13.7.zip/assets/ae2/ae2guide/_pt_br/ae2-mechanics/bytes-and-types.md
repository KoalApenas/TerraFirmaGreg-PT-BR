---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Bytes e Tipos
  icon: creative_item_cell
---

# Bytes e Tipos

<Row>
    <ItemImage id="item_storage_cell_1k" scale="4" />

    <ItemImage id="item_storage_cell_4k" scale="4" />

    <ItemImage id="item_storage_cell_16k" scale="4" />

    <ItemImage id="item_storage_cell_64k" scale="4" />

    <ItemImage id="item_storage_cell_256k" scale="4" />
  </Row>

As [Células de Armazenamento](../items-blocks-machines/storage_cells.md) são definidas por *bytes* e *tipos*. Bytes, assim como em
um computador real, medem a quantidade total de “conteúdo” em uma célula de armazenamento. Tipos medem quantos
*tipos* diferentes de coisas estão armazenados em uma célula. Cada tipo representa um item único; assim, 4,096 pedregulhos são 1 tipo, enquanto 16
espadas com encantamentos diferentes são 16 tipos.

Cada célula de armazenamento pode guardar uma quantidade fixa
de dados. Cada tipo consome antecipadamente certa quantidade de bytes — que varia conforme o tamanho da célula —,
e cada item consome um bit de armazenamento; portanto, oito itens consomem um
byte, e uma pilha completa de 64 consome 8 bytes, independentemente de como o item
seria empilhado fora de uma rede ME. Por exemplo, 64 selas idênticas não
ocupam mais espaço que 64 pedras.

Novamente, cada item ocupa 1 bit; assim, 8 itens equivalem a 1 byte. Para células de fluidos, são 8 baldes por byte.

Muitas pessoas reclamam da quantidade limitada de tipos que uma célula comporta, mas essa é uma ***limitação necessária***.
As células armazenam seus dados em uma etiqueta NBT no próprio item, o que as torna bastante estáveis. Porém, isso significa que colocar dados demais
em uma célula pode fazer muitos dados serem enviados a um jogador, causando um efeito semelhante ao “banimento por livro” no Minecraft padrão.
Além disso, ter tipos diferentes demais no sistema aumenta a carga da ordenação e do processamento de itens. Contudo, essa
limitação não acaba sendo muito restritiva. Um <ItemLink id="drive" /> totalmente preenchido com células comporta 630 tipos, o que na verdade
é bastante, desde que você não armazene muitos itens únicos e não empilháveis.

Por esse motivo, os tipos existem para “desencorajar firmemente” o despejo direto no sistema ME de centenas de armaduras e ferramentas com danos aleatórios
vindas de uma fazenda de criaturas. Cada peça de armadura com dano e encantamentos únicos precisa ser armazenada como uma entrada separada,
causando inchaço dos dados. Recomenda-se filtrá-las do fluxo de itens antes que cheguem ao sistema.

Ir direto para as células de armazenamento do nível mais alto geralmente não é a melhor ideia,
pois você usa mais recursos sem ganhar capacidade adicional de tipos. Isso significa que células de todos os tamanhos continuam úteis até
o fim do jogo, já que cada uma apresenta vantagens e desvantagens.

Abaixo há uma tabela que compara os diferentes níveis de células de armazenamento, suas capacidades e
uma estimativa aproximada do custo.

## Conteúdo das Células de Armazenamento em Relação ao Custo

| Célula                                  |   Bytes | Tipos | Bytes por Tipo | Certus | Redstone | Ouro | Pedra Luminosa |
| ---------------------------------------- | ------: | ----: | -------------: | -----: | -------: | ---: | --------: |
| <ItemLink id="item_storage_cell_1k" />   |   1,024 |    63 |              8 |      4 |        5 |    1 |         0 |
| <ItemLink id="item_storage_cell_4k" />   |   4,096 |    63 |             32 |  14.25 |       20 |    3 |         0 |
| <ItemLink id="item_storage_cell_16k" />  |  16,384 |    63 |            128 |     45 |       61 |    9 |         4 |
| <ItemLink id="item_storage_cell_64k" />  |  65,536 |    63 |            512 | 137.25 |      184 |   27 |        16 |
| <ItemLink id="item_storage_cell_256k" /> | 262,144 |    63 |           2048 |    414 |      553 |   81 |        48 |

## Capacidade de Armazenamento com Diferentes Quantidades de Tipos

O custo inicial dos tipos faz com que uma célula contendo 1 tipo comporte 2x mais que uma célula usando todos os 63 tipos.

| Célula                                  | Capacidade Total com 1 Tipo em Uso | Capacidade Total com 63 Tipos em Uso |
| ---------------------------------------- | ----------------------------------------: | ------------------------------------------: |
| <ItemLink id="item_storage_cell_1k" />   |                                     8,128 |                                       4,160 |
| <ItemLink id="item_storage_cell_4k" />   |                                    32,512 |                                      16,640 |
| <ItemLink id="item_storage_cell_16k" />  |                                   130,048 |                                      66,560 |
| <ItemLink id="item_storage_cell_64k" />  |                                   520,192 |                                     266,240 |
| <ItemLink id="item_storage_cell_256k" /> |                                 2,080,768 |                                   1,064,960 |

![Uma Célula com 1 Tipo](../assets/diagrams/1_type_cell.png)

![Uma Célula com 63 Tipos](../assets/diagrams/63_type_cell.png)
