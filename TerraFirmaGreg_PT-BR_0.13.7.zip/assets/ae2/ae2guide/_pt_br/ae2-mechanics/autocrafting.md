---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Autofabricação
  icon: pattern_provider
---

# Autofabricação

### O Grande Recurso

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/autocraft_setup_greebles.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

A autofabricação é uma das principais funções do AE2. Em vez de fabricar manualmente a quantidade correta de cada subingrediente
e trabalhar como algum tipo de *plebeu*, você pode pedir ao sistema ME que faça isso por você. Também pode fabricar itens automaticamente e exportá-los para algum lugar.
Ou manter automaticamente determinadas quantidades em estoque por meio de comportamentos emergentes engenhosos. Isso também funciona com fluidos e, caso você possua
complementos para tipos adicionais de materiais de mods, como os gases do Mekanism, também com esses materiais. É realmente excelente.

Este é um assunto bastante complexo, então prepare-se e vamos começar.

Uma estrutura de autofabricação consiste em 3 elementos:
- O elemento que envia a solicitação de fabricação
- A CPU de fabricação
- O <ItemLink id="pattern_provider" />.

Veja o que acontece:

1.  Algo cria uma solicitação de fabricação. Pode ser você, clicando em algo autofabricável no terminal,
    ou um ponto de exportação ou uma interface com um cartão de fabricação solicitando um dos itens que deve exportar ou manter em estoque.

*   (**IMPORTANTE:** use a tecla associada a “copiar bloco” — normalmente o botão do meio — para solicitar a fabricação de algo que você já possui em estoque; isso pode entrar em conflito com mods de organização de inventário),

2.  O sistema ME calcula os ingredientes e as etapas prévias de fabricação necessários para atender à solicitação e os armazena na CPU de fabricação selecionada

3.  O <ItemLink id="pattern_provider" /> que contém o [padrão](../items-blocks-machines/patterns.md) pertinente envia os ingredientes especificados pelo padrão para qualquer inventário adjacente.
    No caso de uma receita de bancada de trabalho — um “padrão de fabricação” —, esse inventário será um <ItemLink id="molecular_assembler" />.
    No caso de uma receita que não seja de fabricação — um “padrão de processamento” —, será algum outro bloco, máquina ou uma montagem elaborada controlada por redstone.

4.  O resultado da fabricação retorna ao sistema de alguma forma: por um ponto de importação, uma interface ou sendo enviado de volta a um provedor de padrões.
    **Observe que um evento de “item entrando no sistema” precisa ocorrer; não basta transportar o resultado para um baú que tenha um <ItemLink id="storage_bus" />.**

5.  Se essa fabricação for um pré-requisito de outra fabricação na solicitação, os itens serão armazenados nessa CPU de fabricação e depois usados na fabricação correspondente.

# Padrões

<ItemImage id="crafting_pattern" scale="4" />

Os padrões são produzidos em um <ItemLink id="pattern_encoding_terminal" /> a partir de padrões em branco.

Existem vários tipos de padrão para diferentes finalidades:

*   Os <ItemLink id="crafting_pattern" /> codificam receitas de bancada de trabalho. Eles podem ser inseridos diretamente em um <ItemLink id="molecular_assembler" /> para fazê-lo
    fabricar o resultado sempre que receber os ingredientes, mas seu uso principal é em um <ItemLink id="pattern_provider" /> ao lado de um montador molecular.
    Nesse caso, os provedores de padrões possuem um comportamento especial e enviam o padrão pertinente junto com os ingredientes aos montadores adjacentes.
    Como os montadores ejetam automaticamente os resultados das fabricações para inventários adjacentes, basta um montador em um provedor de padrões para automatizar padrões de fabricação.

***

*   Os <ItemLink id="smithing_table_pattern" /> são muito semelhantes aos padrões de fabricação, mas codificam receitas de mesa de ferraria. Também são automatizados por um provedor de
    padrões e um montador molecular e funcionam exatamente da mesma maneira. Na verdade, padrões de fabricação, ferraria e corte de pedra podem ser
    usados na mesma montagem.

***

*   Os <ItemLink id="stonecutting_pattern" /> são muito semelhantes aos padrões de fabricação, mas codificam receitas do cortador de pedras. Também são automatizados por um provedor de
    padrões e um montador molecular e funcionam exatamente da mesma maneira. Na verdade, padrões de fabricação, ferraria e corte de pedra podem ser
    usados na mesma montagem.

***

*   Os <ItemLink id="processing_pattern" /> oferecem grande parte da flexibilidade da autofabricação. Eles são o tipo mais genérico e simplesmente
    dizem: “se um provedor de padrões enviar estes ingredientes a inventários adjacentes, o sistema ME receberá estes itens em algum momento de um
    futuro próximo ou distante”. É assim que você automatizará a fabricação com quase qualquer máquina de mod, fornalha ou equipamento semelhante. Como seu uso é tão
    genérico e eles não se importam com o que ocorre entre o envio dos ingredientes e o recebimento do resultado, você pode fazer coisas bem incomuns, como inserir
    os ingredientes em toda uma cadeia de produção industrial complexa que separará materiais, receberá outros ingredientes de fazendas de produção infinita,
    imprimirá todo o roteiro do filme Bee Movie; o sistema ME não se importa, desde que receba o resultado especificado pelo padrão. Na verdade,
    ele nem sequer exige que os ingredientes tenham alguma relação com o resultado. Você poderia dizer “1 tábua de cerejeira = 1 estrela do Nether” e fazer
    sua fazenda de Wither matar um Wither ao receber uma tábua de cerejeira, e funcionaria.

Vários <ItemLink id="pattern_provider" /> com padrões idênticos são compatíveis e trabalham em paralelo. Além disso, um padrão pode indicar,
por exemplo, 8 pedregulhos = 8 pedras em vez de 1 pedregulho = 1 pedra; assim, o provedor de padrões inserirá 8 pedregulhos em
sua estrutura de fundição a cada operação, em vez de inserir um por vez.

## A Forma Mais Genérica de “Padrão”

Na verdade, existe uma forma de “padrão” ainda mais genérica que um padrão de processamento. Um <ItemLink id="level_emitter" /> com um cartão de fabricação pode ser configurado
para emitir um sinal de redstone a fim de fabricar algo. Esse “padrão” não define os ingredientes e nem sequer se importa com eles.
Ele diz apenas: “Se você emitir redstone deste emissor de nível, o sistema ME receberá este item em algum momento de um
futuro próximo ou distante”. Isso costuma ser usado para ativar e desativar fazendas infinitas que não exigem ingredientes de entrada
ou para ativar um sistema que lida com receitas recursivas — que a autofabricação comum não consegue compreender —, como “1 pedregulho = 2 pedregulhos”,
caso você tenha uma máquina que duplique pedregulho.

# A CPU de Fabricação

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/crafting_cpus.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

As CPUs de fabricação administram solicitações e tarefas de fabricação. Elas armazenam os ingredientes intermediários durante a execução de tarefas com várias etapas
e afetam o tamanho máximo dessas tarefas e, até certo ponto, a velocidade de conclusão. São multiblocos
que precisam formar prismas retangulares com pelo menos 1 armazenamento de fabricação.

As CPUs de fabricação são formadas por:

*   (Obrigatório) [Armazenamentos de fabricação](../items-blocks-machines/crafting_cpu_multiblock.md), disponíveis em todos os tamanhos padrão de célula (1k, 4k, 16k, 64k, 256k). Eles armazenam os ingredientes e
    ingredientes intermediários envolvidos em uma fabricação; portanto, armazenamentos maiores ou em maior quantidade são necessários para que a CPU processe tarefas
    com mais ingredientes.
*   (Opcional) Os <ItemLink id="crafting_accelerator" /> fazem o sistema enviar mais lotes de ingredientes pelos provedores de padrões.
    Isso permite, por exemplo, que um provedor cercado por 6 montadores moleculares envie ingredientes a todos os 6 — e, portanto, use todos eles — ao mesmo tempo, em vez de apenas um.
*   (Opcional) Os <ItemLink id="crafting_monitor" /> exibem a tarefa que a CPU está processando no momento. Podem ser coloridos com um <ItemLink id="color_applicator" />
*   (Opcional) Os <ItemLink id="crafting_unit" /> simplesmente ocupam espaço para que a CPU forme um prisma retangular.

Cada CPU de fabricação processa 1 solicitação ou tarefa; portanto, para solicitar ao mesmo tempo um processador de cálculo e 256 pedras lisas, você precisa de 2 multiblocos de CPU.

Elas podem ser configuradas para processar solicitações de jogadores, da automação — pontos de exportação e interfaces — ou de ambos.

# Provedores de Padrões

<Row>
<BlockImage id="pattern_provider" scale="4" />

<BlockImage id="pattern_provider" p:push_direction="up" scale="4" />

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/blocks/cable_pattern_provider.snbt" />
</GameScene>
</Row>

Os <ItemLink id="pattern_provider" /> são a principal maneira de seu sistema de autofabricação interagir com o mundo. Eles enviam os ingredientes de
seus [padrões](../items-blocks-machines/patterns.md) para inventários adjacentes, e itens podem ser inseridos neles para entrar na rede. Muitas vezes,
é possível economizar um canal transportando a saída de uma máquina de volta a um provedor de padrões próximo — normalmente aquele que enviou os ingredientes —
em vez de usar um <ItemLink id="import_bus" /> para retirar a saída da máquina e inseri-la na rede.

Vale observar que, como eles enviam os ingredientes diretamente do [armazenamento de fabricação](../items-blocks-machines/crafting_cpu_multiblock.md#crafting-storage) de uma CPU de fabricação,
os ingredientes nunca ficam realmente no inventário do provedor; portanto, você não pode retirá-los por tubos. É preciso fazer o provedor enviá-los
a outro inventário — como um barril — e então retirá-los dali.

Também é importante observar que o provedor precisa enviar TODOS os ingredientes de uma vez; ele não consegue enviar lotes parciais. Isso é útil
e pode ser aproveitado.

Os provedores de padrões possuem uma interação especial com interfaces em [sub-redes](../ae2-mechanics/subnetworks.md): se a interface não tiver sido modificada — nada nos slots de solicitação —,
o provedor ignorará completamente a interface e enviará os itens diretamente ao [armazenamento](../ae2-mechanics/import-export-storage.md) da sub-rede,
sem encher a interface com lotes de receitas e, o mais importante, sem inserir o próximo lote até haver espaço no armazenamento.

Vários provedores de padrões com padrões idênticos são compatíveis e trabalham em paralelo.

Os provedores tentam distribuir seus lotes alternadamente entre todas as faces, usando assim todas as máquinas conectadas em paralelo.

## Variantes

Os Provedores de Padrões possuem 3 variantes: normal, direcional e plana. Isso afeta os lados específicos pelos quais enviam
ingredientes, recebem itens e fornecem conexão com a rede.

*   Provedores de padrões normais enviam ingredientes para todos os lados, recebem entradas de todos os lados e, como a maioria das máquinas do AE2, agem
    como um cabo que fornece conexão de rede para todos os lados.

*   Provedores de padrões direcionais são criados usando uma <ItemLink id="certus_quartz_wrench" /> em um provedor normal para alterar sua
    direção. Eles enviam ingredientes apenas para o lado selecionado, recebem entradas de todos os lados e especificamente não fornecem uma conexão de rede
    no lado selecionado. Isso permite enviar itens a máquinas do AE2 sem conectar as redes, caso você queira criar uma sub-rede.

*   Provedores de padrões planos são uma [subparte de cabo](../ae2-mechanics/cable-subparts.md); por isso, vários podem ser colocados no mesmo cabo, permitindo montagens compactas.
    Eles funcionam de modo semelhante ao lado selecionado de um provedor direcional: fornecem padrões, recebem entradas e não
    fornecem conexão de rede na face em que estão instalados.

Provedores de padrões podem ser alternados entre as variantes normal e plana em uma grade de fabricação.

## Configurações

Os provedores de padrões possuem vários modos:

*   O **Modo de Bloqueio** impede que o provedor envie um novo lote de ingredientes se já houver
    ingredientes na máquina.
*   **Bloquear Fabricação** pode bloquear o provedor sob várias condições de redstone ou até que o resultado da
    fabricação anterior seja inserido naquele provedor de padrões específico.
*   O provedor pode ser exibido ou ocultado nos <ItemLink id="pattern_access_terminal" />.

## Prioridade

As prioridades podem ser definidas clicando na chave inglesa no canto superior direito da interface. Quando há vários [padrões](../items-blocks-machines/patterns.md)
para o mesmo item, os padrões em provedores de maior prioridade são usados antes daqueles em provedores de menor prioridade,
a menos que a rede não possua os ingredientes do padrão de maior prioridade.

# Montadores Moleculares

<BlockImage id="molecular_assembler" scale="4" />

O <ItemLink id="molecular_assembler" /> recebe itens e executa a operação definida por um <ItemLink id="pattern_provider" /> adjacente
ou pelo <ItemLink id="crafting_pattern" />, <ItemLink id="smithing_table_pattern" /> ou <ItemLink id="stonecutting_pattern" /> inserido,
e então envia o resultado aos inventários adjacentes.

Seu principal uso é ao lado de um <ItemLink id="pattern_provider" />. Nesse caso, os provedores de padrões possuem um comportamento especial
e enviam informações sobre o padrão correspondente junto com os ingredientes aos montadores adjacentes. Como os montadores ejetam automaticamente os resultados das
fabricações para inventários adjacentes — e, portanto, para os slots de retorno do provedor —, basta um montador em um provedor de padrões
para automatizar padrões de fabricação.

<GameScene zoom="4" background="transparent">
<ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>
