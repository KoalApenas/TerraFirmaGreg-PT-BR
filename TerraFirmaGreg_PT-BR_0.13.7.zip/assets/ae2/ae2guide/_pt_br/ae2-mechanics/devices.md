---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Dispositivos
  icon: interface
---

# Dispositivos

Um “Dispositivo” é um componente de rede do AE2 que executa alguma função relacionada à própria rede. Quase sempre
exige um canal, com a importante exceção dos [Emissores de Nível](../items-blocks-machines/level_emitter.md).

Alguns exemplos incluem:

*   <ItemLink id="interface" />
*   <ItemLink id="import_bus" />
*   <ItemLink id="storage_bus" />
*   <ItemLink id="pattern_provider" />
*   <ItemLink id="drive" />
