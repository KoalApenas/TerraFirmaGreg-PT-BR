---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: E/S Espacial
  icon: spatial_storage_cell_2
---

# E/S Espacial

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/spatial_storage_1x1x1.snbt" />

  <BoxAnnotation color="#33dd33" min="1 1 1" max="2 2 2">
        O volume a ser movido
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />

</GameScene>

A E/S Espacial é uma maneira de recortar e colar volumes físicos do espaço em seu mundo. Ela pode ser usada para mover <ItemLink id="flawless_budding_quartz" />,
criar uma sala na base cujo interior possa ser trocado para diferentes finalidades ou até mesmo mover
o portal do End!

Ela funciona *trocando* o volume definido por outro de tamanho idêntico na dimensão de armazenamento espacial: o que estiver
no conjunto de pilões é enviado à dimensão de armazenamento espacial, e o que estiver na dimensão é trazido ao conjunto de pilões.

Isso significa que, se você possuir uma forma de viajar entre dimensões — a E/S Espacial *pode* ser usada para criar um teletransportador,
mas isso é muito complexo, um pouco instável e está além do escopo do guia —, poderá usá-las como máquinas compactas de tamanho personalizado ou
dimensões de bolso.

# A Estrutura Multibloco

A E/S Espacial exige uma disposição específica de seus componentes para funcionar e definir o volume que será recortado e colado.

Todos os componentes precisam estar na mesma [rede](me-network-connections.md) para funcionar, e só pode haver uma
estrutura de E/S Espacial por rede. Portanto, recomenda-se usar uma [sub-rede](subnetworks.md).

## O Porto de Entrada/Saída Espacial

<BlockImage id="spatial_io_port" p:powered="true" scale="4" />

O <ItemLink id="spatial_io_port" /> controla a operação de E/S Espacial. Ele mostra estatísticas da estrutura multibloco e comporta
as [células espaciais](../items-blocks-machines/spatial_cells.md).

Ele exibe:
- A [energia](energy.md) armazenada e máxima da rede
- A energia necessária para executar a operação. Esse valor pode ser muito alto e é consumido instantaneamente; portanto, garanta que haja
  [células de energia](../items-blocks-machines/energy_cells.md) suficientes para armazenar tudo.
- A eficiência do conjunto de pilões
- O tamanho do volume definido

Para executar uma operação de E/S Espacial, coloque uma célula de armazenamento espacial no slot de entrada e envie um pulso de redstone ao porto de E/S espacial.
Ele então *trocará* o volume entre os pilões pelo volume da dimensão de armazenamento espacial. Isso significa que, se você enviar um
conjunto de blocos à dimensão de armazenamento espacial, *depois colocar outro conjunto de blocos entre os pilões*, recolocar a célula no slot de entrada
e acionar novamente o porto de E/S, o 2º conjunto de blocos desaparecerá e o 1º reaparecerá.

**TENHA CUIDADO: toda entidade no volume definido, inclusive você, será transportada; se não houver uma forma de sair, você ficará preso
na dimensão de armazenamento espacial, dentro de uma caixa escura e sem características.** Use isso para pregar peças em seus amigos!

## Pilões

<BlockImage id="spatial_pylon" p:powered_on="true" scale="4" />

Os <ItemLink id="spatial_pylon" /> são a parte principal de uma estrutura de E/S Espacial e definem o volume afetado.

O volume é definido pela caixa delimitadora do lado externo dos pilões, contraída em 1 bloco em todas as direções.

As regras são:
- Tamanho mínimo de 3x3x3 — que define um volume de 1x1x1
- Todos os pilões espaciais precisam estar na caixa delimitadora externa
- Todos os pilões espaciais precisam estar na mesma rede
- Todos os pilões precisam ter pelo menos 2 blocos de comprimento

Por exemplo, suponha que você queira definir um volume de 3x3x3. De acordo com a regra 2, todos os pilões precisam estar dentro de uma estrutura de 5x5x5 ao redor
do volume que você deseja definir. Eles podem adotar quase qualquer disposição, desde que fiquem contidos nessa estrutura com 1 bloco de espessura,
de 5x5x5.

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/spatial_storage_3x3x3_pylon_demonstration.snbt" />

<BoxAnnotation color="#33dd33" min="1 1 1" max="4 4 4">
        O volume a ser movido
  </BoxAnnotation>

<BoxAnnotation color="#3333ff" min="5 5 0" max="0 0 5">
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Uma estrutura mais razoável seria esta:

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/better_spatial_storage_3x3x3.snbt" />

<BoxAnnotation color="#33dd33" min="1 1 1" max="4 4 4">
        O volume a ser movido
  </BoxAnnotation>

<BoxAnnotation color="#3333ff" min="5 5 0" max="0 0 5">
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Eficiência

A eficiência do conjunto de pilões depende de quanto da estrutura externa você preenche. Montagens mínimas ao redor de grandes volumes
serão muito ineficientes e poderão exigir *bilhões* de AE.

## Dimensões das Células

Depois que uma [célula espacial](../items-blocks-machines/spatial_cells.md) é usada, ela recebe um conjunto permanente de dimensões XYZ — por exemplo, 3x4x2 —
e fica vinculada a um volume de espaço na dimensão de armazenamento espacial. **VOCÊ NÃO PODE REDEFINIR, REFORMATAR NEM REDIMENSIONAR UMA CÉLULA ESPACIAL DEPOIS
QUE ELA FOR USADA.** Crie uma nova célula se quiser usar dimensões diferentes. 

Essas não são as mesmas dimensões presentes no nome da célula: uma célula 16^3 pode ter quaisquer dimensões *até* 16x16x16.

Observe que esse volume é direcional e não pode ser girado. Um volume de 2x2x3 não é igual a um volume de 3x2x2, embora ambos tenham
o mesmo tamanho.

Se as dimensões XYZ de uma célula não corresponderem ao volume definido — exibido no porto de E/S —, ele não funcionará.
