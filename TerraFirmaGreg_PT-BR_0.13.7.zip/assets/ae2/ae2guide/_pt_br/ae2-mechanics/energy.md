---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Energia
  icon: energy_cell
---

# Energia

Sua rede precisa de energia para funcionar. As redes possuem uma reserva de energia da qual os [dispositivos](../ae2-mechanics/devices.md) retiram diretamente, e que
<ItemLink id="vibration_chamber" />, <ItemLink id="energy_acceptor" /> e <ItemLink id="controller" /> abastecem. Você pode
consultar as estatísticas de energia da rede clicando com o botão direito em qualquer parte dela usando uma <ItemLink id="network_tool" /> ou
clicando com o botão direito no controlador da rede, se houver um. Esse armazenamento e essa distribuição para toda a rede significam que
não há limites de taxa de transferência de energia; portanto, os dispositivos podem retirar quantidades arbitrariamente altas de energia, e
os aceitadores de energia podem recebê-la em uma velocidade praticamente ilimitada, restrita apenas por seu armazenamento de energia.

## Recebimento de Energia

<Row>
  <BlockImage id="energy_acceptor" scale="4" />

  <GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/blocks/cable_energy_acceptor.snbt" />
  </GameScene>

  <BlockImage id="controller" p:state="online" scale="4" />

  <BlockImage id="vibration_chamber" p:active="true" scale="4" />
</Row>

O AE2 não usa internamente a Energia Forge — no Forge — nem a Energia do TechReborn — no Fabric. Em vez disso, converte-as para
sua própria unidade, AE. Essa conversão ocorre em apenas um sentido. A energia pode ser convertida por <ItemLink id="energy_acceptor" /> e
<ItemLink id="controller" />, embora seja melhor usar as faces do controlador para obter mais [canais](../ae2-mechanics/channels.md).
Ela também pode ser gerada por <ItemLink id="vibration_chamber" />, mas o AE2 foi projetado
para ser usado com outros mods tecnológicos que possuam métodos melhores de geração de energia.

Tudo isso significa que é melhor considerar uma rede do AE2 como uma única máquina multibloco de grande porte ao planejar a
infraestrutura de distribuição de energia da sua base.

As proporções de conversão da Energia Forge e da Energia do TechReborn são:

*   2 FE = 1 AE (Forge)
*   1 E  = 2 AE (Fabric)

## Armazenamento de Energia

<Row>
  <BlockImage id="energy_cell" scale="4" p:fullness="4" />

  <BlockImage id="dense_energy_cell" scale="4" p:fullness="4" />

  <BlockImage id="creative_energy_cell" scale="4" />
</Row>

Por motivos relativamente óbvios, uma rede não pode receber nem consumir em um tique de jogo mais energia do que consegue armazenar. Se uma rede
consegue armazenar apenas 800 AE, quando seus [dispositivos](../ae2-mechanics/devices.md) solicitarem energia, poderão usar no máximo 800 AE — supondo que o armazenamento esteja cheio —,
e um aceitador de energia só poderá inserir até 800 AE na rede — supondo que o armazenamento esteja vazio.

Essa é uma causa comum de comportamentos estranhos: alguém monta uma pequena rede contendo apenas um aceitador de energia, um gabinete, um terminal e
alguns dispositivos, depois tenta despejar de seu inventário na rede um inventário inteiro de pedregulho. Inserir todo esse pedregulho de uma vez, em um
único tique de jogo, exige mais energia do que há armazenada na rede; assim, nem todo o pedregulho é inserido, a rede
fica sem energia e reinicia.

**Isso pode ser resolvido adicionando células de energia.**

As redes possuem uma reserva de energia interna de 25 AE por cabo, máquina ou parte.

Os <ItemLink id="controller" /> possuem uma pequena capacidade interna de armazenamento de energia: 8,000 AE.

A <ItemLink id="energy_cell" /> armazena 200k AE, e apenas uma deve ser suficiente para a maioria dos casos, absorvendo com facilidade os picos de energia
do uso normal da rede.

A <ItemLink id="dense_energy_cell" /> armazena 1.6M AE e é indicada quando você deseja alimentar uma rede com energia armazenada ou
suportar o enorme consumo instantâneo de energia de grandes estruturas de [armazenamento espacial](spatial-io.md).

A <ItemLink id="creative_energy_cell" /> é um item criativo para testes, que fornece PODERRRR ILIMITADO ou algo assim.
