---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Subpartes de Cabo
icon: fluix_glass_cable
---

# Subpartes de Cabo

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/subparts_demonstration.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

No AE2, determinados [dispositivos](devices.md) e componentes podem ser instalados em cabos dentro do mesmo bloco. Isso é útil em montagens compactas.
Clicar com Shift e o botão direito usando uma <ItemLink id="certus_quartz_wrench" /> ou uma <ItemLink id="network_tool" /> permite quebrar apenas uma
subparte — ou o cabo — sem destruir tudo o que está naquele bloco.
