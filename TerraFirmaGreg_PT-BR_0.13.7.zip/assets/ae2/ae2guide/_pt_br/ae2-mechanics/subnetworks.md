---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Sub-redes
---

# Sub-redes

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/subnet_demonstration.snbt" />

<DiamondAnnotation pos="6.5 2.5 0.5" color="#00ff00">
        Sub-rede de Tubo de Itens
    </DiamondAnnotation>

<DiamondAnnotation pos="5.5 2.5 0.5" color="#00ff00">
        Sub-rede de Tubo de Fluidos
    </DiamondAnnotation>

<DiamondAnnotation pos="4.5 2.5 0.5" color="#00ff00">
        Plano de Aniquilação Filtrado
    </DiamondAnnotation>

<DiamondAnnotation pos="3.5 2.5 0.5" color="#00ff00">
        Sub-rede de Plano de Formação
    </DiamondAnnotation>

<DiamondAnnotation pos="2.5 2.5 0.5" color="#00ff00">
        Sub-rede que usa a interação entre a Interface e o Ponto de Armazenamento como um armazenamento local secundário que a rede
principal pode acessar
    </DiamondAnnotation>

<DiamondAnnotation pos="1.5 1.5 0.5" color="#00ff00">
        Outra sub-rede de tubo de itens, para devolver os itens carregados ao Provedor de Padrões
    </DiamondAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

"Sub-rede" é um termo definido de forma um tanto vaga, mas pode-se dizer que uma sub-rede é qualquer rede que dá suporte à sua
rede principal ou executa alguma tarefa pequena. Em geral, elas são pequenas o bastante para não exigirem controladores. Seus 2 principais usos costumam ser:

*   Restringir quais [dispositivos](../ae2-mechanics/devices.md) têm acesso a qual armazenamento (você não vai querer que o ponto de importação em uma sub-rede de "tubulação" tenha acesso ao armazenamento da sua rede principal
    pois ele colocaria os itens nas suas células de armazenamento em vez de colocá-los no inventário de destino).
*   Economizar canais na sua rede principal, por exemplo, fazendo um Provedor de Padrões enviar para uma Interface conectada a vários pontos de
    armazenamento em várias máquinas, usando 1 canal, em vez de colocar um Provedor de Padrões em cada máquina e usar vários canais.

Cabos de cores diferentes não têm relação com a criação de uma sub-rede, exceto pelo fato de não se conectarem uns aos outros.

Elas podem ser:

*   um ponto de importação e um ponto de armazenamento configurados para transferir itens ou fluidos de um recipiente para outro, como um tubo de itens ou fluidos
*   um Plano de Aniquilação e um ponto de armazenamento, de modo que o único lugar em que o plano possa colocar o que quebrar seja o ponto de armazenamento, permitindo filtrar o plano
*   uma Interface e um Plano de Formação, de modo que tudo o que for inserido na Interface seja enviado ao Plano de Formação e colocado/solto no mundo
*   uma configuração para produzir quartzo Certus automaticamente, regulada e controlada por um <ItemLink id="level_emitter" /> na rede principal
*   um sistema de armazenamento especializado, acessível pela rede principal por meio da interação especial entre ponto de armazenamento e Interface, para guardar a produção de uma fazenda sem transbordar continuamente o armazenamento principal
*   e assim por diante

O <ItemLink id="quartz_fiber" /> é muito útil para criar sub-redes. Ele transfere energia entre redes sem
conectá-las, permitindo alimentar sub-redes sem precisar espalhar aceitadores de energia e cabos de energia por toda parte.
