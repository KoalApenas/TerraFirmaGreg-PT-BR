---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Crescimento de Certus
  icon: quartz_cluster
---

# Crescimento de Certus

## Basicamente Copiado da Página de Primeiros Passos

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/budding_certus_1.snbt" />
</GameScene>

Gemas de quartzo Certus brotam das [drusas de Certus](../items-blocks-machines/budding_certus.md), de forma semelhante à ametista. Se você quebrar uma gema que ainda não terminou de
crescer, ela derrubará um <ItemLink id="certus_quartz_dust" />, sem alteração pela Fortuna. Se quebrar um aglomerado totalmente crescido, ele derrubará quatro
<ItemLink id="certus_quartz_crystal" />, e a Fortuna aumentará essa quantidade.

Há 4 níveis de drusas de Certus: Infalível, Imperfeita, Lascada e Danificada.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Sempre que uma gema avança um estágio de crescimento, a drusa tem uma chance de se degradar em um nível, até acabar se transformando
em um simples bloco de quartzo Certus. Elas podem ser restauradas — e novas drusas podem ser criadas — lançando a drusa ou um
bloco de quartzo Certus na água com um ou mais <ItemLink id="charged_certus_quartz_crystal" />.

<RecipeFor id="damaged_budding_quartz" />

Drusas de Certus infalíveis não se degradam e geram Certus infinitamente. Porém, elas não podem ser fabricadas nem movidas
com uma picareta, nem mesmo com Toque Suave. (Entretanto, elas *podem* ser movidas com [armazenamento espacial](../ae2-mechanics/spatial-io.md).)

Sozinhas, as gemas de quartzo Certus crescem muito lentamente. Felizmente, o <ItemLink id="growth_accelerator" />
acelera enormemente esse processo quando colocado ao lado da drusa. Construir alguns deles deve ser sua primeira prioridade.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_certus_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Se você não tiver quartzo suficiente para também fabricar um <ItemLink id="energy_acceptor" /> ou uma <ItemLink id="vibration_chamber" />,
pode fabricar uma <ItemLink id="crank" /> e instalá-la na extremidade do acelerador.

A coleta automática de Certus é [descrita aqui](../example-setups/simple-certus-farm.md).
