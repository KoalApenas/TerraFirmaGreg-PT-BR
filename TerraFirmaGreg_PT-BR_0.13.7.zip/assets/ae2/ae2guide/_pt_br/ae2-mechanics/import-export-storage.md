---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Importação, Exportação e Armazenamento
---

# Importação, Exportação e Armazenamento

**seu sistema ME e o mundo**

Um conceito importante do AE2 é a ideia de Armazenamento da Rede. Esse é o lugar em que o conteúdo da rede fica guardado,
normalmente em [células de armazenamento](../items-blocks-machines/storage_cells.md) ou no inventário ao qual um <ItemLink id="storage_bus" />
está conectado. A maioria dos [dispositivos](../ae2-mechanics/devices.md) do AE2 interage com ele de alguma maneira.

Por exemplo:

*   Os <ItemLink id="import_bus" /> enviam coisas ao armazenamento da rede
*   Os <ItemLink id="export_bus" /> retiram coisas do armazenamento da rede
*   As <ItemLink id="interface" /> retiram e enviam coisas ao armazenamento da rede
*   Os [Terminais](../items-blocks-machines/terminals.md) enviam e retiram coisas do armazenamento da rede quando você insere ou pega itens, ou para reabastecer os slots de fabricação
*   Os <ItemLink id="storage_bus" /> não enviam ou retiram propriamente do armazenamento; eles enviam ao inventário conectado ou retiram dele
    para usá-lo como armazenamento da rede — portanto, na realidade, os outros dispositivos enviam ou retiram itens *deles*

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/import_export_storage.snbt" />

  <BoxAnnotation color="#dddddd" min="8 1 1" max="9 1.3 2">
        Pontos de Importação importam coisas dos inventários para os quais apontam e as inserem no armazenamento da rede
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="8 2 1" max="9 3 1.3">
        Inserir algo de seu inventário em um terminal conta como uma importação da rede
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="7 0 1" max="8 1 2">
        Interfaces importam de seus inventários internos quando o slot não está configurado para manter nada em estoque ou quando há mais
        itens no slot que a quantidade configurada; portanto, itens podem ser enviados a elas para entrar na rede
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="6 0 1" max="7 1 2">
        Provedores de Padrões importam do inventário de seu slot interno de retorno; portanto, itens podem ser enviados a eles para entrar na rede
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 1" max="5 2 2">
        Gabinetes ME disponibilizam as células inseridas como armazenamento da rede
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="4 1.3 2">
        Pontos de Armazenamento usam como armazenamento da rede o inventário para o qual apontam
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 1 1" max="2 1.3 2">
        Pontos de Exportação exportam coisas do armazenamento da rede para os inventários aos quais apontam
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 1" max="2 3 1.3">
        Retirar algo de um terminal conta como uma exportação da rede
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 1 1" max="1 2 2">
        Interfaces exportam para seus inventários internos quando o slot está configurado para manter algo em estoque;
        portanto, é possível retirar itens delas para extraí-los da rede
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

É importante ter em mente as ações e os eventos de envio e retirada do armazenamento da rede ao projetar estruturas de automação
e logística.

## Prioridade do Armazenamento

As prioridades podem ser definidas clicando na chave inglesa no canto superior direito de algumas interfaces.
Itens que entram na rede começam pelo armazenamento de maior prioridade como
seu primeiro destino. Quando dois armazenamentos possuem a mesma prioridade,
se um deles já contém o item, ele será preferido em relação a qualquer
outro. Toda célula filtrada por lista branca é tratada como se já contivesse o item
quando está no mesmo grupo de prioridade que outros armazenamentos. Itens removidos do armazenamento são
retirados daquele de menor prioridade. Esse sistema faz com que, à medida que itens são inseridos e removidos
do armazenamento da rede, os armazenamentos de maior prioridade sejam preenchidos e os de menor prioridade sejam esvaziados.
