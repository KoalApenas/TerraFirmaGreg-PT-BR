---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Meteoritos
  icon: sky_stone_block
---

# Meteoritos

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/meteor_interior.snbt" />
</GameScene>

Meteoritos são o ponto de partida para usar o AE2. Eles fornecem materiais essenciais: [drusas de Certus](../items-blocks-machines/budding_certus.md)
de vários tipos e um <ItemLink id="mysterious_cube" /> no centro.

A página [Primeiros Passos](../getting-started.md) explica o que fazer depois que você encontrar um.

## Encontrando Meteoritos

Meteoritos são bem comuns e deixam enormes crateras no solo, então talvez você já tenha encontrado alguns. Caso contrário, uma
<ItemLink id="meteorite_compass" /> apontará para o Cubo Misterioso mais próximo.

![Cratera de Meteorito](../assets/assemblies/meteorite-crater.png)
