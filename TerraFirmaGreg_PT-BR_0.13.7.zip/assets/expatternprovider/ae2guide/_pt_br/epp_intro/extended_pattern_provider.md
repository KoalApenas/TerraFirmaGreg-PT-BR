---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Provedor de Padrões Estendido ME
    icon: expatternprovider:ex_pattern_provider
categories:
- extended devices
item_ids:
- expatternprovider:ex_pattern_provider
- expatternprovider:ex_pattern_provider_part
---

# Provedor de Padrões Estendido ME

<Row gap="20">
<BlockImage id="expatternprovider:ex_pattern_provider" scale="8"></BlockImage>
<BlockImage id="expatternprovider:ex_pattern_provider" p:push_direction="up" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_pattern_provider.snbt"></ImportStructure>
</GameScene>
</Row>

O Provedor de Padrões Estendido ME é um <ItemLink id="ae2:pattern_provider" /> com um
inventário de padrões maior.

*Quem precisa de uma sub-rede quando é possível colocar todos os padrões em um único bloco?*

![EPPGui](../pic/epp_gui.png)
