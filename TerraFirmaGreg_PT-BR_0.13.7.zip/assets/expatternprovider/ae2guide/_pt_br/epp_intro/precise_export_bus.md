---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Ponto de Exportação Preciso ME
    icon: expatternprovider:precise_export_bus
categories:
- extended devices
item_ids:
- expatternprovider:precise_export_bus
---

# Ponto de Exportação Preciso ME

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_precise_export_bus.snbt"></ImportStructure>
</GameScene>

O Ponto de Exportação Preciso ME exporta itens/fluidos nas quantidades especificadas. Ele só exporta se o recipiente puder aceitar toda a saída.

## Exemplo

![GUI](../pic/pre_bus_gui1.png)

Isso significa exportar 3 pedregulhos por operação. A exportação é interrompida quando a quantidade de pedregulho na rede fica abaixo de 3.

![GUI](../pic/pre_bus_gui2.png)

A exportação também é interrompida quando o recipiente de destino não comporta toda a saída. Agora, o baú só comporta mais 2 pedregulhos, então o ponto de exportação para.
