---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Fatiador de Circuitos
    icon: expatternprovider:circuit_cutter
categories:
- extended devices
item_ids:
- expatternprovider:circuit_cutter
---

# Fatiador de Circuitos

<Row gap="20">
<BlockImage id="expatternprovider:circuit_cutter" scale="8"></BlockImage>
</Row>

Não aguenta a lentidão do Inscritor? Agora existe o Fatiador de Circuitos! Ele pode fatiar blocos de materiais diretamente em
impressões de processador, o que o torna até 9x mais rápido que um Inscritor na maioria das vezes.

**Aviso: as faces de vidro sem portas não podem se conectar à rede.**

