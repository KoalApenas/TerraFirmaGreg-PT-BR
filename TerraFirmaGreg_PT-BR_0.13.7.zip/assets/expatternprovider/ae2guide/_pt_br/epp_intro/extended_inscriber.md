---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Inscritor Estendido
    icon: expatternprovider:ex_inscriber
categories:
- extended devices
item_ids:
- expatternprovider:ex_inscriber
---

# Inscritor Estendido

<Row gap="20">
<BlockImage id="expatternprovider:ex_inscriber" scale="8"></BlockImage>
</Row>

O Inscritor Estendido é um <ItemLink id="ae2:inscriber" /> avançado.

Ele pode executar 4 trabalhos de inscrição ao mesmo tempo.

Há um botão que permite alterar o tamanho máximo das pilhas em seu inventário, assim como no Inscritor normal.

Recomenda-se definir o tamanho da pilha como 1 ao usá-lo com um <ItemLink id="ae2:pattern_provider" />, para evitar possíveis problemas.
