---
navigation:
    title: Introdução ao Extended AE
    position: 60
---

# Amplie sua configuração AE!

O Extended AE traz de volta alguns recursos das versões 1.7.10/1.12.2 do AE para o AE moderno.

[GitHub do Extended AE](https://github.com/GlodBlock/ExtendedAE) 

## Dispositivos Estendidos
<CategoryIndex category="extended devices"></CategoryIndex>

## Itens Estendidos
<CategoryIndex category="extended items"></CategoryIndex>
