---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Ponto de Exportação/Importação Estendido ME
    icon: expatternprovider:ex_import_bus_part
categories:
- extended devices
item_ids:
- expatternprovider:ex_import_bus_part
- expatternprovider:ex_export_bus_part
---

# Ponto de Importação/Exportação Estendido ME

<Row gap="20">
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_import_bus.snbt"></ImportStructure>
</GameScene>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_export_bus.snbt"></ImportStructure>
</GameScene>
</Row>

O Ponto de Importação/Exportação Estendido ME funciona mais rápido que o <ItemLink id="ae2:import_bus" />/<ItemLink id="ae2:export_bus" /> normal
(o multiplicador de velocidade padrão é 8 e pode ser configurado).

Eles também têm mais espaços de melhorias que os normais.

