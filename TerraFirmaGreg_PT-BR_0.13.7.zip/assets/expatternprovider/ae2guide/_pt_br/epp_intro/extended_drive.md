---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Gabinete Estendido ME
    icon: expatternprovider:ex_drive
categories:
- extended devices
item_ids:
- expatternprovider:ex_drive
---

# Gabinete Estendido ME

<Row gap="20">
<BlockImage id="expatternprovider:ex_drive" scale="8"></BlockImage>
</Row>

O Gabinete Estendido ME é um <ItemLink id="ae2:drive" /> com um inventário de células maior. Ele comporta 20 células de armazenamento.
