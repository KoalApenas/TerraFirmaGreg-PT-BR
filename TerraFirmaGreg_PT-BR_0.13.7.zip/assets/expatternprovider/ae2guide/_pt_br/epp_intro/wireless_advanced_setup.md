---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Kit Avançado de Configuração Sem Fio ME
    icon: expatternprovider:wireless_advanced_tool
categories:
- extended devices
item_ids:
- expatternprovider:wireless_advanced_tool
---

# Kit Avançado de Configuração Sem Fio ME

<Row>
<ItemImage id="expatternprovider:wireless_advanced_tool" scale="4"></ItemImage>
</Row>

O Kit Avançado de Configuração Sem Fio ME funciona exatamente como o <ItemLink id="expatternprovider:wireless_tool" />, mas inclui um sistema de fila.
Você pode adicionar conexões à fila e depois alternar para o modo de uso para aplicá-las.
