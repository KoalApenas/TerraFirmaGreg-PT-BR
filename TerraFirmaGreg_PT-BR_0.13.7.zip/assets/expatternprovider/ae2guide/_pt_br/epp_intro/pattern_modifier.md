---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Modificador de Padrões
    icon: expatternprovider:pattern_modifier
categories:
- extended items
item_ids:
- expatternprovider:pattern_modifier
---

# Modificador de Padrões

O Modificador de Padrões é uma ferramenta para modificar padrões em massa.

<ItemImage id="expatternprovider:pattern_modifier" scale="4"></ItemImage>

Clique com o botão direito nele para abrir sua interface gráfica.

## Modo Multiplicação

Você pode multiplicar/dividir por x as quantidades de entrada e saída de um padrão de processamento clicando no botão correspondente.

![PM](../pic/pm.png)

Padrão original:

![PM1](../pic/pm1.png)

Após x10:

![PM2](../pic/pm2.png)

Ele também pode apagar todo o conteúdo dos padrões e transformá-los em padrões vazios ao clicar no botão Limpar.

### Observações:

 - O botão de divisão só funciona quando a quantidade é divisível. Por exemplo, o botão ÷2 não funcionará quando o padrão exigir 3x
pedregulhos como entrada, porque 3÷2 é 1.5.

 - O botão de multiplicação tem um limite (999999). Ele não pode fazer a quantidade de um único ingrediente ultrapassar esse número.

## Modo Substituição

Substitua um ingrediente específico de entrada ou saída de um padrão por outro item.

![PM3](../pic/pm4.png)

O espaço A contém o que será substituído, e o espaço B contém aquilo que substituirá o alvo.

Por exemplo, a configuração a seguir substituirá tábuas por carvão.

![PM4](../pic/pm6.png)

![PM5](../pic/pm5.png)

Clique no botão Substituir para realizar a substituição.

![PM6](../pic/pm7.png)

## Modo Clonagem

Neste modo, você pode copiar qualquer padrão fornecido.

![PM7](../pic/pm3.png)

