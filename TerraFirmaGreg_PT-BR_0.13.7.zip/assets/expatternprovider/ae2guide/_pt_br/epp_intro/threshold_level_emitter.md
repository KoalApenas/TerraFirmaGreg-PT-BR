---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Emissor de Nível Limite ME
    icon: expatternprovider:threshold_level_emitter
categories:
- extended devices
item_ids:
- expatternprovider:threshold_level_emitter
---

# Emissor de Nível Limite ME

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_threshold_level_emitter.snbt"></ImportStructure>
</GameScene>

Ele funciona como um circuito biestável de redefinição e ativação. Ele desliga o sinal de redstone quando a quantidade de um item na rede é menor que
o limite inferior e o liga quando a quantidade é maior que o limite superior.

Por exemplo, suponha que o limite inferior esteja definido como 100 e o limite superior como 150.

No início, a rede está vazia, portanto o emissor não estará ativo.

Quando a quantidade do item ultrapassar 150, o emissor enviará um sinal de redstone.

Quando a quantidade cair para menos de 150, o emissor continuará enviando um sinal.

Por fim, quando a quantidade cair para menos de 100, o emissor será desligado.
