---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Ponto de Exportação por Mod ME
    icon: expatternprovider:mod_export_bus
categories:
- extended devices
item_ids:
- expatternprovider:mod_export_bus
---

# Ponto de Exportação por Mod ME

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_mod_export_bus.snbt"></ImportStructure>
</GameScene>

O Ponto de Exportação por Mod ME é um <ItemLink id="ae2:export_bus" /> que pode ser filtrado pelo nome ou ID do mod.

Use vírgulas para separar vários IDs de mods caso queira filtrar vários mods.

![PIC](../pic/mod_bus_name2.png)
