---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Carregador Estendido
    icon: expatternprovider:ex_charger
categories:
- extended devices
item_ids:
- expatternprovider:ex_charger
---

# Carregador Estendido

<Row gap="20">
<BlockImage id="expatternprovider:ex_charger" scale="8"></BlockImage>
</Row>

O Carregador Estendido é um <ItemLink id="ae2:charger" /> avançado.

Ele pode carregar 4 itens ao mesmo tempo.
