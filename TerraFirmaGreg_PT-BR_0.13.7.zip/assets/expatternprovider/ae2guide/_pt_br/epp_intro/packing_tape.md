---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Fita de Embalagem ME
    icon: expatternprovider:me_packing_tape
categories:
- extended items
item_ids:
- expatternprovider:me_packing_tape
- expatternprovider:package
---

# Fita de Embalagem ME

A Fita de Embalagem ME pode embalar um dispositivo ME colocado no mundo e transformá-lo em um item Dispositivo Embalado.

<Row>
<ItemImage id="expatternprovider:me_packing_tape" scale="4"></ItemImage>
<ItemImage id="expatternprovider:package" scale="4"></ItemImage>
</Row>

## Embalagem

Agache-se e clique com o botão direito em um dispositivo ME usando a fita para obter seu item embalado. Todas as configurações e todo o inventário
do dispositivo serão preservados. Isso pode ser muito útil ao mover sua configuração ME.

Observe que a Fita de Embalagem ME aceita somente os dispositivos da lista. A lista de dispositivos pode ser configurada.

### Lista padrão

|                                   Dispositivo                                    |                                 Nome                                  |
|:---------------------------------------------------------------------------------:|:---------------------------------------------------------------------:|
|    <ItemImage id="expatternprovider:ex_interface_part" scale="3"></ItemImage>     |    <ItemLink id="expatternprovider:ex_interface_part"></ItemLink>     |
| <ItemImage id="expatternprovider:ex_pattern_provider_part" scale="3"></ItemImage> | <ItemLink id="expatternprovider:ex_pattern_provider_part"></ItemLink> |
|       <ItemImage id="expatternprovider:ex_interface" scale="3"></ItemImage>       |       <ItemLink id="expatternprovider:ex_interface"></ItemLink>       |
|   <ItemImage id="expatternprovider:ex_pattern_provider" scale="3"></ItemImage>    |   <ItemLink id="expatternprovider:ex_pattern_provider"></ItemLink>    |
|            <ItemImage id="ae2:cable_interface" scale="3"></ItemImage>             |            <ItemLink id="ae2:cable_interface"></ItemLink>             |
|         <ItemImage id="ae2:cable_pattern_provider" scale="3"></ItemImage>         |         <ItemLink id="ae2:cable_pattern_provider"></ItemLink>         |
|               <ItemImage id="ae2:interface" scale="3"></ItemImage>                |               <ItemLink id="ae2:interface"></ItemLink>                |
|            <ItemImage id="ae2:pattern_provider" scale="3"></ItemImage>            |            <ItemLink id="ae2:pattern_provider"></ItemLink>            |
|                 <ItemImage id="ae2:drive" scale="3"></ItemImage>                  |                 <ItemLink id="ae2:drive"></ItemLink>                  |

## Desembalagem

Basta clicar com o botão direito segurando o item embalado, como se ele fosse o bloco ou a peça do dispositivo, e o dispositivo embalado será restaurado
a partir da embalagem.
