---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Terminal de Fabricação Estendido ME
    icon: expatternprovider:ex_crafting_terminal
categories:
- extended devices
item_ids:
- expatternprovider:ex_crafting_terminal
- expatternprovider:wireless_ex_ct
---

# Terminal de Fabricação Estendido ME

O Terminal de Fabricação Estendido ME acrescenta as funções do Cortador de Pedras, da Mesa de Ferraria e da Bigorna ao <ItemLink id="ae2:crafting_terminal" />.

<Row gap="20">
<GameScene zoom="6" background="transparent">
<ImportStructure src="../structure/cable_ex_crafting_terminal.snbt"></ImportStructure>
<IsometricCamera yaw="180"></IsometricCamera>
</GameScene>
<ItemImage id="expatternprovider:wireless_ex_ct" scale="4"></ItemImage>
</Row>

## Receitas extras

Você pode usar o Terminal de Fabricação Estendido como Cortador de Pedras, Mesa de Ferraria ou Bigorna. Use o botão de aba para alternar entre os modos.

O modo Bigorna pode usar XP líquido de outros mods armazenado na rede ME quando você não tiver níveis suficientes.

![M1](../pic/ex_stonecutter.png)

![M2](../pic/ex_smith.png)

![M3](../pic/ex_anvil.png)
