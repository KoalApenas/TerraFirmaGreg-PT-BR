---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Montador Molecular Estendido
    icon: expatternprovider:ex_molecular_assembler
categories:
- extended devices
item_ids:
- expatternprovider:ex_molecular_assembler
---

# Montador Molecular Estendido

<Row gap="20">
<BlockImage id="expatternprovider:ex_molecular_assembler" scale="8"></BlockImage>
</Row>

O Montador Molecular Estendido é um <ItemLink id="ae2:molecular_assembler" /> avançado.

Ele pode executar 8 trabalhos de fabricação ao mesmo tempo (é claro que primeiro você precisa de <ItemLink id="ae2:crafting_accelerator" /> na sua rede ME)
e é 2x mais rápido que o normal.

No entanto, ele aceita somente trabalhos de fabricação vindos de um <ItemLink id="ae2:pattern_provider" />; portanto, você não pode inserir padrões diretamente nele.

