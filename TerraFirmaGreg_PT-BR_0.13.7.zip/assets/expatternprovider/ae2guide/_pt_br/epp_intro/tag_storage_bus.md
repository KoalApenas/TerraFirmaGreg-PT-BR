---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Ponto de Armazenamento por Tag ME
    icon: expatternprovider:tag_storage_bus
categories:
- extended devices
item_ids:
- expatternprovider:tag_storage_bus
---

# Ponto de Armazenamento por Tag ME

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_tag_storage_bus.snbt"></ImportStructure>
</GameScene>

O Ponto de Armazenamento por Tag ME é um <ItemLink id="ae2:storage_bus" /> que pode ser filtrado por tags de itens ou fluidos e aceita alguns operadores lógicos básicos.

Veja alguns exemplos:

- Aceitar somente minério bruto

forge:raw_materials/*

- Aceitar todos os lingotes e todas as gemas

forge:ingots/* | forge:gems/*

