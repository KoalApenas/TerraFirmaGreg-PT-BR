---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Melhorias para Dispositivos ME
    icon: expatternprovider:pattern_provider_upgrade
categories:
- extended items
item_ids:
- expatternprovider:pattern_provider_upgrade
- expatternprovider:interface_upgrade
- expatternprovider:io_bus_upgrade
- expatternprovider:pattern_terminal_upgrade
- expatternprovider:drive_upgrade
---

# Melhorias para Dispositivos ME

Estas melhorias permitem substituir dispositivos ME normais por suas versões estendidas sem quebrá-los.

<Row>
<ItemImage id="expatternprovider:pattern_provider_upgrade" scale="4"></ItemImage>
<ItemImage id="expatternprovider:interface_upgrade" scale="4"></ItemImage>
<ItemImage id="expatternprovider:io_bus_upgrade" scale="4"></ItemImage>
<ItemImage id="expatternprovider:pattern_terminal_upgrade" scale="4"></ItemImage>
<ItemImage id="expatternprovider:drive_upgrade" scale="4"></ItemImage>
</Row>

Agache-se e clique com o botão direito nesses dispositivos usando a melhoria correspondente para transformá-los em suas versões estendidas. Todas as configurações e todo o inventário do dispositivo
serão preservados.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/upgrade_show_1.snbt"></ImportStructure>
  <BoxAnnotation color="#ffffff" min="1 0 0" max="4 1 1">
        Provedores de Padrões normais. Você pode aprimorá-los com a Melhoria do Provedor de Padrões.
        <ItemImage id="expatternprovider:pattern_provider_upgrade" scale="2"></ItemImage>
  </BoxAnnotation>
</GameScene>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/upgrade_show_2.snbt"></ImportStructure>
  <BoxAnnotation color="#ffffff" min="1 0 0" max="4 1 1">
        Os Provedores de Padrões Estendidos preservam todas as configurações e todo o inventário de padrões dos Provedores de Padrões originais.
  </BoxAnnotation>
</GameScene>

## Lista de Melhorias

|                                      Melhoria                                     |                         Dispositivo Normal                         |                              Dispositivo Estendido                                |
|:---------------------------------------------------------------------------------:|:------------------------------------------------------------------:|:---------------------------------------------------------------------------------:|
| <ItemImage id="expatternprovider:pattern_provider_upgrade" scale="3"></ItemImage> |    <ItemImage id="ae2:pattern_provider" scale="3"></ItemImage>     |   <ItemImage id="expatternprovider:ex_pattern_provider" scale="3"></ItemImage>    |
| <ItemImage id="expatternprovider:pattern_provider_upgrade" scale="3"></ItemImage> | <ItemImage id="ae2:cable_pattern_provider" scale="3"></ItemImage>  | <ItemImage id="expatternprovider:ex_pattern_provider_part" scale="3"></ItemImage> |
|    <ItemImage id="expatternprovider:interface_upgrade" scale="3"></ItemImage>     |        <ItemImage id="ae2:interface" scale="3"></ItemImage>        |       <ItemImage id="expatternprovider:ex_interface" scale="3"></ItemImage>       |
|    <ItemImage id="expatternprovider:interface_upgrade" scale="3"></ItemImage>     |     <ItemImage id="ae2:cable_interface" scale="3"></ItemImage>     |    <ItemImage id="expatternprovider:ex_interface_part" scale="3"></ItemImage>     |
|      <ItemImage id="expatternprovider:io_bus_upgrade" scale="3"></ItemImage>      |       <ItemImage id="ae2:import_bus" scale="3"></ItemImage>        |    <ItemImage id="expatternprovider:ex_import_bus_part" scale="3"></ItemImage>    |
|      <ItemImage id="expatternprovider:io_bus_upgrade" scale="3"></ItemImage>      |       <ItemImage id="ae2:export_bus" scale="3"></ItemImage>        |    <ItemImage id="expatternprovider:ex_export_bus_part" scale="3"></ItemImage>    |
| <ItemImage id="expatternprovider:pattern_terminal_upgrade" scale="3"></ItemImage> | <ItemImage id="ae2:pattern_access_terminal" scale="3"></ItemImage> |  <ItemImage id="expatternprovider:ex_pattern_access_part" scale="3"></ItemImage>  |
|      <ItemImage id="expatternprovider:drive_upgrade" scale="3"></ItemImage>       |          <ItemImage id="ae2:drive" scale="3"></ItemImage>          |         <ItemImage id="expatternprovider:ex_drive" scale="3"></ItemImage>         |
