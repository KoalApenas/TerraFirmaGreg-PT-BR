---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Reparador de Cristais ME
    icon: expatternprovider:crystal_fixer
categories:
- extended devices
item_ids:
- expatternprovider:crystal_fixer
---

# Reparador de Cristais ME

<BlockImage id="expatternprovider:crystal_fixer" scale="8"></BlockImage>

O Reparador de Cristais ME pode reparar e aprimorar um bloco de Certus em brotamento.

Ele precisa de <ItemLink id="ae2:charged_certus_quartz_crystal" /> e energia para funcionar. Clique nele com o botão direito segurando um <ItemLink id="ae2:charged_certus_quartz_crystal" /> para inserir uma unidade.

No entanto, ele não consegue transformar um bloco imperfeito em impecável. O nível mais alto que o Reparador pode alcançar é imperfeito.

<Row gap="20">
<GameScene zoom="4" background="transparent">
  <ImportStructure src="../structure/crystal_fixer.snbt"></ImportStructure>
</GameScene>
</Row>
