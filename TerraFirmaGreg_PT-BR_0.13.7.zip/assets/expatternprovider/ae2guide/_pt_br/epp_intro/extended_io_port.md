---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Porto de Entrada/Saída Estendido ME
    icon: expatternprovider:ex_io_port
categories:
- extended devices
item_ids:
- expatternprovider:ex_io_port
---

# Porto de Entrada/Saída Estendido ME

<Row gap="20">
<BlockImage id="expatternprovider:ex_io_port" p:powered="true" scale="8"></BlockImage>
</Row>

O Porto de Entrada/Saída Estendido ME funciona 8x mais rápido que o <ItemLink id="ae2:io_port" /> normal.

Ele também tem mais espaços de melhorias que o normal.
