---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Buffer de Ingredientes ME
    icon: expatternprovider:ingredient_buffer
categories:
- extended devices
item_ids:
- expatternprovider:ingredient_buffer
---

# Buffer de Ingredientes ME

<BlockImage id="expatternprovider:ingredient_buffer" scale="8"></BlockImage>

Um bloco de armazenamento capaz de guardar 36 tipos de conteúdo, incluindo itens e fluidos.
