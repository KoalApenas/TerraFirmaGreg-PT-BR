---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Envasador ME
    icon: expatternprovider:caner
categories:
- extended devices
item_ids:
- expatternprovider:caner
---

# Envasador ME

<BlockImage id="expatternprovider:caner" scale="8"></BlockImage>

O Envasador ME é uma máquina que envasa recursos, incluindo fluidos, gases do Mekanism, mana do Botania e até energia!

O primeiro espaço recebe o recurso de preenchimento, e o segundo recebe o recipiente que será preenchido.

Ele precisa de energia para funcionar, e cada operação custa 80 AE.

![GUI](../pic/caner_gui.png)

Por padrão, ele preenche apenas fluidos. Para preencher outros recursos, você precisa instalar o complemento correspondente.

### Complementos compatíveis:
- Applied Flux
- Applied Mekanistics
- Applied Botanics Addon

## Fabricação automática com o Envasador ME

Somente as faces superior e inferior podem receber energia e se conectar à rede.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/caner_example.snbt"></ImportStructure>
</GameScene>

Uma configuração simples para o Envasador ME. O Envasador ME ejeta automaticamente o item preenchido ao receber os ingredientes de um <ItemLink id="ae2:pattern_provider" />.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/caner_auto.snbt"></ImportStructure>
</GameScene>

O padrão deve conter somente o recurso usado no preenchimento e o recipiente a ser preenchido. Veja alguns exemplos:

Encher um balde de água:

![P1](../pic/fill_water.png)

Carregar um Tablete de Energia (requer Applied Flux):

![P1](../pic/fill_energy.png)


## Esvaziamento

O Envasador ME também pode drenar recursos de recipientes no modo Esvaziar. Você precisa inverter as entradas e saídas no padrão.
