---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Célula ME Infinita
    icon: expatternprovider:infinity_cell
categories:
- extended items
item_ids:
- expatternprovider:infinity_cell
---

# Célula ME Infinita

Uma opção prática para água e pedregulho em forma de célula de armazenamento.

<Row>
<ItemImage id="expatternprovider:infinity_cell" scale="4"></ItemImage>
</Row>

Ela pode armazenar 2.1 bilhões de itens/fluidos, e você pode extrair dela uma quantidade infinita de pedregulho/água ou inserir nela uma quantidade infinita de
pedregulho/água.
