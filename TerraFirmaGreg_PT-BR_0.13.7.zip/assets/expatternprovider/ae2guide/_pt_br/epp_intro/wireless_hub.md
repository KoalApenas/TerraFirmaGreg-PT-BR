---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Concentrador Sem Fio ME
    icon: expatternprovider:wireless_hub
categories:
- extended devices
item_ids:
- expatternprovider:wireless_hub
---

# Concentrador Sem Fio ME

<Row gap="20">
<BlockImage id="expatternprovider:wireless_hub" scale="6"></BlockImage>
</Row>

O Concentrador Sem Fio ME funciona exatamente como o <ItemLink id="expatternprovider:wireless_connect" />, mas pode se conectar a até 8 concentradores/conectores
ao mesmo tempo.

## Configuração das conexões

Há 8 portas no Concentrador Sem Fio ME. Ele encontra automaticamente uma porta disponível quando você o conecta usando o <ItemLink id="expatternprovider:wireless_tool" />.

No entanto, quando todas as portas estiverem ocupadas, você precisará desconectar uma manualmente clicando no botão 'X' antes de configurar novas conexões.
