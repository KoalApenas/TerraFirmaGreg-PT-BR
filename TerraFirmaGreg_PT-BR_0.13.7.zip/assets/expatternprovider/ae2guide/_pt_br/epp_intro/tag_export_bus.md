---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Ponto de Exportação por Tag ME
    icon: expatternprovider:tag_export_bus
categories:
- extended devices
item_ids:
- expatternprovider:tag_export_bus
---

# Ponto de Exportação por Tag ME

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_tag_export_bus.snbt"></ImportStructure>
</GameScene>

O Ponto de Exportação por Tag ME é um <ItemLink id="ae2:export_bus" /> que pode ser filtrado por tags de itens ou fluidos.

Sua regra de filtragem é a mesma do <ItemLink id="expatternprovider:tag_storage_bus" />.

