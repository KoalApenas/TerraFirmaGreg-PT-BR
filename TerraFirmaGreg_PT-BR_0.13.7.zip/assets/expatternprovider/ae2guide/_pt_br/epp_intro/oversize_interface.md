---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Interface Superdimensionada ME
    icon: expatternprovider:oversize_interface
categories:
- extended devices
item_ids:
- expatternprovider:oversize_interface
- expatternprovider:oversize_interface_part
---
# Interface Superdimensionada ME
<Row gap="20">
<BlockImage id="expatternprovider:oversize_interface" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_oversize_interface.snbt"></ImportStructure>
</GameScene>
</Row>
A Interface Superdimensionada ME tem o mesmo número de espaços que a <ItemLink id="expatternprovider:ex_interface" />, mas pode armazenar 16 vezes mais (configurável)
itens por espaço. Isso significa que ela pode armazenar 1024 (64x16) itens em cada espaço.
