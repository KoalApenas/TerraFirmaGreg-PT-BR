---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Conector Sem Fio ME
    icon: expatternprovider:wireless_connect
categories:
- extended devices
item_ids:
- expatternprovider:wireless_connect
- expatternprovider:wireless_tool
---

# Conector Sem Fio ME

<Row gap="20">
<BlockImage id="expatternprovider:wireless_connect" scale="6"></BlockImage>
<ItemImage id="expatternprovider:wireless_tool" scale="6"></ItemImage>
</Row>

O Conector Sem Fio ME pode interligar duas redes como o <ItemLink id="ae2:quantum_link" />, mas com alcance limitado e sem
suporte entre dimensões. O Conector Sem Fio ME aceita somente conexões de um para um. Use um <ItemLink id="expatternprovider:wireless_hub" />
caso queira conexões de muitos para muitos.

## Conectar os Conectores Sem Fio

Clique nos dois Conectores Sem Fio que deseja interligar usando o Kit de Configuração Sem Fio ME para conectá-los.

Agache-se e clique para apagar a configuração atual do Kit de Configuração Sem Fio ME.

O Conector Sem Fio ME muda de textura quando uma conexão é estabelecida com sucesso.

Conectores Sem Fio ME desconectados

<GameScene zoom="5" background="transparent">
  <ImportStructure src="../structure/wireless_connector_off.snbt"></ImportStructure>
</GameScene>

Conectores Sem Fio ME conectados

<GameScene zoom="5" background="transparent">
  <ImportStructure src="../structure/wireless_connector_on.snbt"></ImportStructure>
</GameScene>

## Cor

Os Conectores Sem Fio podem ser coloridos como cabos e só se conectam a cabos/conectores da mesma cor.

Você precisa de um <ItemLink id="ae2:color_applicator" /> para colorir o conector.

Assim, você pode configurar seus Conectores Sem Fio desta forma:

<GameScene zoom="3" background="transparent" interactive={true}>
  <ImportStructure src="../structure/wireless_connector_setup.snbt"></ImportStructure>
</GameScene>

## Consumo de energia

Os Conectores Sem Fio ME consomem mais energia quanto maior for a distância entre eles. A curva de custo por distância não é linear; portanto, o custo de energia
pode ficar muito alto quando eles estão distantes demais.

Você pode usar <ItemLink id="ae2:energy_card" /> para economizar energia. Cada placa reduz o custo de energia em 10%.

