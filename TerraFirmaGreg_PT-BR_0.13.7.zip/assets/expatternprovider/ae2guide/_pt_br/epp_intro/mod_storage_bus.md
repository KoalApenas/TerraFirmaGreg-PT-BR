---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Ponto de Armazenamento por Mod ME
    icon: expatternprovider:mod_storage_bus
categories:
- extended devices
item_ids:
- expatternprovider:mod_storage_bus
---

# Ponto de Armazenamento por Mod ME

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_mod_storage_bus.snbt"></ImportStructure>
</GameScene>

O Ponto de Armazenamento por Mod ME é um <ItemLink id="ae2:storage_bus" /> que pode ser filtrado pelo nome ou ID do mod.

Use vírgulas para separar vários IDs de mods caso queira filtrar vários mods.

![PIC](../pic/mod_bus_name.png)

