---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Terminal de Acesso Estendido aos Padrões ME
    icon: expatternprovider:ex_pattern_access_part
categories:
- extended devices
item_ids:
- expatternprovider:ex_pattern_access_part
- expatternprovider:wireless_ex_pat
---

# Terminal de Acesso Estendido aos Padrões ME

O Terminal de Acesso Estendido aos Padrões ME oferece 3 recursos adicionais em comparação com o <ItemLink id="ae2:pattern_access_terminal" />.

<Row gap="20">
<GameScene zoom="6" background="transparent">
<ImportStructure src="../structure/cable_ex_pattern_terminal.snbt"></ImportStructure>
<IsometricCamera yaw="180"></IsometricCamera>
</GameScene>
<ItemImage id="expatternprovider:wireless_ex_pat" scale="4"></ItemImage>
</Row>

## Pesquisa de padrões aprimorada

Você pode pesquisar padrões pelo nome do ingrediente de entrada/saída.

![EPA1](../pic/epa_gui1.png)

## Destaque de padrões

Às vezes, ainda é difícil encontrar o padrão desejado porque os padrões sempre são exibidos em grupos. Agora, o Terminal de Acesso
Estendido aos Padrões pode destacar na interface gráfica o padrão correspondente.

![EPA2](../pic/epa_gui2.png)

## Destaque do Provedor de Padrões no mundo

É incômodo descobrir qual Provedor de Padrões está travado ao executar trabalhos de fabricação grandes. O Terminal de Acesso Estendido aos Padrões
pode destacar o Provedor de Padrões no mundo, permitindo localizá-lo facilmente.

![EPA3](../pic/epa_gui3.png)

