---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Ponto de Exportação por Limite ME
    icon: expatternprovider:threshold_export_bus
categories:
- extended devices
item_ids:
- expatternprovider:threshold_export_bus
---

# Ponto de Exportação por Limite ME

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_threshold_export_bus.snbt"></ImportStructure>
</GameScene>

O Ponto de Exportação por Limite ME funciona quando a quantidade de um item armazenado na rede ME está acima ou abaixo do limite.

## Exemplo

![GUI](../pic/thr_bus_gui1.png)

O limite do cobre está definido como 128; portanto, ele exporta cobre quando a quantidade de cobre armazenada na rede ultrapassa 128.

![GUI](../pic/thr_bus_gui2.png)

O limite é igual ao anterior, mas o modo está definido como ABAIXO. Ele exporta cobre quando a quantidade armazenada fica abaixo de 128.
